import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { db } from './src/server/db.ts';
import { firestore, config as firebaseConfig, syncEntireDatabase, syncDocument, loadFirestoreDataIntoDb, purgeNonMasterFirestoreData } from './src/server/firebaseServer.ts';
import { requireAuth } from './src/middleware/auth.ts';
import type { AuthRequest } from './src/middleware/auth.ts';
import { getUsers as getSqlUsers, getOrCreateUser as getOrCreateSqlUser } from './src/db/users.ts';
import { db as sqlDb } from './src/db/index.ts';

dotenv.config();

// Prevent dev server process from dying on background network interruptions, transient EADDRINUSE, or Firestore quota notices
process.on('uncaughtException', (err: any) => {
  const msg = err?.message || String(err);
  if (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota') ||
    msg.includes('EADDRINUSE') ||
    msg.includes('ECONNRESET') ||
    msg.includes('Port 24678 is already in use')
  ) {
    console.warn('[Handled Background Server Notice]:', msg);
    return;
  }
  console.error('[Server Uncaught Exception]:', err);
});

process.on('unhandledRejection', (reason: any) => {
  const msg = reason?.message || String(reason);
  if (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota') ||
    msg.includes('ECONNRESET')
  ) {
    console.warn('[Handled Background Promise Rejection]:', msg);
    return;
  }
  console.error('[Server Unhandled Rejection]:', reason);
});

const app = express();
const argPortIndex = process.argv.indexOf('--port');
const argPort = argPortIndex !== -1 && process.argv[argPortIndex + 1] ? parseInt(process.argv[argPortIndex + 1], 10) : undefined;
const envPort = process.env.PORT ? parseInt(process.env.PORT, 10) : undefined;
// Runtime environment strictly mandates port 3000 for dev & preview. Avoid port 8080 which is container nginx.
const PORT = (envPort && envPort !== 8080) ? envPort : ((argPort && argPort !== 8080) ? argPort : 3000);

// Global Middleware & CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json());

// Handle favicon and robots to prevent 404 console noise
app.get('/favicon.ico', (_req: Request, res: Response) => {
  res.status(204).end();
});
app.get('/robots.txt', (_req: Request, res: Response) => {
  res.type('text/plain').send('User-agent: *\nAllow: /');
});

// Direct Project ZIP Download route for user export/backup
app.get(['/download-project-zip', '/spikenodes-project.zip', '/api/download-zip'], (_req: Request, res: Response) => {
  const zipPath = path.resolve('public', 'spikenodes-project.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="spikenodes-full-project.zip"');
    res.download(zipPath, 'spikenodes-full-project.zip');
  } else {
    res.status(404).send('Project zip file not found.');
  }
});

// Ready-to-upload Hostinger public_html ZIP (Contains only compiled production assets and .htaccess)
app.get(['/download-hostinger-zip', '/spikenodes-hostinger-dist.zip'], (_req: Request, res: Response) => {
  const distZipPath = path.resolve('public', 'spikenodes-hostinger-dist.zip');
  if (fs.existsSync(distZipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="spikenodes-hostinger-public_html.zip"');
    res.download(distZipPath, 'spikenodes-hostinger-public_html.zip');
  } else {
    res.status(404).send('Hostinger zip not found.');
  }
});

// ============================================================
// SYSTEM & DATABASE HEALTH APIS
// ============================================================
app.get('/api/health', (req: Request, res: Response) => {
  const stats = db.getStats();
  res.json({
    status: 'ONLINE',
    system: 'SPIKE Mining Protocol Backend Engine',
    timestamp: new Date().toISOString(),
    database: {
      status: 'CONNECTED',
      sizeKb: stats.dbSizeKb,
      lastSaved: stats.lastSaved,
      users: stats.totalUsers,
      nodes: stats.totalNodes,
      transactions: stats.totalTransactions,
    },
  });
});

app.get('/api/db/health', (req: Request, res: Response) => {
  res.json({
    status: 'HEALTHY',
    engine: 'SPIKE Persistent JSON ACID Database Engine',
    stats: db.getStats(),
  });
});

app.get('/api/db/export', (req: Request, res: Response) => {
  const exportData = db.exportData();
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename=spike_database_backup_${Date.now()}.json`);
  res.json(exportData);
});

app.post('/api/db/reset', (req: Request, res: Response) => {
  const adminAddress = req.body.adminAddress || '0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
  const result = db.resetMainnetBaseline(adminAddress);
  res.json(result);
});

app.post('/api/db/reset-mainnet', (req: Request, res: Response) => {
  const adminAddress = req.body.adminAddress || '0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
  const result = db.resetMainnetBaseline(adminAddress);
  res.json(result);
});

app.post('/api/db/clean-to-master-only', async (req: Request, res: Response) => {
  try {
    const masterWallets = req.body.masterWallets || [
      '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
      '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
    ];
    // 1. Purge memory and local JSON database
    const dbResult = db.purgeNonMasterData(masterWallets);
    
    // 2. Purge Firestore collections
    const firestoreResult = await purgeNonMasterFirestoreData(masterWallets);

    res.json({
      success: true,
      message: 'All non-master addresses, mining records, nodes, and test data successfully cleaned from database.',
      database: dbResult,
      firestore: firestoreResult,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to clean database' });
  }
});

// ============================================================
// FIREBASE FIRESTORE SYNC & STATUS APIS
// ============================================================
app.get('/api/firebase/status', (req: Request, res: Response) => {
  res.json({
    connected: !!firestore,
    projectId: firebaseConfig?.projectId || null,
    databaseId: firebaseConfig?.firestoreDatabaseId || null,
    status: firestore ? 'ONLINE_ACTIVE' : 'INITIALIZING',
    storage: 'Firebase Cloud Firestore Enterprise',
    rules: 'Deployed and active',
  });
});

app.post('/api/firebase/sync', async (req: Request, res: Response) => {
  try {
    const allData = db.exportData();
    const result = await syncEntireDatabase(allData);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || String(err) });
  }
});

// ============================================================
// CLOUD SQL POSTGRESQL & AUTH APIS
// ============================================================
app.get('/api/users', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const users = await getSqlUsers();
    res.json(users);
  } catch (error: any) {
    console.error('Failed to fetch users from Cloud SQL:', error);
    res.status(500).json({ error: error.message || 'Failed to fetch users' });
  }
});

app.post('/api/users/sync-sql', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user?.uid) {
      res.status(401).json({ error: 'Unauthorized: missing user uid' });
      return;
    }
    const { address } = req.body || {};
    const user = await getOrCreateSqlUser(req.user.uid, req.user.email, address);
    res.json({ success: true, user });
  } catch (error: any) {
    console.error('Failed to sync auth user to Cloud SQL:', error);
    res.status(500).json({ error: error.message || 'Failed to sync user' });
  }
});

// ============================================================
// OFFICIAL DOMAIN & SUBLINKS CONFIGURATION (spikenodes.com)
// ============================================================
app.get('/api/domain/config', (req: Request, res: Response) => {
  const settings = db.getSettings();
  const domain = settings.primaryDomain || 'spikenodes.com';
  const baseUrl = `https://${domain}`;

  res.json({
    primaryDomain: domain,
    canonicalUrl: baseUrl,
    sublinks: {
      home: `${baseUrl}/`,
      dashboard: `${baseUrl}/?tab=dashboard`,
      miningNodes: `${baseUrl}/?tab=mining-nodes`,
      referrals: `${baseUrl}/?tab=referrals`,
      adminConsole: `${baseUrl}/?tab=admin`,
      apiHealth: `${baseUrl}/api/health`,
      dbExport: `${baseUrl}/api/db/export`,
    },
    subdomains: {
      pool: `pool.${domain}`,
      stratum: settings.stratumPoolUrl || `stratum+tcp://pool.${domain}:443`,
      api: `${baseUrl}/api`,
      rpc: settings.rpcUrl || `https://rpc.${domain}`,
      docs: settings.docsUrl || `https://docs.${domain}`,
    },
    dnsRecords: [
      { type: 'A', host: '@', value: '172.67.149.202 (Cloudflare/Edge)', status: 'Active' },
      { type: 'CNAME', host: 'www', value: domain, status: 'Active' },
      { type: 'CNAME', host: 'pool', value: `stratum.${domain}`, status: 'Stratum ASIC' },
      { type: 'CNAME', host: 'api', value: domain, status: 'REST Gateway' },
      { type: 'CNAME', host: 'docs', value: `gitbook.${domain}`, status: 'Docs' },
    ],
    ssl: {
      issuer: "Let's Encrypt / Cloudflare Edge TLS",
      status: 'Valid & Enforced (HTTPS)',
      hsts: true,
    },
    timestamp: new Date().toISOString(),
  });
});

app.get('/admin', (req: Request, res: Response) => {
  res.redirect('/?tab=admin');
});

// ============================================================
// ADMIN PANEL APIS
// ============================================================
app.get('/api/admin/metrics', (req: Request, res: Response) => {
  const stats = db.getStats();
  const settings = db.getSettings();
  const recentLogs = db.getAuditLogs(10);
  res.json({
    ...stats,
    settings,
    recentLogs,
  });
});

app.get('/api/admin/users', (req: Request, res: Response) => {
  const users = db.getUsers();
  res.json({ users });
});

app.post('/api/admin/users/:address/adjust-balance', (req: Request, res: Response) => {
  try {
    const { address } = req.params;
    const { usdtDelta = 0, bnbDelta = 0, reason = 'Admin adjustment', adminUser = 'Admin Portal' } = req.body || {};
    const norm = (address || '').toLowerCase();
    let user = db.getUser(norm);
    if (!user) {
      user = db.upsertUser({ address: norm });
    }
    const updated = db.adjustUserBalance(norm, Number(usdtDelta), Number(bnbDelta), reason, adminUser);
    if (updated) {
      syncDocument('users', norm, updated).catch(() => {});
    }
    res.json({ success: true, user: updated });
  } catch (err: any) {
    console.error('[API Error] adjust-balance:', err);
    res.status(500).json({ success: false, error: err?.message || 'Server error adjusting balance' });
  }
});

app.post('/api/admin/faucet/credit', (req: Request, res: Response) => {
  try {
    const { walletAddress, amount = 100, bnbAmount = 0.05, note = 'Admin Faucet Credit' } = req.body || {};
    const addr = (walletAddress || '').trim();
    if (!addr || !addr.startsWith('0x') || addr.length < 10) {
      res.status(400).json({ success: false, error: 'Valid BEP-20 wallet address (starting with 0x) is required' });
      return;
    }
    const norm = addr.toLowerCase();
    let user = db.getUser(norm);
    if (!user) {
      user = db.upsertUser({ address: addr });
    }
    const amt = Number(amount) || 100;
    const bnbAmt = Number(bnbAmount) || 0;
    const updated = db.adjustUserBalance(norm, amt, bnbAmt, note, 'Admin Testnet Faucet');
    if (updated) {
      syncDocument('users', norm, updated).catch(() => {});
    }
    res.json({ success: true, user: updated, creditedUsdt: amt, creditedBnb: bnbAmt });
  } catch (err: any) {
    console.error('[API Error] faucet/credit:', err);
    res.status(500).json({ success: false, error: err?.message || 'Server error crediting wallet' });
  }
});

app.get('/api/admin/is-master/:address', (req: Request, res: Response) => {
  const { address } = req.params;
  const isMaster = db.isMasterUser(address);
  res.json({ success: true, isMaster, address });
});

app.post('/api/admin/users/:address/role', (req: Request, res: Response) => {
  const { address } = req.params;
  const { role, adminUser = 'Master Admin' } = req.body;
  if (!['master', 'admin', 'user', 'moderator'].includes(role)) {
    res.status(400).json({ error: 'Invalid role value' });
    return;
  }
  const updated = db.updateUserRole(address, role, adminUser);
  if (!updated) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  syncDocument('users', address.toLowerCase(), updated).catch(() => {});
  res.json({ success: true, user: updated });
});

app.post('/api/admin/users/:address/status', (req: Request, res: Response) => {
  const { address } = req.params;
  const { status, adminUser = 'Admin Portal' } = req.body;
  if (!['active', 'frozen', 'banned'].includes(status)) {
    res.status(400).json({ error: 'Invalid status value' });
    return;
  }
  const updated = db.setUserStatus(address, status, adminUser);
  if (!updated) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  syncDocument('users', address.toLowerCase(), updated).catch(() => {});
  res.json({ user: updated });
});

app.post('/api/admin/users/:address/hashrate', (req: Request, res: Response) => {
  try {
    const { address } = req.params;
    const { hashrate, reason = 'Admin Override', adminUser = 'Admin Portal' } = req.body || {};
    const norm = (address || '').toLowerCase();
    const result = db.setUserCustomHashrate(norm, hashrate !== undefined ? hashrate : null, reason, adminUser);
    if (result.user) {
      syncDocument('users', norm, result.user).catch(() => {});
    }
    res.json(result);
  } catch (err: any) {
    console.error('[API Error] hashrate override:', err);
    res.status(500).json({ success: false, error: err?.message || 'Server error setting hashrate' });
  }
});

app.get('/api/admin/nodes', (req: Request, res: Response) => {
  const nodes = db.getNodes();
  res.json({ nodes });
});

app.post('/api/admin/nodes/:id/status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, adminUser = 'Admin Portal' } = req.body;
  const updated = db.updateNodeStatus(id, status, adminUser);
  if (!updated) {
    res.status(404).json({ error: 'Node not found' });
    return;
  }
  res.json({ success: true, node: updated });
});

app.delete('/api/admin/nodes/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { adminUser = 'Admin Portal' } = req.body;
  const deleted = db.deleteNode(id, adminUser);
  res.json({ success: deleted });
});

app.get('/api/admin/transactions', (req: Request, res: Response) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 100;
  const txs = db.getTransactions(undefined, limit);
  res.json({ transactions: txs });
});

app.post('/api/admin/transactions/:id/status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, adminUser = 'Admin Portal' } = req.body;
  const updated = db.updateTransactionStatus(id, status, adminUser);
  if (!updated) {
    res.status(404).json({ error: 'Transaction not found' });
    return;
  }
  res.json({ success: true, transaction: updated });
});

app.get('/api/admin/referrals', (req: Request, res: Response) => {
  const referrals = db.getReferrals();
  res.json({ referrals });
});


app.get('/api/settings', (req: Request, res: Response) => {
  res.json({ success: true, settings: db.getSettings() });
});

app.get('/api/admin/settings', (req: Request, res: Response) => {
  res.json({ success: true, settings: db.getSettings() });
});

app.post('/api/admin/settings', (req: Request, res: Response) => {
  const { adminUser = 'Master Admin', ...settingsPatch } = req.body;
  const updated = db.updateSettings(settingsPatch, adminUser);
  syncDocument('settings', 'global_config', updated).catch(() => {});
  res.json({ success: true, settings: updated });
});

app.get('/api/admin/audit-logs', (req: Request, res: Response) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 100;
  res.json({ logs: db.getAuditLogs(limit) });
});

// ============================================================
// CLIENT / USER FACING DATA SYNC APIS
// ============================================================
app.get('/api/user/:address', (req: Request, res: Response) => {
  const { address } = req.params;
  const user = db.upsertUser({ address });
  const nodes = db.getNodes(address);
  const transactions = db.getTransactions(address, 20);
  const settings = db.getSettings();
  const referralStats = db.getReferralStats(address);
  const hashrateInfo = db.calculateUserHashrate(address);
  res.json({
    user,
    nodes,
    transactions,
    settings,
    referralStats,
    hashrateInfo,
  });
});

app.post('/api/user/sync-balance', (req: Request, res: Response) => {
  try {
    const { address, balanceUsdt, balanceBnb, balanceSpk, miningCycleStartTime } = req.body || {};
    if (!address) {
      res.status(400).json({ success: false, error: 'address is required' });
      return;
    }
    const user = db.syncUserBalance(address, balanceUsdt, balanceBnb, balanceSpk, miningCycleStartTime);
    if (user) {
      syncDocument('users', address.toLowerCase(), user).catch(() => {});
    }
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error syncing balance' });
  }
});

app.post('/api/faucet/claim', (req: Request, res: Response) => {
  // Public self-claiming disabled per security policy: Only Admin Panel can credit faucet balances
  res.status(403).json({
    success: false,
    error: 'Self-claim faucet is disabled. Testnet USDT can only be credited by the Platform Administrator from the Admin Panel (Testnet Faucet & Wallet Credit).',
  });
});

// BSC RPC on-chain transaction verifier
async function verifyBscTxReceipt(txHash: string): Promise<{
  verifiedOnChain: boolean;
  blockNumber?: number;
  status?: 'Success' | 'Failed' | 'Pending';
  gasUsed?: number;
}> {
  const rpcs = [
    'https://bsc-dataseed.binance.org',
    'https://bsc-dataseed1.defibit.io',
    'https://data-seed-prebsc-1-s1.binance.org:8545',
  ];

  for (const rpc of rpcs) {
    try {
      const res = await fetch(rpc, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'eth_getTransactionReceipt',
          params: [txHash.trim()],
          id: Date.now(),
        }),
        signal: AbortSignal.timeout(3500),
      });

      if (res.ok) {
        const data = await res.json();
        if (data?.result) {
          const receipt = data.result;
          const blockNum = receipt.blockNumber ? parseInt(receipt.blockNumber, 16) : undefined;
          const status = receipt.status === '0x1' ? 'Success' : receipt.status === '0x0' ? 'Failed' : 'Pending';
          const gasUsed = receipt.gasUsed ? parseInt(receipt.gasUsed, 16) : undefined;
          return { verifiedOnChain: true, blockNumber: blockNum, status, gasUsed };
        }
      }
    } catch {
      // Continue to next RPC fallback
    }
  }

  return { verifiedOnChain: false, status: 'Pending' };
}

// ============================================================
// ON-CHAIN BSC BALANCES & RPC HELPERS (SPIKE & USDT BEP-20)
// ============================================================
const SPIKE_CONTRACT_BSC = '0xc213905ac995bCC943c077b7918c8134094A9267';
const USDT_CONTRACT_BSC = '0x55d398326f99059fF775485246999027B3197955';
const BSC_RPC_URLS = [
  'https://bsc-dataseed.binance.org/',
  'https://bsc-dataseed1.defibit.io/',
  'https://binance.llamarpc.com',
  'https://rpc.ankr.com/bsc',
];

async function callBscRpcNode(method: string, params: any[]): Promise<string | null> {
  for (const url of BSC_RPC_URLS) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method, params }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      if (res.ok) {
        const json = await res.json();
        if (json && json.result !== undefined) {
          return json.result;
        }
      }
    } catch {}
  }
  return null;
}

const formatTokenDecimals = (hex: string | null, decimals = 18): number => {
  if (!hex || hex === '0x') return 0;
  try {
    const bi = BigInt(hex);
    const divisor = BigInt(10 ** decimals);
    const whole = bi / divisor;
    const remainder = bi % divisor;
    const remFloat = Number(remainder) / (10 ** decimals);
    return +(Number(whole) + remFloat).toFixed(4);
  } catch {
    return 0;
  }
};

async function fetchOnChainTokenBalance(tokenContract: string, walletAddress: string, decimals = 18): Promise<number> {
  if (!walletAddress || !walletAddress.startsWith('0x') || walletAddress.length < 10) return 0;
  try {
    const cleanAddr = walletAddress.toLowerCase().replace(/^0x/, '').padStart(64, '0');
    const dataPayload = '0x70a08231' + cleanAddr;
    const rawHex = await callBscRpcNode('eth_call', [{ to: tokenContract, data: dataPayload }, 'latest']);
    return formatTokenDecimals(rawHex, decimals);
  } catch {
    return 0;
  }
}

// Check on-chain BEP-20 USDT across official protocol deposit wallet and creator reserve
async function getLiveTreasuryUsdt(): Promise<{ totalUsdt: number; breakdown: Record<string, number> }> {
  const wallets = [
    '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7', // Official Protocol Deposit Wallet (5.00 USDT on BSC mainnet)
    '0x3471e07c4d2f7e11c155760a7b386e616b5c3715', // Master Protocol Creator / Reserve
  ];
  const breakdown: Record<string, number> = {};
  try {
    const balances = await Promise.all(
      wallets.map(async (addr) => {
        const bal = await fetchOnChainTokenBalance(USDT_CONTRACT_BSC, addr, 18);
        breakdown[addr] = bal;
        return bal;
      })
    );
    const totalUsdt = +balances.reduce((sum, b) => sum + b, 0).toFixed(2);
    return { totalUsdt, breakdown };
  } catch {
    return { totalUsdt: 0, breakdown };
  }
}

app.get('/api/deposit/config', async (_req: Request, res: Response) => {
  try {
    const live = await getLiveTreasuryUsdt();
    const currentStored = typeof db.getSettings().treasuryBalanceUsdt === 'number' ? db.getSettings().treasuryBalanceUsdt : 0;
    const effectiveUsdt = Math.max(currentStored, live.totalUsdt);
    if (effectiveUsdt > currentStored) {
      db.updateTreasuryBalance(effectiveUsdt);
      syncDocument('settings', 'global', db.getSettings()).catch(() => {});
    }
    const treasury = db.getTreasuryInfo();
    res.json({
      success: true,
      officialWallet: treasury.treasuryWalletAddress,
      amount: 5,
      miningActivationCost: 10,
      totalProjectCost: 15,
      network: 'BNB Smart Chain (BEP-20)',
      autoVerify: true,
      treasuryBalanceUsdt: effectiveUsdt,
      onChainBreakdown: live.breakdown,
    });
  } catch (err: any) {
    const treasury = db.getTreasuryInfo();
    res.json({
      success: true,
      officialWallet: treasury.treasuryWalletAddress,
      amount: 5,
      miningActivationCost: 10,
      totalProjectCost: 15,
      network: 'BNB Smart Chain (BEP-20)',
      autoVerify: true,
      treasuryBalanceUsdt: treasury.treasuryBalanceUsdt,
    });
  }
});

app.get('/api/treasury', async (_req: Request, res: Response) => {
  try {
    const live = await getLiveTreasuryUsdt();
    const currentStored = typeof db.getSettings().treasuryBalanceUsdt === 'number' ? db.getSettings().treasuryBalanceUsdt : 0;
    const effectiveUsdt = Math.max(currentStored, live.totalUsdt);
    if (effectiveUsdt > currentStored) {
      db.updateTreasuryBalance(effectiveUsdt);
      syncDocument('settings', 'global', db.getSettings()).catch(() => {});
    }
    res.json({
      success: true,
      ...db.getTreasuryInfo(),
      treasuryBalanceUsdt: effectiveUsdt,
      onChainBreakdown: live.breakdown,
    });
  } catch (err: any) {
    res.json({
      success: true,
      ...db.getTreasuryInfo(),
    });
  }
});

app.post('/api/admin/treasury/update-address', (req: Request, res: Response) => {
  try {
    const { newAddress, adminUser = 'Admin Portal' } = req.body || {};
    const result = db.updateTreasuryAddress(newAddress, adminUser);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    syncDocument('settings', 'global', db.getSettings()).catch(() => {});
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to update treasury address' });
  }
});

app.post('/api/treasury/deposit', (req: Request, res: Response) => {
  try {
    const { userAddress, amount = 5, txHash } = req.body || {};
    const effectiveAddress = userAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
    const result = db.processTreasuryDeposit(effectiveAddress, Number(amount) || 5, txHash);
    if (result.success) {
      if (result.user) {
        syncDocument('users', effectiveAddress.toLowerCase(), result.user).catch(() => {});
      }
      if (result.node) {
        syncDocument('nodes', result.node.id, result.node).catch(() => {});
      }
      syncDocument('settings', 'global', db.getSettings()).catch(() => {});
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to process treasury deposit' });
  }
});

app.post('/api/mining/activate', (req: Request, res: Response) => {
  try {
    const { userAddress, nodeName, costUsdt = 10 } = req.body || {};
    if (!userAddress) {
      res.status(400).json({ success: false, error: 'userAddress is required' });
      return;
    }
    const result = db.executeMiningActivation(userAddress, nodeName, Number(costUsdt) || 10);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    const user = db.getUser(userAddress);
    if (user) {
      syncDocument('users', userAddress.toLowerCase(), user).catch(() => {});
    }
    if (result.node) {
      syncDocument('nodes', result.node.id, result.node).catch(() => {});
    }
    syncDocument('settings', 'global', db.getSettings()).catch(() => {});
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to activate mining via smart contract' });
  }
});

app.post('/api/deposit/verify-hash', async (req: Request, res: Response) => {
  try {
    const { userAddress, txHash, amount = 15 } = req.body || {};
    if (!userAddress || !txHash) {
      res.status(400).json({ error: 'userAddress and txHash are required' });
      return;
    }

    const cleanHash = String(txHash).trim();
    if (!cleanHash.startsWith('0x') || cleanHash.length < 20) {
      res.status(400).json({ error: 'Invalid transaction hash format. Must begin with 0x' });
      return;
    }

    const officialWallet = '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7';

    // Query on-chain BSC RPC for real receipt verification
    const onChain = await verifyBscTxReceipt(cleanHash);
    if (onChain.status === 'Failed') {
      res.status(400).json({
        success: false,
        error: 'Transaction failed on the BNB Smart Chain. Please verify your transaction on BscScan.',
      });
      return;
    }

    const result = db.verifyAndProcessDeposit(
      userAddress,
      cleanHash,
      Number(amount) || 15,
      officialWallet,
      onChain.blockNumber
    );

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    if (result.user) {
      syncDocument('users', result.user.address.toLowerCase(), result.user).catch(() => {});
    }
    if (result.transaction) {
      syncDocument('transactions', result.transaction.id, result.transaction).catch(() => {});
    }
    syncDocument('settings', 'global', db.getSettings()).catch(() => {});

    res.json({
      success: true,
      message: `Deposit of ${amount} USDT verified successfully on BNB Smart Chain and credited to Mining Balance!`,
      balanceUsdt: result.user?.balanceUsdt,
      transaction: result.transaction,
      onChainVerification: {
        verified: onChain.verifiedOnChain,
        blockNumber: onChain.blockNumber || result.transaction?.blockNumber,
        status: onChain.status || 'Confirmed',
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Deposit verification failed' });
  }
});

app.get('/api/referrals/stats/:address', (req: Request, res: Response) => {
  const { address } = req.params;
  const stats = db.getReferralStats(address);
  res.json({ success: true, stats });
});

// Dedicated sponsor verification and auto-matcher endpoint
app.get('/api/referrals/verify-sponsor', (req: Request, res: Response) => {
  const query = ((req.query.q as string) || (req.query.code as string) || (req.query.address as string) || '').trim();
  if (!query) {
    res.status(400).json({ success: false, message: 'Referral code or sponsor address is required' });
    return;
  }
  const user = db.findUserByReferralCodeOrAddress(query);
  const { address: extractedAddr } = db.extractReferralInput(query);
  const sponsorAddress = user ? user.address : (extractedAddr || '0x71C8a914B97e889F12A0987cB32456Fa12349A2');
  const referralCode = user?.referralCode || (sponsorAddress.startsWith('0x') ? `SPK-${sponsorAddress.slice(2, 8).toUpperCase()}` : 'SPK-71C8A9');
  const stats = db.getReferralStats(sponsorAddress);

  res.json({
    success: true,
    valid: true,
    sponsorAddress,
    referralCode,
    directPartners: stats.directPartners || 0,
    totalPartners: stats.totalPartners || 0,
    level: (stats.directPartners || 0) >= 10 ? 'Elite Tier 3 Partner' : ((stats.directPartners || 0) >= 3 ? 'VIP Tier 2 Partner' : 'Tier 1 Protocol Sponsor'),
    commissionRate: '15%',
    matched: true,
  });
});

// Sync / register sponsor wallet explicitly from client
app.post('/api/referrals/sync-sponsor', (req: Request, res: Response) => {
  const { address, referralCode } = req.body || {};
  if (!address || typeof address !== 'string' || !address.startsWith('0x')) {
    res.status(400).json({ success: false, message: 'Valid BSC address required' });
    return;
  }
  const cleanAddr = address.trim();
  const code = referralCode || `SPK-${cleanAddr.slice(2, 8).toUpperCase()}`;
  const user = db.upsertUser({ address: cleanAddr, referralCode: code });
  res.json({ success: true, user, referralCode: user.referralCode });
});

app.post('/api/referrals/register', (req: Request, res: Response) => {
  try {
    const { referrerCodeOrAddr, refereeAddress } = req.body || {};
    if (!referrerCodeOrAddr || !refereeAddress) {
      res.status(400).json({ error: 'referrerCodeOrAddr and refereeAddress are required' });
      return;
    }

    const result = db.registerReferral(referrerCodeOrAddr, refereeAddress);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    // Sync updated referrer & referee to Firestore
    if (result.referrer) {
      syncDocument('users', result.referrer.address.toLowerCase(), result.referrer).catch(() => {});
    }
    if (result.referee) {
      syncDocument('users', result.referee.address.toLowerCase(), result.referee).catch(() => {});
    }
    if (result.referral) {
      syncDocument('referrals', result.referral.id, result.referral).catch(() => {});
    }

    const updatedReferrerStats = result.referrer ? db.getReferralStats(result.referrer.address) : null;
    const updatedRefereeStats = result.referee ? db.getReferralStats(result.referee.address) : null;

    res.json({
      success: true,
      message: result.message,
      referral: result.referral,
      referrer: result.referrer,
      referee: result.referee,
      referrerStats: updatedReferrerStats,
      refereeStats: updatedRefereeStats,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to register referral' });
  }
});

// Domain configuration & SSL status (managed entirely in backend)
app.get('/api/config/domain', (req: Request, res: Response) => {
  res.json({
    success: true,
    domain: 'spikenodes.com',
    sslVerified: true,
    sslIssuer: "Let's Encrypt / Cloudflare SSL Authority",
    shortUrlPrefix: 'https://spikenodes.com/ref',
    corsEnabled: true,
  });
});

// Short referral link backend redirect
app.get(['/ref/:code', '/r/:code'], (req: Request, res: Response) => {
  const { code } = req.params;
  let sponsor = (req.query.sponsor as string) || '';

  // If sponsor address not in query, resolve from db by code or address
  if (!sponsor && code) {
    const resolvedUser = db.findUserByReferralCodeOrAddress(code);
    if (resolvedUser && resolvedUser.address) {
      sponsor = resolvedUser.address;
    }
  }

  if (sponsor && /^0x[a-fA-F0-9]{40}$/i.test(sponsor.trim())) {
    db.upsertUser({
      address: sponsor.trim(),
      referralCode: code || `SPK-${sponsor.trim().slice(2, 8).toUpperCase()}`,
    });
  }
  const queryObj: Record<string, string> = { ...(req.query as Record<string, string>) };
  if (sponsor && !queryObj.sponsor) {
    queryObj.sponsor = sponsor;
  }
  const qs = new URLSearchParams(queryObj).toString();
  const target = `/?ref=${encodeURIComponent(code)}${qs ? `&${qs}` : ''}`;
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.redirect(302, target);
});


app.post('/api/referrals/simulate', (req: Request, res: Response) => {
  const { referrerAddress } = req.body;
  if (!referrerAddress) {
    res.status(400).json({ error: 'referrerAddress is required' });
    return;
  }
  const result = db.simulateReferral(referrerAddress);
  const stats = db.getReferralStats(referrerAddress);
  res.json({ success: true, ...result, stats });
});

// ============================================================
// WITHDRAWAL REQUESTS & ADMIN APPROVAL APIS
// ============================================================
app.get('/api/withdrawals', (req: Request, res: Response) => {
  try {
    const userAddress = req.query.userAddress as string | undefined;
    const requests = db.getWithdrawalRequests(userAddress);
    res.json({ success: true, withdrawals: requests });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to fetch withdrawals' });
  }
});

app.post('/api/withdrawals/request', (req: Request, res: Response) => {
  try {
    const { userAddress, destinationAddress, amount, source, milestoneLabel } = req.body || {};
    if (!userAddress || !amount) {
      res.status(400).json({ success: false, error: 'userAddress and amount are required' });
      return;
    }
    const result = db.createWithdrawalRequest({
      userAddress,
      destinationAddress: destinationAddress || userAddress,
      amount: Number(amount),
      source: source || 'milestone_reward',
      milestoneLabel: milestoneLabel || 'Team Milestone Reward',
    });

    if (result.success && result.request) {
      syncDocument('withdrawals', result.request.id, result.request).catch(() => {});
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to create withdrawal request' });
  }
});

app.post('/api/admin/withdrawals/:id/approve', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { txHash, adminUser } = req.body || {};
    const result = db.approveWithdrawalRequest(id, txHash, adminUser || 'Admin Dashboard');

    if (result.success && result.request) {
      syncDocument('withdrawals', result.request.id, result.request).catch(() => {});
      if (result.user) {
        syncDocument('users', result.user.address.toLowerCase(), result.user).catch(() => {});
      }
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to approve withdrawal' });
  }
});

app.post('/api/admin/withdrawals/:id/reject', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason, adminUser } = req.body || {};
    const result = db.rejectWithdrawalRequest(id, reason, adminUser || 'Admin Dashboard');

    if (result.success && result.request) {
      syncDocument('withdrawals', result.request.id, result.request).catch(() => {});
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to reject withdrawal' });
  }
});

app.post('/api/user/:address/sync', (req: Request, res: Response) => {
  const { address } = req.params;
  const patch = req.body;
  const updated = db.upsertUser({ address, ...patch });
  res.json({ success: true, user: updated });
});

app.get('/api/nodes', (req: Request, res: Response) => {
  const userAddress = req.query.address as string | undefined;
  res.json({ nodes: db.getNodes(userAddress) });
});

app.post('/api/nodes/deploy', (req: Request, res: Response) => {
  const { userAddress, name, region, hashrate = 85, costUsdt = 15 } = req.body;
  if (!userAddress || !name) {
    res.status(400).json({ error: 'Missing required node parameters' });
    return;
  }
  const user = db.getUser(userAddress);
  if (user && user.balanceUsdt < costUsdt) {
    res.status(400).json({ error: 'Insufficient wallet balance in database' });
    return;
  }

  // Deduct balance
  if (user) {
    db.adjustUserBalance(userAddress, -costUsdt, 0, `Node activation fee (${name})`, 'SYSTEM');
  }

  const newNode = db.createNode({
    userAddress,
    name,
    region: region || 'Frankfurt (EU-Central)',
    status: 'mining',
    hashrate: Number(hashrate),
    temperature: 61,
    shareAcceptance: 99.9,
    fanSpeed: 70,
    powerUsage: 2200,
    uptimeDays: 0.1,
    algorithm: 'SHA-256 (BSC Sublayer)',
    logs: [
      `[${new Date().toLocaleTimeString()}] Provisioned on BSC validator sublayer.`,
      `[${new Date().toLocaleTimeString()}] Stratum target diff accepted: 1048576.`,
    ],
    costUsdt: Number(costUsdt),
  });

  if (newNode) {
    syncDocument('nodes', newNode.id, newNode).catch(() => {});
  }
  const updatedUserAfterNode = db.getUser(userAddress);
  if (updatedUserAfterNode) {
    syncDocument('users', userAddress.toLowerCase(), updatedUserAfterNode).catch(() => {});
  }

  res.json({ success: true, node: newNode });
});

app.post('/api/nodes/sync', (req: Request, res: Response) => {
  const { userAddress, nodes } = req.body || {};
  if (!userAddress) {
    res.status(400).json({ error: 'userAddress is required' });
    return;
  }
  const synced = db.syncUserNodes(userAddress, nodes || []);
  if (Array.isArray(synced)) {
    synced.forEach((n) => syncDocument('nodes', n.id, n).catch(() => {}));
  }
  res.json({ success: true, nodes: synced });
});

app.post('/api/nodes/:id/action', (req: Request, res: Response) => {
  const { id } = req.params;
  const { action, userAddress = 'user' } = req.body;
  let status: 'mining' | 'idle' | 'stopped' = 'mining';
  if (action === 'stop') status = 'idle';
  else if (action === 'restart' || action === 'start') status = 'mining';

  let updated = db.updateNodeStatus(id, status, userAddress);
  // Fallback: If node wasn't in db fleet, register it as an active node for this user
  if (!updated && userAddress && userAddress !== 'user') {
    const norm = userAddress.toLowerCase();
    const created = db.createNode({
      userAddress: norm,
      name: id,
      region: 'Frankfurt (EU-Central BSC Pool)',
      status,
      hashrate: 142.8,
      temperature: status === 'mining' ? 63 : 45,
      shareAcceptance: 99.9,
      fanSpeed: 70,
      powerUsage: 2200,
      uptimeDays: 0.1,
      algorithm: 'SHA-256 (BSC Sublayer)',
      logs: [`[${new Date().toLocaleTimeString()}] Node initialized with status ${status}`],
      costUsdt: 15,
    });
    updated = created;
  }
  if (updated) {
    syncDocument('nodes', updated.id, updated).catch(() => {});
  }
  res.json({ success: !!updated, node: updated });
});

app.post('/api/transactions/record', (req: Request, res: Response) => {
  const { userAddress, type, amount, currency = 'USDT', details, txHash } = req.body;
  const created = db.createTransaction({
    userAddress,
    txHash: txHash || `0x${Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
    type: type || 'claim',
    amount: Number(amount),
    currency,
    status: 'Confirmed',
    details: details || 'Platform transaction',
    blockNumber: 42900000 + Math.floor(Math.random() * 50000),
  });

  // Adjust balance if applicable
  if (type === 'claim' || type === 'faucet' || type === 'referral_bonus') {
    db.adjustUserBalance(userAddress, Number(amount), 0, details || type, 'SYSTEM');
  }

  if (created) {
    syncDocument('transactions', created.id, created).catch(() => {});
    const updatedUser = db.getUser(userAddress);
    if (updatedUser) {
      syncDocument('users', userAddress.toLowerCase(), updatedUser).catch(() => {});
    }
  }

  res.json({ success: true, transaction: created });
});

// ============================================================
// SPIKE (SPK) TESTNET & HARVEST AUTO-BUY ENGINE APIS
// ============================================================
app.get('/api/testnet/spike/info', (req: Request, res: Response) => {
  try {
    const token = db.getTestnetSpikeToken();
    res.json({
      success: true,
      token,
      metrics: {
        totalSupply: token.totalSupply,
        circulatingSupply: token.circulatingSupply,
        symbol: token.symbol,
        name: token.name,
        decimals: token.decimals,
        contractAddress: token.contractAddress,
        pair: token.pair,
        priceUsdt: token.currentPrice,
        poolReserves: {
          spk: token.poolSpkReserve,
          usdt: token.poolUsdtReserve,
        },
        volume24h: token.volume24h,
        high24h: token.high24h,
        low24h: token.low24h,
        change24h: token.change24h,
        buyPressure: token.buyPressure,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error fetching testnet token info' });
  }
});

app.get('/api/testnet/wallet/:address', (req: Request, res: Response) => {
  try {
    const { address } = req.params;
    const wallet = db.getTestnetWallet(address);
    const token = db.getTestnetSpikeToken();
    const transactions = db.getTestnetTransactions(address, 20);
    res.json({
      success: true,
      wallet,
      tokenPrice: token.currentPrice,
      transactions,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error fetching testnet wallet' });
  }
});

app.post('/api/testnet/wallet/settings', (req: Request, res: Response) => {
  try {
    const { address, autoBuyEnabled = true, slippageTolerance = 0.5 } = req.body;
    const wallet = db.updateTestnetWalletSettings(address, Boolean(autoBuyEnabled), Number(slippageTolerance));
    res.json({ success: true, wallet });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error updating testnet settings' });
  }
});

app.post('/api/testnet/wallet/faucet', (req: Request, res: Response) => {
  try {
    const { address, usdtAmount = 500, spkAmount = 100 } = req.body;
    const result = db.topupTestnetWallet(address, Number(usdtAmount), Number(spkAmount));
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error crediting testnet faucet' });
  }
});

app.post('/api/testnet/harvest-autobuy', (req: Request, res: Response) => {
  try {
    const { address, minedSpkAmount = 25.0, hashrate = 1.25, slippageTolerance = 0.2, txHash } = req.body;
    const targetAddr = (address && typeof address === 'string' && address.trim()) ? address.trim() : '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
    const numAmount = Number(minedSpkAmount) > 0 ? Number(minedSpkAmount) : 25.0;
    const result = db.executeTestnetHarvestAutoBuy(
      targetAddr,
      numAmount,
      Number(hashrate) || 1.25,
      Number(slippageTolerance) || 0.2,
      txHash
    );
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error executing harvest auto-buy' });
  }
});

app.post('/api/testnet/swap', (req: Request, res: Response) => {
  try {
    const { address, fromToken, toToken, amountIn } = req.body;
    const result = db.executeTestnetSwap(address, fromToken, toToken, Number(amountIn));
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error executing testnet swap' });
  }
});

app.get('/api/testnet/transactions', (req: Request, res: Response) => {
  try {
    const address = req.query.address as string | undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
    const txs = db.getTestnetTransactions(address, limit);
    res.json({ success: true, transactions: txs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Server error fetching testnet transactions' });
  }
});

app.get('/api/bsc/balances/:address', async (req: Request, res: Response) => {
  const address = (req.params.address || '').trim();
  if (!address.startsWith('0x') || address.length < 10) {
    res.status(400).json({ success: false, error: 'Invalid wallet address' });
    return;
  }

  const cleanAddr = address.toLowerCase().replace(/^0x/, '').padStart(64, '0');
  const dataPayload = '0x70a08231' + cleanAddr;

  try {
    const [rawSpikeHex, rawUsdtHex, rawBnbHex] = await Promise.all([
      callBscRpcNode('eth_call', [{ to: SPIKE_CONTRACT_BSC, data: dataPayload }, 'latest']),
      callBscRpcNode('eth_call', [{ to: USDT_CONTRACT_BSC, data: dataPayload }, 'latest']),
      callBscRpcNode('eth_getBalance', [address, 'latest']),
    ]);

    const spikeBalance = formatTokenDecimals(rawSpikeHex, 18);
    const usdtBalance = formatTokenDecimals(rawUsdtHex, 18);
    const bnbBalance = formatTokenDecimals(rawBnbHex, 18);

    res.json({
      success: true,
      address,
      contracts: {
        spike: SPIKE_CONTRACT_BSC,
        usdt: USDT_CONTRACT_BSC,
      },
      balances: {
        spike: spikeBalance,
        usdt: usdtBalance,
        bnb: bnbBalance,
      },
      raw: {
        spikeHex: rawSpikeHex,
        usdtHex: rawUsdtHex,
        bnbHex: rawBnbHex,
      },
      network: 'Binance Smart Chain (BSC Mainnet)',
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err?.message || 'Error querying BSC RPC',
    });
  }
});

// ============================================================
// STATIC & FRONTEND SPA SERVING
// ============================================================
async function startServer() {
  // 1. Initial State Hydration from Cloud Firestore: Ensures spikenodes.com and *.run.app share 100% identical data
  try {
    console.log('[FIREBASE] Synchronizing data from shared Cloud Firestore database...');
    const syncRes = await loadFirestoreDataIntoDb(db);
    console.log(`[FIREBASE] Hydration completed: ${syncRes.usersLoaded} users, ${syncRes.referralsLoaded} referrals, ${syncRes.nodesLoaded} nodes, ${syncRes.transactionsLoaded} transactions synchronized.`);
  } catch (err) {
    console.warn('[FIREBASE] Startup hydration notice (using persistent local cache):', err);
  }

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`SPIKE Full-Stack Server running at http://0.0.0.0:${PORT}`);
    console.log(`[DB] Persistent Database connected at .data/spike_database.json`);
    console.log(`[ADMIN] Admin API routes live at /api/admin/*`);
    console.log(`[FIREBASE] Cloud Firestore connected: ${firebaseConfig?.projectId || 'active'}`);
    console.log(`[CLOUDSQL] PostgreSQL Relational Database (Drizzle ORM) active`);
    console.log(`[MAINNET] Clean baseline active: Treasury $0.00, Master Creator authenticated.`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`[Server] Port ${PORT} busy, waiting 500ms before retrying...`);
      setTimeout(() => {
        try {
          server.close();
        } catch {}
        server.listen(PORT, '0.0.0.0');
      }, 500);
    } else {
      console.error('[Server Error]:', err);
    }
  });
}

startServer();
