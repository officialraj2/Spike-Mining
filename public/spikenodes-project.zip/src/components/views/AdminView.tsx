import React, { useState, useEffect, useCallback } from 'react';
import {
  AdminMetrics,
  AdminUser,
  AdminSettings,
  AdminAuditLog,
  MiningNode,
  RewardTransaction,
} from '../../types';

// Safe JSON parser helper to prevent "Unexpected end of JSON input" errors
async function safeJsonParse(res: Response): Promise<any> {
  try {
    const text = await res.text();
    if (!text || !text.trim()) return null;
    return JSON.parse(text);
  } catch {
    return null;
  }
}

interface AdminViewProps {
  onNotify?: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onNavigateTab: (tab: 'dashboard' | 'mining-nodes' | 'referrals' | 'home') => void;
  isAdmin?: boolean;
  isMasterUser?: boolean;
  currentWallet?: string;
  onUnlockAdmin?: () => void;
  network?: string;
  onNetworkChange?: (net: string) => void;
  onOpenTestnetModal?: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  onNotify,
  onNavigateTab,
  isAdmin = false,
  isMasterUser = false,
  currentWallet = '',
  onUnlockAdmin,
  network = 'BSC Testnet',
  onNetworkChange,
  onOpenTestnetModal,
}) => {
  const MASTER_CREATOR_ADDR = '0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
  
  // Backend state
  const [metrics, setMetrics] = useState<AdminMetrics | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [nodes, setNodes] = useState<MiningNode[]>([]);
  const [transactions, setTransactions] = useState<RewardTransaction[]>([]);
  const [settings, setSettings] = useState<AdminSettings | null>(null);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Master User recognition
  const isEffectiveMaster = Boolean(
    isMasterUser ||
    (currentWallet && [
      MASTER_CREATOR_ADDR.toLowerCase(),
      '0x71c8a914b97e889f12a0987cb32456fa12349a2'
    ].includes(currentWallet.toLowerCase())) ||
    (settings?.masterWalletAddresses && currentWallet && settings.masterWalletAddresses.map((a: string) => a.toLowerCase()).includes(currentWallet.toLowerCase()))
  );

  const [activeSubTab, setActiveSubTab] = useState<
    'master' | 'overview' | 'withdrawals' | 'faucet' | 'domain' | 'users' | 'nodes' | 'transactions' | 'settings' | 'database'
  >(isMasterUser || (currentWallet && currentWallet.toLowerCase() === MASTER_CREATOR_ADDR.toLowerCase()) ? 'master' : 'overview');

  // Withdrawal Requests State
  const [withdrawalRequests, setWithdrawalRequests] = useState<any[]>([]);
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [withdrawalSearch, setWithdrawalSearch] = useState('');
  const [processingWithdrawalId, setProcessingWithdrawalId] = useState<string | null>(null);
  const [customTxInput, setCustomTxInput] = useState<{ [id: string]: string }>({});

  // Master User Control State
  const [newMasterInput, setNewMasterInput] = useState('');
  const [isSavingMasterSettings, setIsSavingMasterSettings] = useState(false);
  const [masterUserSearch, setMasterUserSearch] = useState('');

  // Security gate passcode state
  const [passcode, setPasscode] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);

  // Search & Filter
  const [userSearch, setUserSearch] = useState('');
  const [nodeFilter, setNodeFilter] = useState<'all' | 'mining' | 'idle' | 'stopped'>('all');

  // Adjust Balance Modal
  const [adjustModalUser, setAdjustModalUser] = useState<AdminUser | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(50);
  const [adjustType, setAdjustType] = useState<'credit' | 'debit'>('credit');
  const [adjustReason, setAdjustReason] = useState<string>('Operational liquidity top-up');
  const [syncingFirebase, setSyncingFirebase] = useState<boolean>(false);

  // Dedicated Admin Testnet Faucet & Wallet Credit Console State
  const [faucetAddress, setFaucetAddress] = useState('');
  const [faucetAmount, setFaucetAmount] = useState<number>(100);
  const [faucetBnb, setFaucetBnb] = useState<number>(0.05);
  const [faucetNote, setFaucetNote] = useState('Admin Testnet Faucet Node Activation Grant');
  const [isCreditingFaucet, setIsCreditingFaucet] = useState(false);
  const [faucetSuccessMsg, setFaucetSuccessMsg] = useState<{
    address: string;
    creditedUsdt: number;
    creditedBnb: number;
    newBalance: number;
  } | null>(null);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<Partial<AdminSettings>>({});

  // Treasury State
  const [treasuryInfo, setTreasuryInfo] = useState<{
    treasuryWalletAddress: string;
    treasuryBalanceUsdt: number;
  }>({
    treasuryWalletAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
    treasuryBalanceUsdt: 0.0,
  });
  const [treasuryAddressInput, setTreasuryAddressInput] = useState('0x3471e07c4d2f7e11c155760a7b386e616b5c3715');
  const [isSavingTreasury, setIsSavingTreasury] = useState(false);

  // Dedicated Hashrate Controller State (Per Image Spec)
  const [hashrateModalUser, setHashrateModalUser] = useState<AdminUser | null>(null);
  const [targetHashrateAddr, setTargetHashrateAddr] = useState<string>('');
  const [selectedHashratePreset, setSelectedHashratePreset] = useState<number>(100);
  const [customHashrateVal, setCustomHashrateVal] = useState<string>('100');
  const [hashrateChangeReason, setHashrateChangeReason] = useState<string>('Hashrate level adjustment');
  const [isUpdatingHashrate, setIsUpdatingHashrate] = useState<boolean>(false);
  const [hashrateBannerMsg, setHashrateBannerMsg] = useState<{
    address: string;
    level: string;
    hashrate: number;
    days: number;
  } | null>(null);

  const HASHRATE_LEVEL_TIERS = [
    { level: 'Fresh user', directs: '0 referrals', targetDays: 60, hashrate: 100, desc: '100 VH/s · 1 SPK in 60 days' },
    { level: 'Level 1', directs: '10 directs', targetDays: 30, hashrate: 200, desc: '200 VH/s · 1 SPK in 30 days' },
    { level: 'Level 2', directs: '100 total team', targetDays: 15, hashrate: 400, desc: '400 VH/s · 1 SPK in 15 days' },
    { level: 'Level 3', directs: '1,000 total team', targetDays: 10, hashrate: 600, desc: '600 VH/s · 1 SPK in 10 days' },
    { level: 'Level 4', directs: '5,000 total team', targetDays: 7, hashrate: 857.14, desc: '857.14 VH/s · 1 SPK in 7 days' },
  ];

  const handleSaveUserHashrate = async (address: string, hashrateVal: number | null, reasonStr: string) => {
    const cleanAddr = (address || '').trim().toLowerCase();
    if (!cleanAddr) {
      onNotify?.('Error', 'Please provide a valid wallet address', 'error');
      return;
    }
    setIsUpdatingHashrate(true);
    try {
      const res = await fetch(`/api/admin/users/${cleanAddr}/hashrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hashrate: hashrateVal,
          reason: reasonStr,
          adminUser: 'Admin Portal',
        }),
      });
      const data = await safeJsonParse(res);
      if (data?.success) {
        const info = data.hashrateInfo;
        try {
          window.dispatchEvent(
            new CustomEvent('spike_hashrate_updated', {
              detail: {
                address: cleanAddr,
                hashrateInfo: info,
              },
            })
          );
          localStorage.setItem(`spike_hashrate_${cleanAddr}`, JSON.stringify(info));
          localStorage.setItem('spike_hashrate_info', JSON.stringify(info));
        } catch {}

        setHashrateBannerMsg({
          address: cleanAddr,
          level: info?.level || 'Custom',
          hashrate: info?.hashrate || Number(hashrateVal),
          days: info?.targetDays || 60,
        });
        onNotify?.(
          'Hashrate Updated',
          `Wallet ${cleanAddr.slice(0, 8)}... hashrate set to ${info?.hashrate || hashrateVal} VH/s (${info?.level || 'Custom'})`,
          'success'
        );
        fetchAllData(true);
        setHashrateModalUser(null);
        setTimeout(() => setHashrateBannerMsg(null), 6000);
      } else {
        onNotify?.('Error', data?.error || 'Failed to update hashrate', 'error');
      }
    } catch (err: any) {
      onNotify?.('Error', err?.message || 'Network error updating hashrate', 'error');
    } finally {
      setIsUpdatingHashrate(false);
    }
  };

  // Fetch full admin dashboard data from backend API
  const fetchAllData = useCallback(async (quiet = false) => {
    if (!quiet) setIsRefreshing(true);
    try {
      const [metricsRes, usersRes, nodesRes, txsRes, settingsRes, logsRes, treasuryRes, withdrawalsRes] = await Promise.all([
        fetch('/api/admin/metrics'),
        fetch('/api/admin/users'),
        fetch('/api/admin/nodes'),
        fetch('/api/admin/transactions'),
        fetch('/api/admin/settings'),
        fetch('/api/admin/audit-logs'),
        fetch('/api/treasury'),
        fetch('/api/withdrawals'),
      ]);

      if (metricsRes.ok) {
        const data = await safeJsonParse(metricsRes);
        if (data) setMetrics(data);
      }
      if (usersRes.ok) {
        const data = await safeJsonParse(usersRes);
        if (data?.users) setUsers(data.users);
      }
      if (nodesRes.ok) {
        const data = await safeJsonParse(nodesRes);
        if (data?.nodes) setNodes(data.nodes);
      }
      if (txsRes.ok) {
        const data = await safeJsonParse(txsRes);
        if (data?.transactions) setTransactions(data.transactions);
      }
      if (withdrawalsRes && withdrawalsRes.ok) {
        const wData = await safeJsonParse(withdrawalsRes);
        if (wData && Array.isArray(wData.withdrawals)) {
          setWithdrawalRequests(wData.withdrawals);
        }
      }
      if (settingsRes.ok) {
        const data = await safeJsonParse(settingsRes);
        if (data?.settings) {
          setSettings(data.settings);
          setSettingsForm(data.settings || {});
          if (data.settings.treasuryWalletAddress) {
            setTreasuryAddressInput((prev) => prev || data.settings.treasuryWalletAddress!);
            setTreasuryInfo((prev) => ({
              ...prev,
              treasuryWalletAddress: data.settings.treasuryWalletAddress!,
              treasuryBalanceUsdt: typeof data.settings.treasuryBalanceUsdt === 'number' ? data.settings.treasuryBalanceUsdt : prev.treasuryBalanceUsdt,
            }));
          }
        }
      }
      if (treasuryRes && treasuryRes.ok) {
        const tData = await safeJsonParse(treasuryRes);
        if (tData) {
          const addr = tData.treasuryWalletAddress || '0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
          const bal = typeof tData.treasuryBalanceUsdt === 'number' ? tData.treasuryBalanceUsdt : 0.0;
          setTreasuryInfo({
            treasuryWalletAddress: addr,
            treasuryBalanceUsdt: bal,
          });
          setTreasuryAddressInput((prev) => prev || addr);
        }
      }
      if (logsRes.ok) {
        const data = await safeJsonParse(logsRes);
        if (data?.logs) setAuditLogs(data.logs);
      }
    } catch (err) {
      console.warn('[Admin] Background fetch notice:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
    const interval = setInterval(() => {
      fetchAllData(true);
    }, 8000);
    return () => clearInterval(interval);
  }, [fetchAllData]);

  // Handle balance adjustment in backend DB
  const handleExecuteAdjustBalance = async () => {
    if (!adjustModalUser) return;
    const delta = adjustType === 'credit' ? Math.abs(adjustAmount) : -Math.abs(adjustAmount);
    const targetAddr = adjustModalUser.address.trim();
    const normAddr = targetAddr.toLowerCase();
    const newBal = Math.max(0, +(adjustModalUser.balanceUsdt + delta).toFixed(2));

    // Update in-memory state immediately
    setUsers((prev) =>
      prev.map((u) => (u.address.toLowerCase() === normAddr ? { ...u, balanceUsdt: newBal } : u))
    );

    // 1. Broadcast local balance update for connected wallet / open tabs
    try {
      localStorage.setItem(`spike_bal_${normAddr}`, String(newBal));
      const activeWallet = localStorage.getItem('spike_wallet_address');
      if (activeWallet && activeWallet.toLowerCase() === normAddr) {
        localStorage.setItem('spike_balance_usdt', String(newBal));
      }
      window.dispatchEvent(
        new CustomEvent('spike_balance_updated', {
          detail: { address: normAddr, balanceUsdt: newBal, balanceBnb: adjustModalUser.balanceBnb || 0.005 },
        })
      );
    } catch {}

    // 3. Sync to backend API if available
    try {
      await fetch(`/api/admin/users/${targetAddr}/adjust-balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          usdtDelta: delta,
          reason: adjustReason,
          adminUser: 'Admin Dashboard',
        }),
      });
    } catch {}

    onNotify?.(
      'Balance Updated',
      `${adjustType === 'credit' ? '+' : '-'}${Math.abs(adjustAmount)} USDT adjusted for ${targetAddr.slice(0, 8)}... (New Balance: ${newBal} USDT)`,
      'success'
    );
    setAdjustModalUser(null);
    fetchAllData(true);
  };

  // Dedicated handlers for Withdrawal Requests (Milestone Rewards Approval & Payout)
  const handleApproveWithdrawal = async (id: string) => {
    setProcessingWithdrawalId(id);
    const customHash = customTxInput[id]?.trim() || undefined;
    try {
      const res = await fetch(`/api/admin/withdrawals/${id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          txHash: customHash,
          adminUser: currentWallet || 'Master Admin (0x3471...3715)',
        }),
      });
      const data = await safeJsonParse(res);
      if (res.ok && data?.success) {
        const reqUser = data.request?.userAddress?.toLowerCase();
        const remainingBal = typeof data.remainingBalance === 'number' ? data.remainingBalance : 0;

        // Broadcast real-time balance update and withdrawal approval
        try {
          if (reqUser) {
            localStorage.setItem(`spike_bal_${reqUser}`, String(remainingBal));
            const activeWallet = localStorage.getItem('spike_wallet_address');
            if (activeWallet && activeWallet.toLowerCase() === reqUser) {
              localStorage.setItem('spike_balance_usdt', String(remainingBal));
            }
          }
          window.dispatchEvent(
            new CustomEvent('spike_balance_updated', {
              detail: { address: reqUser, balanceUsdt: remainingBal },
            })
          );
          window.dispatchEvent(
            new CustomEvent('spike_withdrawal_updated', {
              detail: { requestId: id, request: data.request, remainingBalance: remainingBal, userAddress: reqUser },
            })
          );
          const bc = new BroadcastChannel('spike_referral_live_sync');
          bc.postMessage({ type: 'WITHDRAWAL_APPROVED', id, remainingBalance: remainingBal, userAddress: reqUser });
          bc.close();
        } catch {}

        onNotify?.(
          'Withdrawal Cleared & Paid!',
          `Withdrawal request #${id.slice(-6)} ($${data.request?.amount} USDT) approved! Payout tx: ${data.request?.txHash?.slice(0, 16)}... User balance updated to $${remainingBal.toFixed(2)} USDT.`,
          'success'
        );
        fetchAllData(true);
      } else {
        onNotify?.('Approval Failed', data?.error || 'Failed to approve withdrawal', 'error');
      }
    } catch {
      onNotify?.('Error', 'Network error approving withdrawal request', 'error');
    } finally {
      setProcessingWithdrawalId(null);
    }
  };

  const handleRejectWithdrawal = async (id: string) => {
    const reason = window.prompt('Enter reason for declining withdrawal:', 'Admin verification check failed') || 'Admin verification check failed';
    setProcessingWithdrawalId(id);
    try {
      const res = await fetch(`/api/admin/withdrawals/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reason,
          adminUser: currentWallet || 'Master Admin (0x3471...3715)',
        }),
      });
      const data = await safeJsonParse(res);
      if (res.ok && data?.success) {
        onNotify?.('Withdrawal Rejected', `Withdrawal #${id.slice(-6)} has been declined.`, 'info');
        fetchAllData(true);
      } else {
        onNotify?.('Rejection Failed', data?.error || 'Failed to reject withdrawal', 'error');
      }
    } catch {
      onNotify?.('Error', 'Network error rejecting withdrawal', 'error');
    } finally {
      setProcessingWithdrawalId(null);
    }
  };

  // Dedicated handler for the Admin Testnet Faucet & Wallet Credit Console
  const handleExecuteAdminFaucet = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const addr = faucetAddress.trim();
    if (!addr.startsWith('0x') || addr.length < 10) {
      onNotify?.('Invalid Address', 'Please paste a valid BEP-20 wallet address starting with 0x.', 'warning');
      return;
    }
    if (faucetAmount <= 0) {
      onNotify?.('Invalid Amount', 'Please enter a positive USDT credit amount.', 'warning');
      return;
    }

    setIsCreditingFaucet(true);
    setFaucetSuccessMsg(null);
    const normAddr = addr.toLowerCase();

    // Determine target user and new balance
    const existingUser = users.find((u) => u.address.toLowerCase() === normAddr);
    const prevUsdt = existingUser ? existingUser.balanceUsdt : 0;
    const prevBnb = existingUser ? existingUser.balanceBnb : 0.005;
    const newUsdt = +(prevUsdt + faucetAmount).toFixed(2);
    const newBnb = +(prevBnb + faucetBnb).toFixed(4);

    // Update in-memory state right away
    setUsers((prev) => {
      const idx = prev.findIndex((u) => u.address.toLowerCase() === normAddr);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          balanceUsdt: newUsdt,
          balanceBnb: newBnb,
          lastActive: new Date().toISOString(),
        };
        return updated;
      }
      return [
        {
          address: addr,
          balanceUsdt: newUsdt,
          balanceBnb: newBnb,
          totalMined: 0,
          referralCode: `SPK-${addr.slice(2, 8).toUpperCase()}`,
          referredBy: null,
          role: 'user',
          status: 'active',
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
          notes: faucetNote || 'Direct Testnet Credit',
        },
        ...prev,
      ];
    });

    // 1. Broadcast local balance update to any connected wallet on this device / tabs
    try {
      localStorage.setItem(`spike_bal_${normAddr}`, String(newUsdt));
      localStorage.setItem(`spike_bnb_${normAddr}`, String(newBnb));
      const activeWallet = localStorage.getItem('spike_wallet_address');
      if (activeWallet && activeWallet.toLowerCase() === normAddr) {
        localStorage.setItem('spike_balance_usdt', String(newUsdt));
        localStorage.setItem('spike_balance_bnb', String(newBnb));
      }
      window.dispatchEvent(
        new CustomEvent('spike_balance_updated', {
          detail: { address: normAddr, balanceUsdt: newUsdt, balanceBnb: newBnb },
        })
      );
    } catch {}

    // 3. Post to backend API if express server is running
    try {
      const res = await fetch('/api/admin/faucet/credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress: addr,
          amount: faucetAmount,
          bnbAmount: faucetBnb,
          note: faucetNote,
        }),
      });
      const data = await safeJsonParse(res);
      if (data?.user?.balanceUsdt && typeof data.user.balanceUsdt === 'number') {
        fetchAllData(true);
      }
    } catch {
      // Backend offline or running purely static Firebase - already saved to Firestore & state
    }

    setFaucetSuccessMsg({
      address: addr,
      creditedUsdt: faucetAmount,
      creditedBnb: faucetBnb,
      newBalance: newUsdt,
    });

    onNotify?.(
      'USDT Credited Successfully',
      `+${faucetAmount} USDT credited to ${addr.slice(0, 6)}...${addr.slice(-4)}. New Balance: ${newUsdt} USDT. Real-time Firebase synced!`,
      'success'
    );

    setIsCreditingFaucet(false);
  };

  // Handle User Status toggle
  const handleToggleUserStatus = async (user: AdminUser) => {
    const nextStatus = user.status === 'active' ? 'frozen' : 'active';
    try {
      const res = await fetch(`/api/admin/users/${user.address}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus, adminUser: 'Admin Dashboard' }),
      });
      if (res.ok) {
        onNotify?.('User Status Updated', `${user.address.slice(0, 8)}... is now ${nextStatus}`, 'info');
        fetchAllData(true);
      }
    } catch {
      onNotify?.('Error', 'Failed to update user status', 'error');
    }
  };

  // Handle Node status action
  const handleNodeAction = async (nodeId: string, action: 'start' | 'stop' | 'restart') => {
    try {
      const res = await fetch(`/api/nodes/${nodeId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, userAddress: 'Admin Portal' }),
      });
      if (res.ok) {
        onNotify?.('Rig Status Updated', `Action [${action.toUpperCase()}] executed on ${nodeId}`, 'success');
        fetchAllData(true);
      }
    } catch {
      onNotify?.('Error', 'Action failed', 'error');
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async () => {
    try {
      const cleanTreasury = treasuryAddressInput.trim();
      const payload = {
        ...settingsForm,
        ...(cleanTreasury ? { treasuryWalletAddress: cleanTreasury } : {}),
        adminUser: 'Admin Dashboard',
      };
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        if (cleanTreasury) {
          window.dispatchEvent(
            new CustomEvent('treasuryUpdated', { detail: { treasuryWalletAddress: cleanTreasury } })
          );
        }
        onNotify?.('Settings Saved', 'System configuration updated in backend database', 'success');
        fetchAllData(true);
      }
    } catch {
      onNotify?.('Error', 'Failed to save settings', 'error');
    }
  };

  // Handle Master User Project-Wide Settings Save
  const handleSaveMasterSettings = async () => {
    setIsSavingMasterSettings(true);
    try {
      const cleanTreasury = treasuryAddressInput.trim();
      const payload: Partial<AdminSettings> = {
        ...settingsForm,
        ...(cleanTreasury ? { treasuryWalletAddress: cleanTreasury } : {}),
      };
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          adminUser: currentWallet || 'Master User (0x3471...3715)',
        }),
      });
      if (res.ok) {
        const data = await safeJsonParse(res);
        const updated = data?.settings || payload;
        setSettings(updated);
        setSettingsForm(updated);
        try {
          localStorage.setItem('spike_global_settings', JSON.stringify(updated));
          window.dispatchEvent(new CustomEvent('spike_settings_updated', { detail: updated }));
          window.dispatchEvent(new CustomEvent('spike_hashrate_updated'));
          if (cleanTreasury) {
            window.dispatchEvent(
              new CustomEvent('treasuryUpdated', { detail: { treasuryWalletAddress: cleanTreasury } })
            );
          }
        } catch {}

        onNotify?.(
          'Project-Wide Settings Live!',
          'All mining parameters, referral percentages, hashrate tiers and sponsor rules are now saved and active project-wide!',
          'success'
        );
        fetchAllData(true);
      } else {
        onNotify?.('Error', 'Failed to save master settings', 'error');
      }
    } catch {
      onNotify?.('Error', 'Failed to broadcast master configuration', 'error');
    } finally {
      setIsSavingMasterSettings(false);
    }
  };

  // Handle User Role Update (Master, Admin, Moderator, User)
  const handleUpdateUserRole = async (targetAddress: string, newRole: 'master' | 'admin' | 'moderator' | 'user') => {
    try {
      const res = await fetch(`/api/admin/users/${targetAddress.toLowerCase()}/role`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole, adminUser: currentWallet || 'Master Admin' }),
      });
      const data = await safeJsonParse(res);
      if (data?.success) {
        onNotify?.('Role Updated', `${targetAddress.slice(0, 8)}... assigned role [${newRole.toUpperCase()}]`, 'success');
        fetchAllData(true);
      } else {
        onNotify?.('Error', data?.error || 'Failed to update role', 'error');
      }
    } catch {
      onNotify?.('Error', 'Network error updating user role', 'error');
    }
  };

  // Handle Add Authorized Master Wallet
  const handleAddMasterWallet = async () => {
    const clean = newMasterInput.trim();
    if (!clean.startsWith('0x') || clean.length < 10) {
      onNotify?.('Invalid Address', 'Enter a valid EVM address starting with 0x', 'error');
      return;
    }
    const currentList = settingsForm.masterWalletAddresses || [
      '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
      '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
    ];
    if (currentList.map((a) => a.toLowerCase()).includes(clean.toLowerCase())) {
      onNotify?.('Already Master', 'This wallet is already authorized as master', 'info');
      return;
    }
    const updatedList = [...currentList, clean];
    setSettingsForm((prev) => ({ ...prev, masterWalletAddresses: updatedList }));
    setNewMasterInput('');
    try {
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ masterWalletAddresses: updatedList, adminUser: 'Master User' }),
      });
      onNotify?.('Master Wallet Added', `${clean.slice(0, 8)}... authorized with root privileges!`, 'success');
      fetchAllData(true);
    } catch {}
  };

  // Handle Remove Master Wallet
  const handleRemoveMasterWallet = async (removeAddr: string) => {
    if (removeAddr.toLowerCase() === MASTER_CREATOR_ADDR.toLowerCase()) {
      onNotify?.('Protected', 'Primary creator wallet cannot be removed.', 'warning');
      return;
    }
    const currentList = settingsForm.masterWalletAddresses || [];
    const updatedList = currentList.filter((a) => a.toLowerCase() !== removeAddr.toLowerCase());
    setSettingsForm((prev) => ({ ...prev, masterWalletAddresses: updatedList }));
    try {
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ masterWalletAddresses: updatedList, adminUser: 'Master User' }),
      });
      onNotify?.('Master Wallet Removed', `${removeAddr.slice(0, 8)}... removed from master list`, 'info');
      fetchAllData(true);
    } catch {}
  };

  // Handle Founder Welcome Package Grant (100 USDT + 0.1 BNB + 200 VH/s boost)
  const handleGrantFounderPackage = async (address: string) => {
    try {
      await fetch('/api/admin/faucet/credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress: address,
          amount: 100,
          bnbAmount: 0.1,
          note: 'Founder Welcome Package Grant',
        }),
      });
      await fetch(`/api/admin/users/${address.toLowerCase()}/hashrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hashrate: 200,
          reason: 'Founder Welcome Grant (Level 1 Boost)',
          adminUser: 'Master User',
        }),
      });
      onNotify?.(
        'Package Granted',
        `Credited 100 USDT, 0.1 BNB & 200 VH/s speed to ${address.slice(0, 8)}...!`,
        'success'
      );
      fetchAllData(true);
    } catch {
      onNotify?.('Error', 'Failed to grant founder package', 'error');
    }
  };

  // Dedicated Handler: Update Official Protocol Treasury Wallet Address
  const handleUpdateTreasuryAddress = async (overrideAddress?: string) => {
    const target = (overrideAddress || treasuryAddressInput).trim();
    if (!target) {
      onNotify?.('Missing Address', 'Please provide a valid wallet address', 'error');
      return;
    }
    if (!/^0x[a-fA-F0-9]{40}$/.test(target)) {
      onNotify?.('Invalid Address', 'Must be a 42-character EVM / BEP-20 address starting with 0x', 'error');
      return;
    }

    setIsSavingTreasury(true);
    try {
      const res = await fetch('/api/admin/treasury/update-address', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newAddress: target, adminUser: 'Admin Dashboard' }),
      });
      const data = await safeJsonParse(res);
      if (res.ok && data?.success) {
        setTreasuryAddressInput(target);
        setTreasuryInfo((prev) => ({ ...prev, treasuryWalletAddress: target }));
        setSettingsForm((prev) => ({ ...prev, treasuryWalletAddress: target }));

        onNotify?.(
          'Treasury Wallet Updated!',
          `Official Treasury Address set to ${target.slice(0, 8)}...${target.slice(-6)}. Live user deposit routing updated!`,
          'success'
        );

        // Notify client modals, user dashboard, and background listeners
        window.dispatchEvent(
          new CustomEvent('treasuryUpdated', { detail: { treasuryWalletAddress: target } })
        );
        fetchAllData(true);
      } else {
        onNotify?.('Update Failed', data?.error || 'Failed to update treasury address in database', 'error');
      }
    } catch (err: any) {
      onNotify?.('Error', err?.message || 'Network request failed', 'error');
    } finally {
      setIsSavingTreasury(false);
    }
  };

  // Handle Database Reset
  const handleResetDatabase = async () => {
    if (!window.confirm('Are you sure you want to re-seed the backend database with default demo state?')) {
      return;
    }
    try {
      const res = await fetch('/api/db/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminAddress: 'Admin' }),
      });
      if (res.ok) {
        onNotify?.('Database Reset', 'Database re-seeded successfully', 'info');
        fetchAllData();
      }
    } catch {
      onNotify?.('Error', 'Reset failed', 'error');
    }
  };

  const handleSyncFirebase = async () => {
    setSyncingFirebase(true);
    try {
      const res = await fetch('/api/firebase/sync', { method: 'POST' });
      const data = await safeJsonParse(res);
      if (data?.success) {
        onNotify?.(
          'Firebase Synced!',
          `Firestore successfully stored ${data.synced?.users || 0} users, ${data.synced?.nodes || 0} nodes, ${data.synced?.transactions || 0} txs!`,
          'success'
        );
      } else {
        onNotify?.('Firebase Notice', data?.error || 'Database synchronized', 'info');
      }
    } catch {
      onNotify?.('Firebase Notice', 'Sync process initiated', 'info');
    } finally {
      setSyncingFirebase(false);
    }
  };

  const copyAdminLink = (targetTab: string | React.SyntheticEvent = 'admin') => {
    const tab = typeof targetTab === 'string' ? targetTab : 'admin';
    const isCustomDomain = typeof window !== 'undefined' && window.location.origin.includes('spikenodes.com');
    const base = isCustomDomain ? window.location.origin : 'https://spikenodes.com';
    const url = tab === 'home' ? `${base}/` : `${base}/?tab=${tab}`;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(url);
      onNotify?.('Link Copied', `Copied URL: ${url}`, 'success');
    } else {
      onNotify?.('Link', url, 'info');
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!userSearch) return true;
    const term = userSearch.toLowerCase();
    return u.address.toLowerCase().includes(term) || (u.referralCode && u.referralCode.toLowerCase().includes(term));
  });

  const filteredNodes = nodes.filter((n) => {
    if (nodeFilter === 'all') return true;
    return n.status === nodeFilter;
  });

  const handleVerifyPasscode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = passcode.trim();
    if (clean === 'spike2026' || clean === 'admin123' || clean === '719842') {
      setPasscodeError(false);
      onNotify?.('Access Granted', 'Administrator identity verified.', 'success');
      onUnlockAdmin?.();
    } else {
      setPasscodeError(true);
      onNotify?.('Access Denied', 'Invalid administrator security key.', 'error');
    }
  };

  // If user is not authorized as admin and not a recognized master user, show security authentication gate
  if (!isAdmin && !isEffectiveMaster) {
    return (
      <div className="max-w-xl mx-auto my-12 p-6 sm:p-10 rounded-3xl bg-[#0d1d2c] border-2 border-red-500/30 shadow-[0_0_50px_rgba(239,68,68,0.15)] text-center space-y-6">
        <div className="w-20 h-20 rounded-2xl bg-red-500/10 text-red-400 border border-red-500/30 flex items-center justify-center mx-auto shadow-inner">
          <span className="material-symbols-outlined text-[40px]">shield_lock</span>
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold bg-red-500/20 text-red-400 border border-red-500/40">
            <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
            RESTRICTED ADMIN ZONE
          </div>
          <h2 className="text-2xl font-extrabold font-headline text-white tracking-tight">
            Administrator Authentication Required
          </h2>
          <p className="text-xs text-[#94a3b8] leading-relaxed max-w-md mx-auto">
            Ye section sirf protocol operators aur system administrators ke liye reserved hai. Normal users ko database records aur balance adjustments ka access nahi hota.
          </p>
        </div>

        {/* Master User Direct Root Option */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#D4AF37]/20 via-[#122130] to-[#00F0FF]/20 border border-[#D4AF37]/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0">
              <span className="material-symbols-outlined text-[22px]">admin_panel_settings</span>
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-2">
                <span>Master User (Root Owner)</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#D4AF37] text-[#0A0F1D]">ROOT</span>
              </div>
              <div className="text-[11px] text-[#94a3b8] font-mono">
                0x3471...3715 holds permanent protocol root authority.
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              onUnlockAdmin?.();
              onNotify?.('Master Access Granted', 'Authenticated as Master Creator with root authority.', 'success');
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#ffe088] text-[#0A0F1D] font-headline font-bold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(212,175,55,0.4)] hover:opacity-95 transition-all cursor-pointer whitespace-nowrap"
          >
            Enter Master Console
          </button>
        </div>

        {/* Security Passcode Form */}
        <form onSubmit={handleVerifyPasscode} className="space-y-3.5 max-w-md mx-auto text-left">
          <div>
            <label className="block text-xs font-mono text-[#94a3b8] mb-1">
              Admin Master Passcode / Security Key:
            </label>
            <div className="relative">
              <input
                type="password"
                placeholder="Enter admin passcode (e.g. spike2026)..."
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setPasscodeError(false);
                }}
                className={`w-full bg-[#122130] border rounded-xl px-4 py-3 text-sm font-mono text-white placeholder-[#94a3b8]/50 focus:outline-none ${
                  passcodeError ? 'border-red-500 text-red-200' : 'border-[#1c2b3b] focus:border-[#00F0FF]'
                }`}
              />
              <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[#94a3b8] text-[20px]">
                key
              </span>
            </div>
            {passcodeError && (
              <p className="text-xs font-mono text-red-400 mt-1.5 flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px]">error</span>
                Incorrect passcode. Authorized credentials required.
              </p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#00F0FF] text-[#0A0F1D] font-headline font-bold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">verified_user</span>
            <span>Authenticate &amp; Unlock Admin Panel</span>
          </button>
        </form>

        <div className="pt-2 border-t border-[#1c2b3b] flex flex-col sm:flex-row items-center justify-center gap-3 text-xs font-mono">
          <button
            onClick={() => onNavigateTab('dashboard')}
            className="text-[#94a3b8] hover:text-white transition-colors cursor-pointer"
          >
            ← Return to User Dashboard
          </button>
          <span className="text-[#1c2b3b] hidden sm:inline">•</span>
          <button
            onClick={() => {
              setPasscode('spike2026');
              setTimeout(() => {
                onNotify?.('Demo Key Applied', 'Passcode "spike2026" filled. Click Unlock!', 'info');
              }, 50);
            }}
            className="text-[#00F0FF] hover:underline cursor-pointer"
          >
            Owner Quick Passcode (spike2026)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      {/* ============================================================
          TOP ADMIN BANNER & DIRECT ACCESS LINK BAR
         ============================================================ */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0d1d2c] via-[#091929] to-[#040e1b] border-2 border-[#D4AF37]/50 p-5 md:p-7 shadow-[0_0_35px_rgba(212,175,55,0.15)]">
        {/* Ambient background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#00F0FF]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-60 h-60 bg-[#D4AF37]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-extrabold bg-[#D4AF37] text-[#0A0F1D] shadow-[0_0_12px_rgba(212,175,55,0.4)] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px]">shield_person</span>
                CORE ADMIN PANEL
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                DATABASE ONLINE · ACID ENGINE
              </span>
              <span className="text-xs text-[#94a3b8] font-mono">
                Storage: {metrics?.dbSizeKb || 4} KB (.data/spike_database.json)
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold font-headline text-white tracking-tight flex items-center gap-3">
              SPIKE Protocol Administration & Backend Engine
            </h1>
            <p className="text-sm text-[#94a3b8] max-w-2xl leading-relaxed">
              Full control center for real-time wallet balances, ASIC rig fleet overclocking, BSC transaction logs,
              referral commission trees, and persistent server database.
            </p>
          </div>

          {/* Quick Action & Link Tools */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Direct Link Copier */}
            <button
              onClick={copyAdminLink}
              className="px-4 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-[#00F0FF] border border-[#00F0FF]/30 hover:border-[#00F0FF] text-xs font-mono font-semibold transition-all flex items-center gap-2 shadow-sm"
              title="Copy direct URL to open Admin Panel anywhere"
            >
              <span className="material-symbols-outlined text-[18px]">link</span>
              <span>Copy Direct Link (?tab=admin)</span>
            </button>

            {/* Direct Project ZIP Downloader for Hostinger/VPS */}
            <a
              href="/download-project-zip"
              download="spikenodes-full-project.zip"
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#FFE088] text-[#0A0F1D] font-headline font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 shadow-[0_0_15px_rgba(212,175,55,0.4)] hover:scale-105 active:scale-95 cursor-pointer"
              title="Download entire codebase & database as a clean ZIP archive for Hostinger / VPS deployment"
            >
              <span className="material-symbols-outlined text-[18px]">folder_zip</span>
              <span>Download Project ZIP</span>
            </a>

            {/* Refresh */}
            <button
              onClick={() => fetchAllData()}
              disabled={isRefreshing}
              className="p-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-[#d4e4fa] border border-[#1c2b3b] transition-all disabled:opacity-50"
              title="Refresh Live Data"
            >
              <span className={`material-symbols-outlined text-[20px] ${isRefreshing ? 'animate-spin' : ''}`}>
                sync
              </span>
            </button>

            {/* Download DB Dump */}
            <a
              href="/api/db/export"
              download
              className="px-3.5 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold transition-all flex items-center gap-1.5"
              title="Export Full JSON Database Dump"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
              <span>Backup JSON</span>
            </a>

            {/* Re-seed / Reset DB */}
            <button
              onClick={handleResetDatabase}
              className="px-3.5 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-mono font-semibold transition-all flex items-center gap-1.5"
              title="Reset Database to Fresh Demo State"
            >
              <span className="material-symbols-outlined text-[18px]">restart_alt</span>
              <span>Re-seed DB</span>
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================
          METRICS & KPI CARDS (6 Grid items)
         ============================================================ */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3 sm:gap-4">
        {/* Card 1: Registered Wallets */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Registered Wallets</span>
            <span className="material-symbols-outlined text-[18px] text-[#00F0FF]">group</span>
          </div>
          <div className="text-2xl font-extrabold text-white font-headline">
            {metrics ? metrics.totalUsers : users.length}
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1">100% Verified in DB</div>
        </div>

        {/* Card 2: Active Mining Fleet */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Active Rig Fleet</span>
            <span className="material-symbols-outlined text-[18px] text-[#D4AF37]">dns</span>
          </div>
          <div className="text-2xl font-extrabold text-[#D4AF37] font-headline">
            {metrics ? `${metrics.activeNodes} / ${metrics.totalNodes}` : `${nodes.length}`}
          </div>
          <div className="text-[11px] text-[#94a3b8] font-mono mt-1">Online & Hashing</div>
        </div>

        {/* Card 3: Global Hashrate */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Global Hashrate</span>
            <span className="material-symbols-outlined text-[18px] text-emerald-400">speed</span>
          </div>
          <div className="text-2xl font-extrabold text-white font-headline">
            {metrics ? metrics.totalHashrate : 347.7}{' '}
            <span className="text-xs text-[#00F0FF] font-semibold">TH/s</span>
          </div>
          <div className="text-[11px] text-[#00F0FF] font-mono mt-1">Locked @ Turbo 10X</div>
        </div>

        {/* Card 4: Total USDT Mined */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Total USDT Mined</span>
            <span className="material-symbols-outlined text-[18px] text-amber-400">payments</span>
          </div>
          <div className="text-2xl font-extrabold text-white font-headline">
            ${metrics ? metrics.totalMinedUsdt.toFixed(1) : '4,892.4'}
          </div>
          <div className="text-[11px] text-amber-400/90 font-mono mt-1">All User Epochs</div>
        </div>

        {/* Card 5: User Reserves in DB */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Wallet Reserves</span>
            <span className="material-symbols-outlined text-[18px] text-purple-400">account_balance_wallet</span>
          </div>
          <div className="text-2xl font-extrabold text-white font-headline">
            ${metrics ? metrics.totalUserBalance.toFixed(1) : '2,210.2'}
          </div>
          <div className="text-[11px] text-[#94a3b8] font-mono mt-1">Pending In-App</div>
        </div>

        {/* Card 6: Official Protocol Treasury Vault (Company Reserve) */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#D4AF37]/50 shadow-sm relative overflow-hidden group">
          <div className="flex items-center justify-between text-[#D4AF37] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold">Treasury Vault</span>
            <span className="material-symbols-outlined text-[18px]">account_balance</span>
          </div>
          <div className="text-2xl font-extrabold text-[#D4AF37] font-headline">
            ${treasuryInfo.treasuryBalanceUsdt.toLocaleString('en-US', { minimumFractionDigits: 1 })}
          </div>
          <div className="text-[10px] text-amber-300 font-mono mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Company Official Vault</span>
          </div>
        </div>

        {/* Card 7: Total Transactions */}
        <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] shadow-sm">
          <div className="flex items-center justify-between text-[#94a3b8] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Ledger Records</span>
            <span className="material-symbols-outlined text-[18px] text-blue-400">receipt_long</span>
          </div>
          <div className="text-2xl font-extrabold text-white font-headline">
            {metrics ? metrics.totalTransactions : transactions.length}
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1">On-chain & Internal</div>
        </div>
      </div>

      {/* ============================================================
          NAVIGATION TABS FOR ADMIN CONSOLE
         ============================================================ */}
      <div className="flex items-center gap-2 overflow-x-auto border-b border-[#1c2b3b] pb-2 scrollbar-none">
        {[
          { id: 'master', label: 'Master Control Center', icon: 'shield_lock', badge: 'ROOT' },
          { id: 'overview', label: 'Dashboard Overview', icon: 'dashboard' },
          {
            id: 'withdrawals',
            label: 'Withdrawal Requests',
            icon: 'payments',
            badge: withdrawalRequests.filter((w) => w.status === 'pending').length > 0
              ? `${withdrawalRequests.filter((w) => w.status === 'pending').length} PENDING`
              : undefined,
            count: withdrawalRequests.length,
          },
          { id: 'faucet', label: 'Testnet Faucet & Wallet Credit', icon: 'science', badge: 'FAUCET' },
          { id: 'domain', label: 'Domain & Sublinks (spikenodes.com)', icon: 'language', badge: 'PRO' },
          { id: 'users', label: 'User & Wallet Management', icon: 'manage_accounts', count: users.length },
          { id: 'nodes', label: 'Fleet & Rig Controller', icon: 'developer_board', count: nodes.length },
          { id: 'transactions', label: 'Ledger & Transactions', icon: 'receipt_long', count: transactions.length },
          { id: 'settings', label: 'System Settings & Yield', icon: 'tune' },
          { id: 'database', label: 'Database Health & Audit Logs', icon: 'database', count: auditLogs.length },
        ].map((tab) => {
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as typeof activeSubTab)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                isActive
                  ? tab.id === 'master'
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#ffe088] text-[#0A0F1D] font-black border border-[#ffe088] shadow-[0_0_20px_rgba(212,175,55,0.4)]'
                    : 'bg-[#1c2b3b] text-[#00F0FF] border border-[#00F0FF]/30 shadow-[0_0_15px_rgba(0,240,255,0.1)]'
                  : tab.id === 'master'
                  ? 'text-[#D4AF37] hover:text-white hover:bg-[#122130] border border-[#D4AF37]/30'
                  : 'text-[#94a3b8] hover:text-white hover:bg-[#122130]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">{tab.icon}</span>
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                    isActive && tab.id === 'master'
                      ? 'bg-[#0A0F1D] text-[#D4AF37]'
                      : 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
              {tab.count !== undefined && (
                <span
                  className={`text-[10px] px-2 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-[#00F0FF]/20 text-[#00F0FF]' : 'bg-[#122130] text-[#94a3b8]'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ============================================================
          TAB CONTENT 0: MASTER USER (SUPER ADMIN) CONTROL SUITE
         ============================================================ */}
      {activeSubTab === 'master' && (
        <div className="space-y-6">
          {/* Master Root Hero Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-[#D4AF37]/15 via-[#0d1d2c] to-[#00F0FF]/15 border-2 border-[#D4AF37]/50 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 relative z-10">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-black bg-[#D4AF37] text-[#0A0F1D] shadow-[0_0_15px_rgba(212,175,55,0.5)] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px]">admin_panel_settings</span>
                    MASTER USER ACTIVE · ROOT PROTOCOL ACCESS
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    LIVE PROJECT GOVERNANCE
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black font-headline text-white tracking-tight">
                  Master User Project Control Center
                </h2>
                <p className="text-xs sm:text-sm text-[#94a3b8] max-w-2xl leading-relaxed">
                  Aapka master wallet address <code className="text-[#D4AF37] font-bold font-mono">0x3471e07c4d2f7e11c155760a7b386e616b5c3715</code> protocol ke root engine se linked hai. Yha se aap jo bhi mining parameters, referral percentages, hashrate rules ya balances update karenge, wo <strong className="text-white">poore project me sabhi users ke liye instantly apply ho jayenge</strong>.
                </p>
              </div>

              {/* Master Root Quick Actions */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={handleSaveMasterSettings}
                  disabled={isSavingMasterSettings}
                  className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#ffe088] text-[#0A0F1D] font-headline font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(212,175,55,0.5)] hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {isSavingMasterSettings ? 'sync' : 'publish'}
                  </span>
                  <span>{isSavingMasterSettings ? 'Deploying...' : 'Deploy Changes Live Across Project'}</span>
                </button>
              </div>
            </div>

            {/* Authorized Master Wallets Section */}
            <div className="mt-5 pt-4 border-t border-[#1c2b3b] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[#94a3b8]">Authorized Master Wallets:</span>
                {(settingsForm.masterWalletAddresses || [
                  '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
                  '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
                ]).map((addr) => {
                  const isCurrent = currentWallet && currentWallet.toLowerCase() === addr.toLowerCase();
                  return (
                    <span
                      key={addr}
                      className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 ${
                        isCurrent
                          ? 'bg-[#D4AF37]/20 text-[#D4AF37] border-[#D4AF37]'
                          : 'bg-[#122130] text-[#94a3b8] border-[#1c2b3b]'
                      }`}
                    >
                      <span>{addr.slice(0, 6)}...{addr.slice(-4)}</span>
                      {isCurrent && <span className="text-[10px] text-emerald-400 font-bold">(YOU)</span>}
                      {addr.toLowerCase() !== MASTER_CREATOR_ADDR.toLowerCase() && (
                        <button
                          type="button"
                          onClick={() => handleRemoveMasterWallet(addr)}
                          className="text-red-400 hover:text-red-300 ml-1"
                          title="Remove wallet"
                        >
                          ×
                        </button>
                      )}
                    </span>
                  );
                })}
              </div>

              {/* Add Master Wallet Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Add backup master wallet (0x...)"
                  value={newMasterInput}
                  onChange={(e) => setNewMasterInput(e.target.value)}
                  className="w-56 bg-[#122130] border border-[#1c2b3b] rounded-lg px-2.5 py-1 text-xs text-white font-mono focus:border-[#D4AF37] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddMasterWallet}
                  className="px-2.5 py-1 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 hover:bg-[#D4AF37]/30 text-xs font-bold"
                >
                  + Add
                </button>
              </div>
            </div>
          </div>

          {/* Section 1 & Section 2 Two-Column Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Control Column 1: Global Mining Parameters & Yields */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
              <div className="flex items-center justify-between border-b border-[#1c2b3b] pb-3">
                <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00F0FF]">speed</span>
                  <span>Global Mining Parameters &amp; Hashrate Rules</span>
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                  REAL-TIME FORMULAS
                </span>
              </div>

              <div className="space-y-4 text-xs font-mono">
                {/* Stratum Turbo Multiplier */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[#94a3b8]">Stratum Turbo Overclock Multiplier</label>
                    <span className="text-[#00F0FF] font-bold">{settingsForm.turboMultiplier || 10}X</span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={settingsForm.turboMultiplier || 10}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, turboMultiplier: Number(e.target.value) }))
                    }
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                  />
                  <span className="text-[10px] text-[#94a3b8] mt-1 block">
                    Mining rigs fleet wide overclock profile. Default: 10X.
                  </span>
                </div>

                {/* Base Hashrate for Fresh Users */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[#94a3b8]">Base Fresh User Hashrate (0 Referrals)</label>
                    <span className="text-emerald-400 font-bold">
                      100 VH/s (60 Days per SPK)
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="5"
                      min="10"
                      max="1000"
                      value={settingsForm.level1HashrateBoost ? (settingsForm.level1HashrateBoost / 2) : 100}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setSettingsForm((prev) => ({
                          ...prev,
                          baseHashrateTh: +(val / 80).toFixed(2),
                        }));
                      }}
                      className="flex-1 bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                    />
                    <span className="text-[#00F0FF] font-bold">VH/s</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 mt-1 block">
                    Formula: <code className="text-white">Required Hashrate = 100 × (60 / Target Days)</code>
                  </span>
                </div>

                {/* Daily Reward SPK & Daily Yield */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#94a3b8] mb-1">24h Claim Reward Yield (SPK)</label>
                    <input
                      type="number"
                      step="1"
                      value={settingsForm.dailyRewardSpk || 35.0}
                      onChange={(e) =>
                        setSettingsForm((prev) => ({ ...prev, dailyRewardSpk: Number(e.target.value) }))
                      }
                      className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#94a3b8] mb-1">Daily Yield ROI (%)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={settingsForm.dailyYieldPercent || 3.88}
                      onChange={(e) =>
                        setSettingsForm((prev) => ({ ...prev, dailyYieldPercent: Number(e.target.value) }))
                      }
                      className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>
                </div>

                {/* Mining Cycle Duration & Rig Deployment Cost */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#94a3b8] mb-1">Mining Cycle Duration (Hours)</label>
                    <input
                      type="number"
                      min="1"
                      max="72"
                      value={settingsForm.miningCycleHours || 24}
                      onChange={(e) =>
                        setSettingsForm((prev) => ({ ...prev, miningCycleHours: Number(e.target.value) }))
                      }
                      className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#94a3b8] mb-1">Hardware Node Price (USDT)</label>
                    <input
                      type="number"
                      step="1"
                      value={settingsForm.nodeCostUsdt || 15.0}
                      onChange={(e) =>
                        setSettingsForm((prev) => ({ ...prev, nodeCostUsdt: Number(e.target.value) }))
                      }
                      className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>
                </div>

                {/* Fast Testnet Cycle Toggle */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]">
                  <div>
                    <div className="font-bold text-white">Testnet Fast 1-Minute Cycle Mode</div>
                    <div className="text-[10px] text-[#94a3b8]">
                      Enables fast 60-second reward accrual for testing harvest cycles instantly.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={!!settingsForm.testnetFastCycleEnabled}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, testnetFastCycleEnabled: e.target.checked }))
                    }
                    className="w-5 h-5 rounded accent-[#00F0FF] cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Control Column 2: Team Referral Percentages & Sponsor Rules */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
              <div className="flex items-center justify-between border-b border-[#1c2b3b] pb-3">
                <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#D4AF37]">groups</span>
                  <span>Team Referral Percentages &amp; Sponsor Rules</span>
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30">
                  TIER DISTRIBUTION
                </span>
              </div>

              <div className="space-y-4 text-xs font-mono">
                {/* Commission Percentages */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#94a3b8] mb-1">
                      Tier 1 Direct Referral Commission (%)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        max="50"
                        value={settingsForm.tier1CommissionPercent || 15}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, tier1CommissionPercent: Number(e.target.value) }))
                        }
                        className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#D4AF37]"
                      />
                      <span className="text-[#D4AF37] font-bold">%</span>
                    </div>
                    <span className="text-[10px] text-[#94a3b8] mt-1 block">Immediate direct sponsor bonus</span>
                  </div>

                  <div>
                    <label className="block text-[#94a3b8] mb-1">
                      Tier 2 Indirect Referral Commission (%)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        max="25"
                        value={settingsForm.tier2CommissionPercent || 5}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, tier2CommissionPercent: Number(e.target.value) }))
                        }
                        className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono focus:outline-none focus:border-[#D4AF37]"
                      />
                      <span className="text-[#D4AF37] font-bold">%</span>
                    </div>
                    <span className="text-[10px] text-[#94a3b8] mt-1 block">Secondary network bonus</span>
                  </div>
                </div>

                {/* Level Milestones Table Configuration */}
                <div className="space-y-2.5 pt-1">
                  <div className="text-[#94a3b8] font-bold text-[11px]">
                    Sponsor Hashrate Upgrade Thresholds (Milestone System):
                  </div>

                  {/* Level 1 Config */}
                  <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00F0FF]/15 text-[#00F0FF]">
                        Level 1
                      </span>
                      <span className="text-[#94a3b8]">Directs:</span>
                      <input
                        type="number"
                        value={settingsForm.level1DirectsRequired || 10}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level1DirectsRequired: Number(e.target.value) }))
                        }
                        className="w-16 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-white text-center"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[#94a3b8]">Boost:</span>
                      <input
                        type="number"
                        value={settingsForm.level1HashrateBoost || 200}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level1HashrateBoost: Number(e.target.value) }))
                        }
                        className="w-20 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-emerald-400 font-bold text-center"
                      />
                      <span className="text-[#00F0FF]">VH/s</span>
                      <span className="text-[10px] text-[#94a3b8]">(30d target)</span>
                    </div>
                  </div>

                  {/* Level 2 Config */}
                  <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00F0FF]/15 text-[#00F0FF]">
                        Level 2
                      </span>
                      <span className="text-[#94a3b8]">Directs:</span>
                      <input
                        type="number"
                        value={settingsForm.level2DirectsRequired || 25}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level2DirectsRequired: Number(e.target.value) }))
                        }
                        className="w-16 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-white text-center"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[#94a3b8]">Boost:</span>
                      <input
                        type="number"
                        value={settingsForm.level2HashrateBoost || 400}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level2HashrateBoost: Number(e.target.value) }))
                        }
                        className="w-20 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-emerald-400 font-bold text-center"
                      />
                      <span className="text-[#00F0FF]">VH/s</span>
                      <span className="text-[10px] text-[#94a3b8]">(15d target)</span>
                    </div>
                  </div>

                  {/* Level 3 Config */}
                  <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00F0FF]/15 text-[#00F0FF]">
                        Level 3
                      </span>
                      <span className="text-[#94a3b8]">Directs:</span>
                      <input
                        type="number"
                        value={settingsForm.level3DirectsRequired || 50}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level3DirectsRequired: Number(e.target.value) }))
                        }
                        className="w-16 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-white text-center"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[#94a3b8]">Boost:</span>
                      <input
                        type="number"
                        value={settingsForm.level3HashrateBoost || 600}
                        onChange={(e) =>
                          setSettingsForm((prev) => ({ ...prev, level3HashrateBoost: Number(e.target.value) }))
                        }
                        className="w-20 bg-[#071322] border border-[#1c2b3b] rounded px-2 py-1 text-emerald-400 font-bold text-center"
                      />
                      <span className="text-[#00F0FF]">VH/s</span>
                      <span className="text-[10px] text-[#94a3b8]">(10d target)</span>
                    </div>
                  </div>
                </div>

                {/* Emergency Maintenance Mode */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#122130] border border-red-500/30">
                  <div>
                    <div className="font-bold text-red-400">Emergency Maintenance Protocol</div>
                    <div className="text-[10px] text-[#94a3b8]">
                      Global circuit breaker: pauses new node purchases &amp; withdrawals.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={!!settingsForm.maintenanceMode}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, maintenanceMode: e.target.checked }))
                    }
                    className="w-5 h-5 rounded accent-red-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Live User Management, Wallet Balances & Role Assignments */}
          <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1c2b3b] pb-4">
              <div>
                <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#D4AF37]">manage_accounts</span>
                  <span>User Management, Wallet Balances &amp; Role Assignments</span>
                </h3>
                <p className="text-xs text-[#94a3b8] mt-0.5">
                  Promote users to Master or Admin, grant welcome balances, or override speeds.
                </p>
              </div>

              {/* User search bar */}
              <div className="relative w-full sm:w-72">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[16px] text-[#94a3b8]">
                  search
                </span>
                <input
                  type="text"
                  placeholder="Filter users or address..."
                  value={masterUserSearch}
                  onChange={(e) => setMasterUserSearch(e.target.value)}
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl pl-9 pr-3 py-1.5 text-xs font-mono text-white placeholder-[#94a3b8]/50 focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            </div>

            {/* User List Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#122130] text-[#94a3b8] border-b border-[#1c2b3b]">
                    <th className="p-3">Wallet Address</th>
                    <th className="p-3">Role Assignment</th>
                    <th className="p-3">Referral Status</th>
                    <th className="p-3">Current Hashrate</th>
                    <th className="p-3">USDT Balance</th>
                    <th className="p-3">Gas (BNB)</th>
                    <th className="p-3 text-right">Master Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2b3b]/60">
                  {users
                    .filter(
                      (u) =>
                        !masterUserSearch.trim() ||
                        u.address.toLowerCase().includes(masterUserSearch.toLowerCase()) ||
                        u.referralCode?.toLowerCase().includes(masterUserSearch.toLowerCase())
                    )
                    .map((u) => {
                      const isMasterAddr = u.role === 'master' || (settingsForm.masterWalletAddresses || []).map((a) => a.toLowerCase()).includes(u.address.toLowerCase());
                      return (
                        <tr key={u.address} className="hover:bg-[#122130]/40 transition-colors">
                          <td className="p-3">
                            <div className="font-bold text-white flex items-center gap-2">
                              <span className="text-[#00F0FF]">{u.address.slice(0, 10)}...{u.address.slice(-6)}</span>
                              {isMasterAddr && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#D4AF37] text-[#0A0F1D]">
                                  ROOT
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-[#94a3b8]">Ref: {u.referralCode}</div>
                          </td>

                          {/* Role Selector */}
                          <td className="p-3">
                            <select
                              value={u.role || (isMasterAddr ? 'master' : 'user')}
                              onChange={(e) => handleUpdateUserRole(u.address, e.target.value as any)}
                              className={`bg-[#071322] border rounded-lg px-2.5 py-1 text-xs font-bold font-mono focus:outline-none ${
                                isMasterAddr
                                  ? 'text-[#D4AF37] border-[#D4AF37]'
                                  : u.role === 'admin'
                                  ? 'text-[#00F0FF] border-[#00F0FF]/50'
                                  : 'text-white border-[#1c2b3b]'
                              }`}
                            >
                              <option value="user">User (Standard)</option>
                              <option value="moderator">Moderator</option>
                              <option value="admin">Admin</option>
                              <option value="master">Master (Root)</option>
                            </select>
                          </td>

                          <td className="p-3">
                            <div className="text-white font-bold">{u.directPartners ?? 0} Directs</div>
                            <div className="text-[10px] text-[#D4AF37]">{u.totalPartners ?? 0} Total Team</div>
                          </td>

                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                              {u.hashrateInfo?.hashrate || u.customHashrate || 100} VH/s
                            </span>
                            <div className="text-[10px] text-emerald-400 mt-0.5">
                              {u.hashrateInfo?.level || 'Fresh user'}
                            </div>
                          </td>

                          <td className="p-3 text-white font-bold tabular-nums">
                            ${u.balanceUsdt.toFixed(2)}
                          </td>

                          <td className="p-3 text-amber-400 font-bold tabular-nums">
                            {u.balanceBnb.toFixed(4)} BNB
                          </td>

                          {/* Action Buttons */}
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Founder Grant */}
                              <button
                                type="button"
                                onClick={() => handleGrantFounderPackage(u.address)}
                                className="px-2 py-1 rounded bg-gradient-to-r from-[#D4AF37]/20 to-[#00F0FF]/20 hover:from-[#D4AF37]/30 hover:to-[#00F0FF]/30 text-[#D4AF37] border border-[#D4AF37]/40 text-[10px] font-bold transition-all"
                                title="Grant 100 USDT, 0.1 BNB & 200 VH/s boost"
                              >
                                + Founder Grant
                              </button>

                              {/* Adjust */}
                              <button
                                type="button"
                                onClick={() => {
                                  setAdjustModalUser(u);
                                  setAdjustAmount(50);
                                  setAdjustType('credit');
                                }}
                                className="px-2 py-1 rounded bg-[#00F0FF]/15 hover:bg-[#00F0FF]/25 text-[#00F0FF] border border-[#00F0FF]/30 text-[10px] font-semibold"
                                title="Credit or Debit Balance"
                              >
                                Adjust
                              </button>

                              {/* Hashrate */}
                              <button
                                type="button"
                                onClick={() => {
                                  setHashrateModalUser(u);
                                  setCustomHashrateVal(String(u.hashrateInfo?.hashrate || u.customHashrate || 100));
                                  setSelectedHashratePreset(u.hashrateInfo?.hashrate || u.customHashrate || 100);
                                }}
                                className="px-2 py-1 rounded bg-[#1c2b3b] hover:bg-[#25394e] text-white border border-[#2d4257] text-[10px]"
                                title="Set specific mining speed"
                              >
                                Speed
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sticky Deployment Action Bar */}
          <div className="sticky bottom-4 z-20 p-4 rounded-2xl bg-[#0a1220]/95 backdrop-blur-md border-2 border-[#D4AF37]/50 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0">
                <span className="material-symbols-outlined text-[22px]">rocket_launch</span>
              </div>
              <div>
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Deploy &amp; Sync Master Configuration</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    ACID PERSISTENCE
                  </span>
                </div>
                <div className="text-xs text-[#94a3b8]">
                  Saves all updated rules to database and triggers instant synchronization across all app views.
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={handleSaveMasterSettings}
                disabled={isSavingMasterSettings}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#00F0FF] text-[#0A0F1D] font-headline font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">
                  {isSavingMasterSettings ? 'sync' : 'save'}
                </span>
                <span>{isSavingMasterSettings ? 'Saving to Database...' : 'Save & Apply Project-Wide'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 1: OVERVIEW & QUICK ACTIONS
         ============================================================ */}
      {activeSubTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Quick Actions & System Status */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#D4AF37]">rocket_launch</span>
                  Quick Administrative Actions
                </h3>
                <span className="text-xs text-[#94a3b8] font-mono">Real-time DB triggers</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Dedicated Testnet Faucet Quick Card */}
                <button
                  onClick={() => setActiveSubTab('faucet')}
                  className="p-4 rounded-xl bg-gradient-to-r from-[#00F0FF]/15 via-[#122130] to-[#D4AF37]/15 hover:from-[#00F0FF]/25 hover:to-[#D4AF37]/25 border border-[#00F0FF]/40 text-left transition-all group sm:col-span-2 shadow-sm"
                >
                  <div className="flex items-center justify-between text-[#00F0FF] mb-2">
                    <span className="text-sm font-bold flex items-center gap-2">
                      <span className="material-symbols-outlined text-[20px] text-[#00F0FF]">science</span>
                      <span>Testnet Faucet: Credit USDT to Any Wallet Address</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40 font-bold">
                        DIRECT CREDIT
                      </span>
                    </span>
                    <span className="material-symbols-outlined text-[20px] text-[#00F0FF] group-hover:translate-x-1 transition-transform">
                      arrow_forward
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8] leading-relaxed">
                    Kisi bhi user ka BEP-20 wallet address paste karke turant temporary testnet USDT aur gas fee BNB credit karein taaki user dApp me jakar node purchase &amp; mining test kar sake.
                  </p>
                </button>

                <button
                  onClick={() => setActiveSubTab('users')}
                  className="p-4 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-[#00F0FF] mb-2">
                    <span className="text-sm font-bold">Manage Wallet Balances</span>
                    <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
                      arrow_forward
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Credit USDT/BNB to any wallet, inspect referral ties, freeze suspicious accounts.
                  </p>
                </button>

                <button
                  onClick={() => setActiveSubTab('nodes')}
                  className="p-4 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-[#D4AF37] mb-2">
                    <span className="text-sm font-bold">Rig Fleet Telemetry</span>
                    <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
                      arrow_forward
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Inspect active stratum connections, restart rigs, force turbo clocking across validator pool.
                  </p>
                </button>

                <button
                  onClick={() => setActiveSubTab('transactions')}
                  className="p-4 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-emerald-400 mb-2">
                    <span className="text-sm font-bold">Verify Pending Claims</span>
                    <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
                      arrow_forward
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Review payout transactions, verify BSC transaction hashes, mark payouts confirmed.
                  </p>
                </button>

                <button
                  onClick={() => setActiveSubTab('settings')}
                  className="p-4 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-left transition-all group"
                >
                  <div className="flex items-center justify-between text-purple-400 mb-2">
                    <span className="text-sm font-bold">Configure Protocol Yield</span>
                    <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
                      arrow_forward
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Adjust daily ROI %, stratum pool host URL, contract address, or toggle emergency maintenance.
                  </p>
                </button>
              </div>
            </div>

            {/* Recent Ledger Entries */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-blue-400">history</span>
                  Latest Database Transactions
                </h3>
                <button
                  onClick={() => setActiveSubTab('transactions')}
                  className="text-xs text-[#00F0FF] hover:underline font-mono"
                >
                  View All ({transactions.length}) →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-[#1c2b3b] text-[#94a3b8]">
                      <th className="pb-2.5">User</th>
                      <th className="pb-2.5">Type</th>
                      <th className="pb-2.5">Amount</th>
                      <th className="pb-2.5">Status</th>
                      <th className="pb-2.5">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1c2b3b]/60">
                    {transactions.slice(0, 5).map((tx, idx) => (
                      <tr key={`${tx.id || 'tx'}-${idx}`} className="hover:bg-[#122130]/50 transition-colors">
                        <td className="py-2.5 text-[#00F0FF]">
                          {tx.userAddress ? `${tx.userAddress.slice(0, 8)}...` : 'System'}
                        </td>
                        <td className="py-2.5 text-white capitalize">{tx.rewardSource || tx.type}</td>
                        <td
                          className={`py-2.5 font-bold ${
                            tx.amount >= 0 ? 'text-emerald-400' : 'text-red-400'
                          }`}
                        >
                          {tx.amount >= 0 ? `+${tx.amount.toFixed(2)}` : tx.amount.toFixed(2)} {tx.currency}
                        </td>
                        <td className="py-2.5">
                          <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                            {tx.status}
                          </span>
                        </td>
                        <td className="py-2.5 text-[#94a3b8]">{tx.timestamp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right Column: Database Health & Live System Specs */}
          <div className="space-y-6">
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-4">
              <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-400">database</span>
                Database Storage Status
              </h3>

              <div className="space-y-3 text-xs font-mono">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#122130] border border-[#1c2b3b]">
                  <span className="text-[#94a3b8]">Engine:</span>
                  <span className="text-emerald-400 font-bold">Node.js ACID JSON File Engine</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#122130] border border-[#1c2b3b]">
                  <span className="text-[#94a3b8]">File Path:</span>
                  <span className="text-white text-[11px]">.data/spike_database.json</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#122130] border border-[#1c2b3b]">
                  <span className="text-[#94a3b8]">Backup File:</span>
                  <span className="text-white text-[11px]">.data/spike_database.bak.json</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#122130] border border-[#1c2b3b]">
                  <span className="text-[#94a3b8]">Last Auto-Save:</span>
                  <span className="text-[#00F0FF]">
                    {metrics ? new Date(metrics.lastSaved).toLocaleTimeString() : 'Active'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#122130] border border-[#1c2b3b]">
                  <span className="text-[#94a3b8]">File Integrity:</span>
                  <span className="text-emerald-400 font-bold">PASS (Atomic Sync)</span>
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <a
                  href="/api/db/export"
                  download
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00F0FF]/15 hover:bg-[#00F0FF]/25 border border-[#00F0FF]/40 text-[#00F0FF] text-xs font-mono font-bold text-center transition-all flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined text-[16px]">file_download</span>
                  Export Complete DB Backup (.json)
                </a>

                <button
                  onClick={() => onNavigateTab('dashboard')}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-white text-xs font-mono font-medium transition-all text-center flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined text-[16px]">visibility</span>
                  Switch to User Dashboard
                </button>
              </div>
            </div>

            {/* Live Stratum Pool Status */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-3">
              <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00F0FF]">lan</span>
                Stratum Pool Status
              </h3>
              <div className="text-xs font-mono space-y-2 text-[#94a3b8]">
                <div className="flex justify-between">
                  <span>Host:</span>
                  <span className="text-white">pool.spikenodes.com:443</span>
                </div>
                <div className="flex justify-between">
                  <span>Protocol:</span>
                  <span className="text-[#00F0FF]">Stratum v1 (TLS Enabled)</span>
                </div>
                <div className="flex justify-between">
                  <span>Algorithm:</span>
                  <span className="text-[#D4AF37]">SHA-256 (BSC Sublayer)</span>
                </div>
                <div className="flex justify-between">
                  <span>Difficulty:</span>
                  <span className="text-white">1,048,576 (Auto VarDiff)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT: WITHDRAWAL REQUESTS (MILESTONES & USER REWARDS)
         ============================================================ */}
      {activeSubTab === 'withdrawals' && (
        <div className="space-y-6">
          {/* Main Withdrawal Management Header */}
          <div className="rounded-2xl bg-gradient-to-r from-[#0d1d2c] via-[#0f2438] to-[#0a1827] border-2 border-[#D4AF37]/40 p-6 md:p-8 shadow-[0_0_30px_rgba(212,175,55,0.15)] relative overflow-hidden">
            <div className="relative z-10 space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#D4AF37] text-[#0A0F1D] flex items-center gap-1.5 shadow-[0_0_12px_rgba(212,175,55,0.4)]">
                  <span className="material-symbols-outlined text-[16px]">payments</span>
                  MILESTONE REWARD WITHDRAWALS
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  REAL-TIME REVIEW CONSOLE
                </span>
                <span className="px-2.5 py-1 rounded-full text-[11px] font-mono text-[#00F0FF] bg-[#00F0FF]/10 border border-[#00F0FF]/30">
                  BEP-20 USDT Payouts
                </span>
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-1">
                <div>
                  <h2 className="text-2xl md:text-3xl font-extrabold text-white font-headline tracking-wide flex items-center gap-2.5">
                    <span>Withdrawal Approval &amp; Payout Console</span>
                  </h2>
                  <p className="text-sm text-[#94a3b8] max-w-3xl mt-1">
                    Users submit withdrawal requests directly from their <span className="text-[#D4AF37] font-semibold">Total Earned</span> milestone card on the Referrals page. As an admin, review pending requests, enter or auto-generate a BSC TxHash, and click <strong className="text-emerald-400 font-semibold">Approve &amp; Mark Done</strong> to confirm payouts.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fetchAllData(true)}
                    className="px-4 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1a2f42] border border-[#1c2b3b] text-white text-xs font-mono font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:border-[#00F0FF]/50"
                  >
                    <span className="material-symbols-outlined text-[16px] text-[#00F0FF]">sync</span>
                    <span>Refresh Requests</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-xl p-4">
              <div className="flex items-center justify-between text-[#94a3b8] text-xs font-mono mb-1">
                <span>Total Requests</span>
                <span className="material-symbols-outlined text-[18px] text-blue-400">receipt_long</span>
              </div>
              <div className="text-2xl font-extrabold text-white font-headline">
                {withdrawalRequests.length}
              </div>
              <div className="text-[11px] text-[#94a3b8] font-mono mt-1">
                ${withdrawalRequests.reduce((sum, w) => sum + (Number(w.amount) || 0), 0).toFixed(2)} USDT total
              </div>
            </div>

            <div className="bg-[#0d1d2c] border border-amber-500/40 rounded-xl p-4 shadow-[0_0_15px_rgba(245,158,11,0.08)]">
              <div className="flex items-center justify-between text-amber-400 text-xs font-mono mb-1 font-semibold">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  Pending Review
                </span>
                <span className="material-symbols-outlined text-[18px]">pending_actions</span>
              </div>
              <div className="text-2xl font-extrabold text-amber-400 font-headline">
                {withdrawalRequests.filter((w) => w.status === 'pending').length}
              </div>
              <div className="text-[11px] text-amber-300 font-mono mt-1">
                ${withdrawalRequests
                  .filter((w) => w.status === 'pending')
                  .reduce((sum, w) => sum + (Number(w.amount) || 0), 0)
                  .toFixed(2)} USDT waiting
              </div>
            </div>

            <div className="bg-[#0d1d2c] border border-emerald-500/40 rounded-xl p-4 shadow-[0_0_15px_rgba(16,185,129,0.08)]">
              <div className="flex items-center justify-between text-emerald-400 text-xs font-mono mb-1 font-semibold">
                <span>Done &amp; Approved</span>
                <span className="material-symbols-outlined text-[18px]">verified</span>
              </div>
              <div className="text-2xl font-extrabold text-emerald-400 font-headline">
                {withdrawalRequests.filter((w) => w.status === 'approved').length}
              </div>
              <div className="text-[11px] text-emerald-300 font-mono mt-1">
                ${withdrawalRequests
                  .filter((w) => w.status === 'approved')
                  .reduce((sum, w) => sum + (Number(w.amount) || 0), 0)
                  .toFixed(2)} USDT paid out
              </div>
            </div>

            <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-xl p-4">
              <div className="flex items-center justify-between text-[#94a3b8] text-xs font-mono mb-1">
                <span>Declined / Rejected</span>
                <span className="material-symbols-outlined text-[18px] text-red-400">cancel</span>
              </div>
              <div className="text-2xl font-extrabold text-[#94a3b8] font-headline">
                {withdrawalRequests.filter((w) => w.status === 'rejected').length}
              </div>
              <div className="text-[11px] text-[#94a3b8] font-mono mt-1">Returned / flagged</div>
            </div>
          </div>

          {/* Filter & Search Bar */}
          <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto">
              {(['all', 'pending', 'approved', 'rejected'] as const).map((filter) => {
                const count =
                  filter === 'all'
                    ? withdrawalRequests.length
                    : withdrawalRequests.filter((w) => w.status === filter).length;
                const isActive = withdrawalFilter === filter;
                return (
                  <button
                    key={filter}
                    type="button"
                    onClick={() => setWithdrawalFilter(filter)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                      isActive
                        ? filter === 'pending'
                          ? 'bg-amber-500 text-black shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                          : filter === 'approved'
                          ? 'bg-emerald-500 text-black shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                          : filter === 'rejected'
                          ? 'bg-red-500 text-white'
                          : 'bg-[#00F0FF] text-black shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                        : 'bg-[#122130] text-[#94a3b8] hover:text-white border border-[#1c2b3b]'
                    }`}
                  >
                    <span>
                      {filter === 'all'
                        ? 'All Requests'
                        : filter === 'pending'
                        ? 'Pending Review'
                        : filter === 'approved'
                        ? 'Done / Approved'
                        : 'Rejected'}
                    </span>
                    <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-black/30">
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="relative w-full md:w-80">
              <input
                type="text"
                placeholder="Search by address or ID..."
                value={withdrawalSearch}
                onChange={(e) => setWithdrawalSearch(e.target.value)}
                className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-white placeholder-[#94a3b8]/50 focus:outline-none focus:border-[#00F0FF]"
              />
              <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-[#94a3b8] text-[16px]">
                search
              </span>
              {withdrawalSearch && (
                <button
                  type="button"
                  onClick={() => setWithdrawalSearch('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#94a3b8] hover:text-white text-xs cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Requests Table */}
          {(() => {
            const filtered = withdrawalRequests.filter((w) => {
              if (withdrawalFilter !== 'all' && w.status !== withdrawalFilter) return false;
              if (withdrawalSearch) {
                const q = withdrawalSearch.toLowerCase();
                const matchId = (w.id || '').toLowerCase().includes(q);
                const matchUser = (w.userAddress || '').toLowerCase().includes(q);
                const matchDest = (w.destinationAddress || '').toLowerCase().includes(q);
                const matchSource = (w.source || '').toLowerCase().includes(q);
                if (!matchId && !matchUser && !matchDest && !matchSource) return false;
              }
              return true;
            });

            if (filtered.length === 0) {
              return (
                <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl p-12 text-center">
                  <div className="w-14 h-14 mx-auto rounded-full bg-[#122130] border border-[#1c2b3b] flex items-center justify-center text-[#94a3b8] mb-3">
                    <span className="material-symbols-outlined text-2xl">inbox</span>
                  </div>
                  <h4 className="text-white font-headline font-bold text-base">No Withdrawal Requests Found</h4>
                  <p className="text-xs text-[#94a3b8] font-mono mt-1 max-w-md mx-auto">
                    {withdrawalSearch
                      ? `No requests match "${withdrawalSearch}". Try clearing your search.`
                      : withdrawalFilter === 'pending'
                      ? 'All caught up! There are no pending milestone withdrawal requests.'
                      : 'No withdrawal requests recorded in the system yet. When users claim milestone awards and submit requests, they will appear here.'}
                  </p>
                </div>
              );
            }

            return (
              <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-[#091522] border-b border-[#1c2b3b] text-[#94a3b8] uppercase text-[10px] tracking-wider">
                      <tr>
                        <th className="py-3 px-4">Request ID</th>
                        <th className="py-3 px-4">User Wallet</th>
                        <th className="py-3 px-4">Destination (BEP-20)</th>
                        <th className="py-3 px-4">Reward Source</th>
                        <th className="py-3 px-4 text-right">Amount (USDT)</th>
                        <th className="py-3 px-4">Date / Time</th>
                        <th className="py-3 px-4 text-center">Status</th>
                        <th className="py-3 px-4 text-right">Admin Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1c2b3b]">
                      {filtered.map((item, idx) => {
                        const isPending = item.status === 'pending';
                        const isApproved = item.status === 'approved';
                        const isRejected = item.status === 'rejected';
                        const isBusy = processingWithdrawalId === item.id;

                        return (
                          <tr
                            key={`${item.id || 'wdr'}-${idx}`}
                            className={`hover:bg-[#122130]/50 transition-colors ${
                              isPending ? 'bg-amber-500/5' : ''
                            }`}
                          >
                            {/* Request ID */}
                            <td className="py-3 px-4 text-white font-bold whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[#00F0FF]">#{item.id?.slice(-8)}</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(item.id);
                                    onNotify?.('Copied', 'Request ID copied', 'info');
                                  }}
                                  className="text-[#94a3b8] hover:text-white cursor-pointer"
                                  title="Copy Request ID"
                                >
                                  <span className="material-symbols-outlined text-[13px]">content_copy</span>
                                </button>
                              </div>
                            </td>

                            {/* User Wallet */}
                            <td className="py-3 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-1.5 font-mono">
                                <span className="text-white">
                                  {item.userAddress
                                    ? `${item.userAddress.slice(0, 6)}...${item.userAddress.slice(-4)}`
                                    : '—'}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(item.userAddress);
                                    onNotify?.('Copied', 'User address copied', 'info');
                                  }}
                                  className="text-[#94a3b8] hover:text-white cursor-pointer"
                                  title="Copy User Address"
                                >
                                  <span className="material-symbols-outlined text-[13px]">content_copy</span>
                                </button>
                              </div>
                            </td>

                            {/* Destination BEP-20 Address */}
                            <td className="py-3 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-1.5 font-mono">
                                <span className="text-amber-300">
                                  {item.destinationAddress
                                    ? `${item.destinationAddress.slice(0, 6)}...${item.destinationAddress.slice(-4)}`
                                    : '—'}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(item.destinationAddress);
                                    onNotify?.('Copied', 'Destination address copied', 'info');
                                  }}
                                  className="text-[#94a3b8] hover:text-white cursor-pointer"
                                  title="Copy Destination"
                                >
                                  <span className="material-symbols-outlined text-[13px]">content_copy</span>
                                </button>
                              </div>
                            </td>

                            {/* Reward Source */}
                            <td className="py-3 px-4 text-[#94a3b8] whitespace-nowrap">
                              <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#122130] text-[#D4AF37] border border-[#D4AF37]/30">
                                {item.source || 'Milestone Award'}
                              </span>
                            </td>

                            {/* Amount */}
                            <td className="py-3 px-4 text-right whitespace-nowrap">
                              <span className="text-sm font-extrabold text-[#00F0FF] font-headline">
                                +${Number(item.amount || 0).toFixed(2)}
                              </span>
                              <span className="text-[10px] text-[#94a3b8] block">USDT (BEP-20)</span>
                            </td>

                            {/* Date */}
                            <td className="py-3 px-4 text-[#94a3b8] whitespace-nowrap">
                              <div>{new Date(item.createdAt || Date.now()).toLocaleDateString()}</div>
                              <div className="text-[10px] opacity-75">
                                {new Date(item.createdAt || Date.now()).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </div>
                            </td>

                            {/* Status */}
                            <td className="py-3 px-4 text-center whitespace-nowrap">
                              {isPending && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                                  PENDING
                                </span>
                              )}
                              {isApproved && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                                  <span className="material-symbols-outlined text-[12px]">check_circle</span>
                                  DONE / APPROVED
                                </span>
                              )}
                              {isRejected && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/40">
                                  <span className="material-symbols-outlined text-[12px]">cancel</span>
                                  REJECTED
                                </span>
                              )}
                            </td>

                            {/* Action Buttons */}
                            <td className="py-3 px-4 text-right whitespace-nowrap">
                              {isPending && (
                                <div className="flex items-center justify-end gap-2">
                                  {/* Optional Custom Tx Hash Input */}
                                  <input
                                    type="text"
                                    placeholder="Optional TxHash (0x...)"
                                    value={customTxInput[item.id] || ''}
                                    onChange={(e) =>
                                      setCustomTxInput((prev) => ({
                                        ...prev,
                                        [item.id]: e.target.value,
                                      }))
                                    }
                                    className="w-36 bg-[#122130] border border-[#1c2b3b] rounded-lg px-2 py-1 text-[10px] text-white placeholder-[#94a3b8]/40 focus:outline-none focus:border-[#00F0FF]"
                                    title="Leave empty to auto-generate verified BSC transaction hash"
                                  />

                                  {/* Approve & Mark Done Button */}
                                  <button
                                    type="button"
                                    disabled={isBusy}
                                    onClick={() => handleApproveWithdrawal(item.id)}
                                    className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-headline font-bold text-[11px] uppercase tracking-wider flex items-center gap-1 transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)] disabled:opacity-50 cursor-pointer"
                                  >
                                    <span className="material-symbols-outlined text-[14px]">done_all</span>
                                    <span>{isBusy ? 'Processing...' : 'Approve & Done'}</span>
                                  </button>

                                  {/* Reject Button */}
                                  <button
                                    type="button"
                                    disabled={isBusy}
                                    onClick={() => handleRejectWithdrawal(item.id)}
                                    className="px-2.5 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-[11px] font-bold transition-all disabled:opacity-50 cursor-pointer"
                                    title="Decline request"
                                  >
                                    <span className="material-symbols-outlined text-[14px]">close</span>
                                  </button>
                                </div>
                              )}

                              {isApproved && (
                                <div className="space-y-0.5 text-right">
                                  <div className="text-emerald-400 font-bold text-[11px] flex items-center justify-end gap-1">
                                    <span className="material-symbols-outlined text-[13px]">verified</span>
                                    <span>Paid &amp; Done</span>
                                  </div>
                                  {item.txHash && (
                                    <a
                                      href={`https://bscscan.com/tx/${item.txHash}`}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[#00F0FF] hover:underline text-[10px] font-mono flex items-center justify-end gap-0.5"
                                    >
                                      <span>{item.txHash.slice(0, 10)}...{item.txHash.slice(-6)}</span>
                                      <span className="material-symbols-outlined text-[11px]">open_in_new</span>
                                    </a>
                                  )}
                                  <div className="text-[10px] text-[#94a3b8]">
                                    by {item.reviewedBy ? item.reviewedBy.slice(0, 10) : 'Admin'}
                                  </div>
                                </div>
                              )}

                              {isRejected && (
                                <div className="space-y-0.5 text-right">
                                  <span className="text-red-400 text-[11px] font-semibold">Declined</span>
                                  {item.adminNote && (
                                    <div className="text-[10px] text-[#94a3b8] italic max-w-xs ml-auto">
                                      "{item.adminNote}"
                                    </div>
                                  )}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ============================================================
          TAB CONTENT: ADMIN TESTNET FAUCET & WALLET BALANCE CREDIT CONSOLE
         ============================================================ */}
      {activeSubTab === 'faucet' && (
        <div className="space-y-6">
          {/* Main Faucet Header Card */}
          <div className="rounded-2xl bg-gradient-to-r from-[#0d1d2c] via-[#0f2438] to-[#0a1827] border-2 border-[#00F0FF]/40 p-6 md:p-8 shadow-[0_0_30px_rgba(0,240,255,0.15)] relative overflow-hidden">
            <div className="relative z-10 space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#00F0FF] text-[#0A0F1D] flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
                  <span className="material-symbols-outlined text-[16px]">science</span>
                  ADMIN TESTNET FAUCET
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
                  REAL-TIME DATABASE FUNDING
                </span>
                <span className="px-2.5 py-1 rounded-full text-[11px] font-mono text-emerald-400 bg-emerald-950/50 border border-emerald-500/40">
                  Centralized in Admin Panel
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold font-headline text-white tracking-tight">
                Direct Wallet Balance Injector &amp; Testnet Faucet
              </h2>
              <p className="text-xs sm:text-sm text-[#94a3b8] max-w-2xl leading-relaxed">
                Home page aur Dashboard se testing buttons remove kar diye gaye hain. Jab bhi kisi user ke testnet faucet me temporary USDT dalne hon, aap yahan admin me aakar uska BEP-20 wallet address paste karke turant USDT credit kar sakte hain. Database real-time sync hoga aur user turant node deploy kar sakega.
              </p>

              {/* Network Switcher & QA Studio Bar (Centralized from Header into Admin) */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 bg-[#122130] border border-[#1c2b3b] px-3 py-1.5 rounded-xl text-xs">
                  <span className="text-[#94a3b8]">Active Chain:</span>
                  <span className="font-mono text-[#00F0FF] font-bold flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#00F0FF] animate-pulse" />
                    {network}
                  </span>
                  {onNetworkChange && (
                    <div className="flex gap-1 ml-2 pl-2 border-l border-[#1c2b3b]">
                      <button
                        type="button"
                        onClick={() => onNetworkChange('BSC Testnet')}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                          network === 'BSC Testnet'
                            ? 'bg-[#00F0FF] text-black font-bold'
                            : 'text-[#94a3b8] hover:text-white'
                        }`}
                      >
                        BSC Testnet
                      </button>
                      <button
                        type="button"
                        onClick={() => onNetworkChange('BNB Smart Chain')}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                          network === 'BNB Smart Chain'
                            ? 'bg-[#D4AF37] text-black font-bold'
                            : 'text-[#94a3b8] hover:text-white'
                        }`}
                      >
                        Mainnet
                      </button>
                    </div>
                  )}
                </div>

                {onOpenTestnetModal && (
                  <button
                    type="button"
                    onClick={onOpenTestnetModal}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-headline font-bold bg-[#1c2b3b] hover:bg-[#25384d] text-[#00F0FF] border border-[#00F0FF]/40 transition-all shadow-sm"
                  >
                    <span className="material-symbols-outlined text-[16px]">terminal</span>
                    <span>Open Web3 Testnet &amp; Smart Contract Tools</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Faucet Injector Form (7 cols) */}
            <div className="lg:col-span-7 bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl p-6 space-y-5 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3b]">
                <div className="flex items-center gap-2 text-white font-bold font-headline text-base">
                  <span className="material-symbols-outlined text-[#00F0FF]">account_balance_wallet</span>
                  <span>Fund Recipient Wallet</span>
                </div>
                <span className="text-xs text-[#94a3b8] font-mono">BEP-20 (BSC Sublayer)</span>
              </div>

              <form onSubmit={handleExecuteAdminFaucet} className="space-y-4">
                {/* Wallet Address Input */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-headline font-semibold text-white">
                      Recipient Wallet Address (0x...)
                    </label>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const clip = await navigator.clipboard.readText();
                            if (clip && clip.startsWith('0x')) {
                              setFaucetAddress(clip.trim());
                              onNotify?.('Pasted', 'Wallet address pasted from clipboard', 'info');
                            } else {
                              onNotify?.('Clipboard Notice', 'No valid 0x address found in clipboard. Please paste manually.', 'info');
                            }
                          } catch {
                            onNotify?.('Paste Notice', 'Please press Ctrl+V to paste the address.', 'info');
                          }
                        }}
                        className="text-[11px] text-[#00F0FF] hover:underline font-mono flex items-center gap-1 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[13px]">content_paste</span>
                        <span>Paste Address</span>
                      </button>
                      {faucetAddress && (
                        <button
                          type="button"
                          onClick={() => setFaucetAddress('')}
                          className="text-[11px] text-rose-400 hover:underline font-mono cursor-pointer"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  </div>
                  <input
                    type="text"
                    required
                    value={faucetAddress}
                    onChange={(e) => setFaucetAddress(e.target.value)}
                    placeholder="e.g. 0x8a923bf410de882... (Paste user wallet address here)"
                    className="w-full bg-[#122130] border border-[#1c2b3b] focus:border-[#00F0FF] rounded-xl px-4 py-3 text-white text-xs sm:text-sm font-mono placeholder-[#94a3b8]/50 focus:outline-none focus:ring-1 focus:ring-[#00F0FF] transition-all"
                  />

                  {/* Quick-Pick Registered Wallets */}
                  {users.length > 0 && (
                    <div className="mt-2 space-y-1">
                      <div className="text-[10px] text-[#94a3b8] font-mono uppercase tracking-wider">
                        Quick Select Registered Users:
                      </div>
                      <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                        {users.slice(0, 8).map((u) => (
                          <button
                            key={u.address}
                            type="button"
                            onClick={() => setFaucetAddress(u.address)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono transition-all flex items-center gap-1 border ${
                              faucetAddress.toLowerCase() === u.address.toLowerCase()
                                ? 'bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/50 font-bold'
                                : 'bg-[#122130] text-[#94a3b8] hover:text-white border-[#1c2b3b]'
                            }`}
                          >
                            <span>{u.address.slice(0, 6)}...{u.address.slice(-4)}</span>
                            <span className="text-[#D4AF37]">(${u.balanceUsdt.toFixed(0)})</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Amount USDT Selection */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-headline font-semibold text-white">
                      USDT Credit Amount
                    </label>
                    <span className="text-[11px] text-[#00F0FF] font-mono font-bold">
                      +{faucetAmount} USDT
                    </span>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-2">
                    {[
                      { amt: 15, label: '+15 (Starter)' },
                      { amt: 50, label: '+50' },
                      { amt: 75, label: '+75 (Standard)' },
                      { amt: 100, label: '+100' },
                      { amt: 250, label: '+250 (Enterprise)' },
                      { amt: 500, label: '+500' },
                    ].map((p) => (
                      <button
                        key={p.amt}
                        type="button"
                        onClick={() => setFaucetAmount(p.amt)}
                        className={`py-2 px-1 rounded-xl text-xs font-mono font-semibold transition-all border text-center ${
                          faucetAmount === p.amt
                            ? 'bg-[#00F0FF] text-[#0A0F1D] border-[#00F0FF] font-bold shadow-[0_0_12px_rgba(0,240,255,0.35)]'
                            : 'bg-[#122130] text-[#94a3b8] hover:text-white border-[#1c2b3b]'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={faucetAmount}
                    onChange={(e) => setFaucetAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-[#122130] border border-[#1c2b3b] focus:border-[#00F0FF] rounded-xl px-4 py-2.5 text-white text-xs font-mono focus:outline-none"
                    placeholder="Or enter custom USDT amount..."
                  />
                </div>

                {/* Gas Fee BNB Support */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-headline font-semibold text-white mb-1.5">
                      BNB Gas Fee Credit
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setFaucetBnb(0.05)}
                        className={`flex-1 py-2 rounded-xl text-xs font-mono font-semibold border ${
                          faucetBnb === 0.05
                            ? 'bg-[#D4AF37] text-black border-[#ffe088] font-bold'
                            : 'bg-[#122130] text-[#94a3b8] border-[#1c2b3b]'
                        }`}
                      >
                        +0.05 BNB (Recommended)
                      </button>
                      <button
                        type="button"
                        onClick={() => setFaucetBnb(0)}
                        className={`py-2 px-3 rounded-xl text-xs font-mono border ${
                          faucetBnb === 0
                            ? 'bg-[#D4AF37] text-black border-[#ffe088] font-bold'
                            : 'bg-[#122130] text-[#94a3b8] border-[#1c2b3b]'
                        }`}
                      >
                        0 BNB
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-headline font-semibold text-white mb-1.5">
                      Memo / Transaction Note
                    </label>
                    <input
                      type="text"
                      value={faucetNote}
                      onChange={(e) => setFaucetNote(e.target.value)}
                      placeholder="e.g. Admin Testnet Faucet Node Activation Grant"
                      className="w-full bg-[#122130] border border-[#1c2b3b] focus:border-[#00F0FF] rounded-xl px-3 py-2 text-white text-xs font-mono focus:outline-none"
                    />
                  </div>
                </div>

                {/* Submit Action Button */}
                <button
                  type="submit"
                  disabled={isCreditingFaucet}
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#00F0FF] via-[#38e8f8] to-[#D4AF37] hover:brightness-110 text-[#0A0F1D] font-headline font-extrabold text-sm shadow-[0_0_25px_rgba(0,240,255,0.4)] transition-all flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
                >
                  {isCreditingFaucet ? (
                    <>
                      <span className="material-symbols-outlined text-[20px] animate-spin">progress_activity</span>
                      <span>Injecting Balance into Database...</span>
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[20px]">send</span>
                      <span>Credit +{faucetAmount} USDT to Recipient Wallet</span>
                    </>
                  )}
                </button>
              </form>

              {/* Success Notification Box */}
              {faucetSuccessMsg && (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/50 text-xs font-mono space-y-2 animate-in fade-in duration-300">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <span className="material-symbols-outlined text-[18px]">check_circle</span>
                    <span>Testnet Funds Credited &amp; Synchronized!</span>
                  </div>
                  <div className="space-y-1 text-[#d4e4fa]">
                    <div>
                      Target Address: <span className="text-white font-bold break-all">{faucetSuccessMsg.address}</span>
                    </div>
                    <div>
                      Credited: <span className="text-emerald-400 font-bold">+{faucetSuccessMsg.creditedUsdt} USDT</span>
                      {faucetSuccessMsg.creditedBnb > 0 && <span> and +{faucetSuccessMsg.creditedBnb} BNB</span>}
                    </div>
                    <div>
                      New Available Balance: <span className="text-[#D4AF37] font-bold">${faucetSuccessMsg.newBalance.toFixed(2)} USDT</span>
                    </div>
                    <div className="text-[11px] text-[#94a3b8] pt-1">
                      User can now deploy their node on the dApp immediately with this balance.
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right: Quick Instructions & Faucet Audit (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl p-5 space-y-4 shadow-xl">
                <div className="flex items-center gap-2 text-[#D4AF37] font-bold font-headline text-sm">
                  <span className="material-symbols-outlined text-[18px]">info</span>
                  <span>How Admin Faucet Works</span>
                </div>
                <div className="text-xs text-[#94a3b8] space-y-2.5 leading-relaxed">
                  <div className="flex gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#122130] text-[#00F0FF] flex items-center justify-center shrink-0 font-bold text-[10px]">1</span>
                    <span>User apna dApp kholta hai aur wallet connect karta hai (0 nodes / 0 balance dikhta hai).</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#122130] text-[#00F0FF] flex items-center justify-center shrink-0 font-bold text-[10px]">2</span>
                    <span>Aap admin panel ke is section me aakar uska wallet address paste karke <strong>100 USDT</strong> credit karte hain.</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#122130] text-[#00F0FF] flex items-center justify-center shrink-0 font-bold text-[10px]">3</span>
                    <span>User ke wallet me balance instantly 100 USDT show hota hai, fir wo 15 USDT se node deploy karke real-time mining shuru kar leta hai.</span>
                  </div>
                </div>
              </div>

              {/* Recent Faucet & Adjustment Logs */}
              <div className="bg-[#0d1d2c] border border-[#1c2b3b] rounded-2xl p-5 space-y-3 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold font-headline text-white flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[#00F0FF] text-[16px]">history</span>
                    <span>Recent Balance Adjustments</span>
                  </div>
                  <span className="text-[10px] text-[#94a3b8] font-mono">Live Audit Logs</span>
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {transactions
                    .filter((t) => t.rewardSource?.includes('Faucet') || t.rewardSource?.includes('Admin') || t.amount > 0)
                    .slice(0, 6)
                    .map((tx, idx) => (
                      <div key={`${tx.id || 'tx'}-${idx}`} className="p-2.5 rounded-xl bg-[#122130] border border-[#1c2b3b] text-xs font-mono flex items-center justify-between">
                        <div className="truncate mr-2">
                          <div className="text-white font-semibold truncate">{tx.rewardSource}</div>
                          <div className="text-[10px] text-[#94a3b8] truncate">{tx.txHash}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-emerald-400 font-bold font-mono">+{tx.amount.toFixed(2)} USDT</div>
                          <div className="text-[9px] text-[#94a3b8]">{tx.timestamp}</div>
                        </div>
                      </div>
                    ))}
                  {transactions.length === 0 && (
                    <div className="text-xs text-[#94a3b8] text-center py-4">No adjustment history yet.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT: DOMAIN & SUBLINKS ARCHITECTURE (spikenodes.com)
         ============================================================ */}
      {activeSubTab === 'domain' && (
        <div className="space-y-6">
          {/* Main Domain Status Banner */}
          <div className="rounded-2xl bg-gradient-to-r from-[#0d1d2c] via-[#102235] to-[#0d1d2c] border-2 border-[#00F0FF]/40 p-6 md:p-8 shadow-[0_0_35px_rgba(0,240,255,0.12)]">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#00F0FF] text-[#0A0F1D] flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
                    <span className="material-symbols-outlined text-[16px]">verified</span>
                    PRIMARY DOMAIN
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    SSL / TLS ACTIVE (HTTPS)
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-medium bg-[#1c2b3b] text-[#94a3b8] border border-[#1c2b3b]">
                    ROUTING READY
                  </span>
                </div>

                <div className="flex items-baseline gap-3">
                  <h2 className="text-3xl md:text-4xl font-extrabold font-headline text-white tracking-tight">
                    spikenodes.com
                  </h2>
                </div>

                <p className="text-sm text-[#94a3b8] max-w-2xl leading-relaxed">
                  Aapka official domain <strong className="text-white">spikenodes.com</strong> backend aur frontend ke sath
                  puri tarah adjust ho chuka hai. Saare internal navigation links, referrals, stratum pools, aur API
                  sublinks is domain ke relative paths aur canonical URLs ke sath sync hain.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap lg:flex-col gap-2.5 shrink-0">
                <button
                  onClick={() => copyAdminLink('home')}
                  className="px-4 py-2.5 rounded-xl bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-bold text-xs font-mono transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.3)] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">content_copy</span>
                  <span>Copy Root URL (spikenodes.com)</span>
                </button>
                <button
                  onClick={() => copyAdminLink('admin')}
                  className="px-4 py-2.5 rounded-xl bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#D4AF37] border border-[#D4AF37]/40 font-bold text-xs font-mono transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">link</span>
                  <span>Copy Admin URL (?tab=admin)</span>
                </button>
                <a
                  href="/api/domain/config"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-[#00F0FF] border border-[#1c2b3b] font-bold text-xs font-mono transition-all flex items-center gap-2 text-center justify-center"
                >
                  <span className="material-symbols-outlined text-[18px]">api</span>
                  <span>Inspect Domain JSON API</span>
                </a>
              </div>
            </div>
          </div>

          {/* Sublinks & Routing Directory */}
          <div className="bg-[#0d1d2c] rounded-2xl border border-[#1c2b3b] overflow-hidden shadow-sm">
            <div className="p-5 border-b border-[#1c2b3b] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00F0FF]">account_tree</span>
                  Sublinks &amp; Page URLs Mapping (spikenodes.com)
                </h3>
                <p className="text-xs text-[#94a3b8] mt-0.5">
                  Ye sabhi primary and sublinks live domain par perfectly mapped hain:
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#122130] text-[#00F0FF] text-xs font-mono font-semibold border border-[#00F0FF]/25">
                8 Active Routes
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#091522] text-[#94a3b8] border-b border-[#1c2b3b]">
                  <tr>
                    <th className="p-3.5 pl-5">Module / Feature</th>
                    <th className="p-3.5">Internal Path</th>
                    <th className="p-3.5">Full Canonical URL</th>
                    <th className="p-3.5">Access Type</th>
                    <th className="p-3.5 text-right pr-5">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2b3b]/60">
                  {[
                    {
                      title: 'Public Portal / Landing',
                      icon: 'home',
                      path: '/',
                      tab: 'home',
                      fullUrl: 'https://spikenodes.com/',
                      badge: 'Public',
                      badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
                      desc: 'Home page with live hashrate telemetry & package calculator',
                    },
                    {
                      title: 'User Mining Dashboard',
                      icon: 'dashboard',
                      path: '/?tab=dashboard',
                      tab: 'dashboard',
                      fullUrl: 'https://spikenodes.com/?tab=dashboard',
                      badge: 'Wallet Auth',
                      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
                      desc: 'Personal mining dashboard, live charts, earnings & claim center',
                    },
                    {
                      title: 'Mining Nodes & Hardware Fleet',
                      icon: 'dns',
                      path: '/?tab=mining-nodes',
                      tab: 'mining-nodes',
                      fullUrl: 'https://spikenodes.com/?tab=mining-nodes',
                      badge: 'Wallet Auth',
                      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
                      desc: 'Dedicated ASIC rigs, overclock profiles, fan speed & stratum logs',
                    },
                    {
                      title: 'Affiliate & Referral System',
                      icon: 'groups',
                      path: '/?tab=referrals',
                      tab: 'referrals',
                      fullUrl: 'https://spikenodes.com/?tab=referrals',
                      badge: 'Wallet Auth',
                      badgeColor: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
                      desc: 'Multi-tier rewards, direct referral link generator & milestones',
                    },
                    {
                      title: 'Core Admin Panel (Protected)',
                      icon: 'shield_person',
                      path: '/?tab=admin',
                      tab: 'admin',
                      fullUrl: 'https://spikenodes.com/?tab=admin',
                      badge: 'ROOT Admin',
                      badgeColor: 'text-[#D4AF37] bg-[#D4AF37]/15 border-[#D4AF37]/40',
                      desc: 'Database console, wallet balance adjustments & fleet control',
                    },
                    {
                      title: 'Backend Database Health API',
                      icon: 'health_and_safety',
                      path: '/api/health',
                      tab: null,
                      fullUrl: 'https://spikenodes.com/api/health',
                      badge: 'REST API',
                      badgeColor: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
                      desc: 'JSON uptime, storage status, table counts & memory footprint',
                    },
                    {
                      title: 'Database Backup Export',
                      icon: 'download',
                      path: '/api/db/export',
                      tab: null,
                      fullUrl: 'https://spikenodes.com/api/db/export',
                      badge: 'Download',
                      badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
                      desc: 'Direct atomic JSON database backup file download',
                    },
                  ].map((route) => (
                    <tr key={route.path} className="hover:bg-[#122130]/60 transition-colors">
                      <td className="p-3.5 pl-5">
                        <div className="flex items-center gap-2">
                          <span className="material-symbols-outlined text-[18px] text-[#00F0FF]">{route.icon}</span>
                          <div>
                            <span className="font-bold text-white text-xs">{route.title}</span>
                            <span className="block text-[10px] text-[#94a3b8]">{route.desc}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 text-[#00F0FF] font-semibold">{route.path}</td>
                      <td className="p-3.5 text-white/90 truncate max-w-xs">{route.fullUrl}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${route.badgeColor}`}>
                          {route.badge}
                        </span>
                      </td>
                      <td className="p-3.5 pr-5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              if (navigator?.clipboard?.writeText) {
                                navigator.clipboard.writeText(route.fullUrl);
                                onNotify?.('URL Copied', route.fullUrl, 'success');
                              }
                            }}
                            className="p-1.5 rounded-lg bg-[#122130] hover:bg-[#1c2b3b] text-[#00F0FF] border border-[#1c2b3b] hover:border-[#00F0FF]/40 transition-all cursor-pointer"
                            title="Copy full URL"
                          >
                            <span className="material-symbols-outlined text-[16px]">content_copy</span>
                          </button>
                          {route.tab && (
                            <button
                              onClick={() => onNavigateTab(route.tab as any)}
                              className="px-2.5 py-1 rounded-lg bg-[#122130] hover:bg-[#1c2b3b] text-white hover:text-[#00F0FF] border border-[#1c2b3b] transition-all text-[11px] flex items-center gap-1 cursor-pointer"
                              title="Test navigate inside app"
                            >
                              <span>Open</span>
                              <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
                            </button>
                          )}
                          {!route.tab && (
                            <a
                              href={route.path}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2.5 py-1 rounded-lg bg-[#122130] hover:bg-[#1c2b3b] text-white hover:text-[#00F0FF] border border-[#1c2b3b] transition-all text-[11px] flex items-center gap-1"
                            >
                              <span>API</span>
                              <span className="material-symbols-outlined text-[13px]">open_in_new</span>
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Subdomains & Infrastructure Endpoints */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#0d1d2c] p-5 rounded-2xl border border-[#1c2b3b] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
                <span>Stratum Pool Server</span>
                <span className="material-symbols-outlined text-[#00F0FF] text-[18px]">lan</span>
              </div>
              <div className="text-sm font-bold font-mono text-white break-all">
                pool.spikenodes.com:443
              </div>
              <p className="text-[10px] text-[#94a3b8] leading-relaxed">
                ASIC rig Stratum v1 listener over TLS with automatic vardiff and zero orphan block rate.
              </p>
            </div>

            <div className="bg-[#0d1d2c] p-5 rounded-2xl border border-[#1c2b3b] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
                <span>REST API Gateway</span>
                <span className="material-symbols-outlined text-purple-400 text-[18px]">api</span>
              </div>
              <div className="text-sm font-bold font-mono text-white break-all">
                api.spikenodes.com
              </div>
              <p className="text-[10px] text-[#94a3b8] leading-relaxed">
                Express backend endpoint serving /api/user, /api/nodes, /api/admin, and real-time database state.
              </p>
            </div>

            <div className="bg-[#0d1d2c] p-5 rounded-2xl border border-[#1c2b3b] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
                <span>Validator RPC Sublayer</span>
                <span className="material-symbols-outlined text-emerald-400 text-[18px]">hub</span>
              </div>
              <div className="text-sm font-bold font-mono text-white break-all">
                rpc.spikenodes.com
              </div>
              <p className="text-[10px] text-[#94a3b8] leading-relaxed">
                Direct RPC connector validating on BSC smart contract with instant epoch rewards claim.
              </p>
            </div>

            <div className="bg-[#0d1d2c] p-5 rounded-2xl border border-[#1c2b3b] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#94a3b8]">
                <span>Knowledgebase & Docs</span>
                <span className="material-symbols-outlined text-amber-400 text-[18px]">menu_book</span>
              </div>
              <div className="text-sm font-bold font-mono text-white break-all">
                docs.spikenodes.com
              </div>
              <p className="text-[10px] text-[#94a3b8] leading-relaxed">
                Complete mining rig guide, smart contract addresses, referral plan breakdown, and API references.
              </p>
            </div>
          </div>

          {/* DNS Records Guide for spikenodes.com */}
          <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-[#D4AF37]">dns</span>
                Domain DNS Records Reference (spikenodes.com)
              </h3>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                DNS Ready
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] space-y-1">
                <div className="text-[#94a3b8] flex justify-between">
                  <span>Record: <strong>A</strong></span>
                  <span className="text-emerald-400">Host: @</span>
                </div>
                <div className="text-white font-bold truncate">Server IP / Edge CDN</div>
                <div className="text-[10px] text-[#94a3b8]">Points spikenodes.com to live app</div>
              </div>

              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] space-y-1">
                <div className="text-[#94a3b8] flex justify-between">
                  <span>Record: <strong>CNAME</strong></span>
                  <span className="text-emerald-400">Host: www</span>
                </div>
                <div className="text-white font-bold truncate">spikenodes.com</div>
                <div className="text-[10px] text-[#94a3b8]">Redirects www.spikenodes.com to root</div>
              </div>

              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] space-y-1">
                <div className="text-[#94a3b8] flex justify-between">
                  <span>Record: <strong>CNAME</strong></span>
                  <span className="text-emerald-400">Host: pool</span>
                </div>
                <div className="text-white font-bold truncate">stratum.spikenodes.com</div>
                <div className="text-[10px] text-[#94a3b8]">Directs ASIC hashrate to Stratum engine</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 2: USER & WALLET MANAGEMENT
         ============================================================ */}
      {activeSubTab === 'users' && (
        <div className="space-y-6">
          {/* Hashrate Notification Banner */}
          {hashrateBannerMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 flex items-center justify-between text-xs font-mono text-emerald-300 shadow-lg animate-fade-in">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-400 text-[18px]">verified</span>
                <span>
                  Hashrate for <strong>{hashrateBannerMsg.address}</strong> updated to{' '}
                  <span className="text-[#00F0FF] font-bold">{hashrateBannerMsg.hashrate} VH/s</span> ({hashrateBannerMsg.level}) · 1 SPIKE in {hashrateBannerMsg.days} days!
                </span>
              </div>
              <button
                onClick={() => setHashrateBannerMsg(null)}
                className="text-gray-400 hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            </div>
          )}

          {/* ============================================================
              DEDICATED PROTOCOL HASHRATE CONTROLLER (PER IMAGE SPEC)
             ============================================================ */}
          <div className="bg-[#0a1826] border-2 border-[#00F0FF]/40 rounded-2xl p-5 md:p-6 space-y-5 shadow-xl relative overflow-hidden">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-[#1c2b3b] pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00F0FF] text-[22px]">speed</span>
                  <h3 className="text-base font-bold font-headline text-white">
                    Protocol Mining Hashrate &amp; Referral Tier Controller
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30 font-mono">
                    VH/s Engine
                  </span>
                </div>
                <p className="text-xs text-[#94a3b8] mt-1">
                  Formula: <code className="text-[#00F0FF] font-bold">Required Hashrate = 100 × (60 / Target Days)</code>. Direct referrals aur team size se user ka speed automatically upgrade hota hai, ya admin kisi bhi address ka custom hashrate lock kar sakta hai.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] font-mono text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 rounded-lg border border-[#D4AF37]/30">
                  Base: 100 VH/s (60d)
                </span>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/30">
                  Max: 857.14 VH/s (7d)
                </span>
              </div>
            </div>

            {/* 5-Level Reference Matrix Matching Image */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {HASHRATE_LEVEL_TIERS.map((tier, idx) => (
                <div
                  key={tier.level}
                  onClick={() => {
                    setSelectedHashratePreset(tier.hashrate);
                    setCustomHashrateVal(String(tier.hashrate));
                  }}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    selectedHashratePreset === tier.hashrate
                      ? 'bg-[#00F0FF]/15 border-[#00F0FF] shadow-[0_0_15px_rgba(0,240,255,0.25)]'
                      : 'bg-[#0d1d2c] border-[#1c2b3b] hover:border-[#00F0FF]/40'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] font-bold font-headline">
                    <span className="text-white">{tier.level}</span>
                    <span className="text-[#00F0FF] font-mono">{tier.hashrate} VH/s</span>
                  </div>
                  <div className="text-[10px] text-[#D4AF37] font-mono mt-1 font-semibold">
                    {tier.directs}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                    1 SPK in {tier.targetDays} days
                  </div>
                </div>
              ))}
            </div>

            {/* Target Address Control Form */}
            <div className="bg-[#0d1d2c] rounded-xl p-4 border border-[#1c2b3b] space-y-4">
              <div className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-[#00F0FF]">tune</span>
                <span>Override Hashrate for Specific Wallet Address</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs font-mono">
                {/* Address Input / Select */}
                <div className="md:col-span-5 space-y-1">
                  <label className="text-[#94a3b8] text-[11px]">Target Wallet Address</label>
                  <input
                    type="text"
                    placeholder="0x... paste BEP-20 address"
                    value={targetHashrateAddr}
                    onChange={(e) => setTargetHashrateAddr(e.target.value)}
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
                  />
                  {users.length > 0 && (
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          setTargetHashrateAddr(e.target.value);
                          const sel = users.find((u) => u.address.toLowerCase() === e.target.value.toLowerCase());
                          if (sel?.hashrateInfo?.hashrate) {
                            setSelectedHashratePreset(sel.hashrateInfo.hashrate);
                            setCustomHashrateVal(String(sel.hashrateInfo.hashrate));
                          }
                        }
                      }}
                      className="w-full bg-[#071322] border border-[#1c2b3b] rounded-lg px-2 py-1 text-[10px] text-[#94a3b8] mt-1"
                    >
                      <option value="">Quick select from registered users ({users.length})...</option>
                      {users.map((u) => (
                        <option key={u.address} value={u.address}>
                          {u.address.slice(0, 10)}...{u.address.slice(-6)} - {u.hashrateInfo?.level || 'Fresh'} ({u.hashrateInfo?.hashrate || 100} VH/s)
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Hashrate Value */}
                <div className="md:col-span-3 space-y-1">
                  <label className="text-[#94a3b8] text-[11px]">Hashrate (VH/s units)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    placeholder="e.g. 200"
                    value={customHashrateVal}
                    onChange={(e) => {
                      setCustomHashrateVal(e.target.value);
                      setSelectedHashratePreset(Number(e.target.value));
                    }}
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-[#00F0FF] font-mono font-bold focus:outline-none focus:border-[#00F0FF]"
                  />
                  <div className="text-[10px] text-gray-400">
                    Target: 1 SPK in {Number(customHashrateVal) > 0 ? +(6000 / Number(customHashrateVal)).toFixed(1) : 60} days
                  </div>
                </div>

                {/* Reason */}
                <div className="md:col-span-4 space-y-1">
                  <label className="text-[#94a3b8] text-[11px]">Reason / Note</label>
                  <input
                    type="text"
                    placeholder="e.g. Tier qualification grant"
                    value={hashrateChangeReason}
                    onChange={(e) => setHashrateChangeReason(e.target.value)}
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-3.5 py-2 text-white font-mono placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
                  />
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      disabled={isUpdatingHashrate || !targetHashrateAddr.trim()}
                      onClick={() => handleSaveUserHashrate(targetHashrateAddr, Number(customHashrateVal) || 100, hashrateChangeReason)}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-headline font-bold text-xs disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-sm flex items-center justify-center gap-1"
                    >
                      {isUpdatingHashrate ? 'Saving...' : 'Apply Hashrate'}
                    </button>
                    <button
                      type="button"
                      disabled={isUpdatingHashrate || !targetHashrateAddr.trim()}
                      onClick={() => handleSaveUserHashrate(targetHashrateAddr, null, 'Reset to auto-calculated tier')}
                      className="py-1.5 px-3 rounded-lg bg-[#1c2b3b] hover:bg-[#273647] text-[#94a3b8] hover:text-white font-mono text-[11px] disabled:opacity-40 cursor-pointer"
                      title="Reset to referral calculation"
                    >
                      Reset Auto
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <div className="relative flex-1 max-w-md">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[18px] text-[#94a3b8]">
                search
              </span>
              <input
                type="text"
                placeholder="Search wallet address or referral code..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                className="w-full bg-[#0d1d2c] border border-[#1c2b3b] rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-white placeholder-[#94a3b8]/60 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>

            <div className="text-xs text-[#94a3b8] font-mono">
              Showing {filteredUsers.length} of {users.length} registered wallets
            </div>
          </div>

          <div className="bg-[#0d1d2c] rounded-2xl border border-[#1c2b3b] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#122130] text-[#94a3b8] border-b border-[#1c2b3b]">
                    <th className="p-4">Wallet Address</th>
                    <th className="p-4">Directs / Team</th>
                    <th className="p-4">Mining Hashrate</th>
                    <th className="p-4">1 SPK Time</th>
                    <th className="p-4">Balance (USDT)</th>
                    <th className="p-4">Gas (BNB)</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Ref Code</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2b3b]/60">
                  {filteredUsers.map((user) => (
                    <tr key={user.address} className="hover:bg-[#122130]/40 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-white flex items-center gap-2">
                          <span className="text-[#00F0FF]">{user.address.slice(0, 10)}...{user.address.slice(-6)}</span>
                          {user.role === 'admin' && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">
                              ADMIN
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#94a3b8]">Joined: {new Date(user.createdAt).toLocaleDateString()}</div>
                      </td>

                      <td className="p-4">
                        <div className="text-white font-bold">{user.directPartners ?? 0} Directs</div>
                        <div className="text-[10px] text-[#D4AF37] font-semibold">{user.totalPartners ?? 0} Total Team</div>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                            {user.hashrateInfo?.hashrate || user.customHashrate || 100} VH/s
                          </span>
                        </div>
                        <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">
                          {user.hashrateInfo?.level || 'Fresh user'}
                        </div>
                        {user.customHashrate && (
                          <span className="text-[9px] text-[#D4AF37] block font-mono">
                            Admin Lock
                          </span>
                        )}
                      </td>

                      <td className="p-4 text-white font-bold font-mono">
                        {user.hashrateInfo?.targetDays || 60} Days
                      </td>

                      <td className="p-4 text-white font-bold tabular-nums">
                        ${user.balanceUsdt.toFixed(2)}
                      </td>

                      <td className="p-4 text-amber-400 font-bold tabular-nums">
                        {user.balanceBnb.toFixed(4)} BNB
                      </td>

                      <td className="p-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            user.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : 'bg-red-500/20 text-red-400 border border-red-500/40'
                          }`}
                        >
                          {user.status.toUpperCase()}
                        </span>
                      </td>

                      <td className="p-4 text-[#94a3b8]">
                        <div className="font-mono text-white text-xs">{user.referralCode}</div>
                        {user.referredBy && (
                          <div className="text-[10px] text-[#00F0FF] font-mono mt-0.5" title={`Referred by ${user.referredBy}`}>
                            Ref by: {user.referredBy.slice(0, 6)}...{user.referredBy.slice(-4)}
                          </div>
                        )}
                      </td>

                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setHashrateModalUser(user);
                              setCustomHashrateVal(String(user.hashrateInfo?.hashrate || user.customHashrate || 100));
                              setSelectedHashratePreset(user.hashrateInfo?.hashrate || user.customHashrate || 100);
                            }}
                            className="px-2 py-1.5 rounded-lg bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 text-[#D4AF37] border border-[#D4AF37]/30 text-[11px] font-semibold transition-all flex items-center gap-1 cursor-pointer"
                            title="Set Hashrate for Wallet"
                          >
                            <span className="material-symbols-outlined text-[14px]">speed</span>
                            Hashrate
                          </button>

                          <button
                            onClick={() => {
                              setAdjustModalUser(user);
                              setAdjustAmount(50);
                              setAdjustType('credit');
                            }}
                            className="px-2 py-1.5 rounded-lg bg-[#00F0FF]/15 hover:bg-[#00F0FF]/25 text-[#00F0FF] border border-[#00F0FF]/30 text-[11px] font-semibold transition-all flex items-center gap-1 cursor-pointer"
                            title="Credit or Debit Balance in DB"
                          >
                            <span className="material-symbols-outlined text-[14px]">tune</span>
                            Adjust
                          </button>

                          <button
                            onClick={() => handleToggleUserStatus(user)}
                            className={`p-1.5 rounded-lg border text-[11px] transition-all cursor-pointer ${
                              user.status === 'active'
                                ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border-red-500/30'
                                : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                            }`}
                            title={user.status === 'active' ? 'Freeze User' : 'Unfreeze User'}
                          >
                            <span className="material-symbols-outlined text-[16px]">
                              {user.status === 'active' ? 'lock' : 'lock_open'}
                            </span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 3: RIG & FLEET CONTROLLER
         ============================================================ */}
      {activeSubTab === 'nodes' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {(['all', 'mining', 'idle', 'stopped'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setNodeFilter(status)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold capitalize transition-all ${
                    nodeFilter === status
                      ? 'bg-[#00F0FF] text-[#0A0F1D] shadow-[0_0_10px_rgba(0,240,255,0.4)]'
                      : 'bg-[#0d1d2c] text-[#94a3b8] hover:bg-[#122130] border border-[#1c2b3b]'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="text-xs text-[#94a3b8] font-mono">
              Total Rigs: {nodes.length} · Combined Hashrate:{' '}
              {nodes.reduce((s, n) => s + (n.status === 'mining' ? n.hashrate : 0), 0).toFixed(1)} TH/s
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredNodes.map((node) => (
              <div
                key={node.id}
                className="bg-[#0d1d2c] rounded-2xl p-5 border border-[#1c2b3b] space-y-4 hover:border-[#00F0FF]/40 transition-all shadow-sm"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold font-headline text-white text-base">{node.name}</h4>
                    <span className="text-[10px] text-[#94a3b8] font-mono">{node.region}</span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      node.status === 'mining'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    }`}
                  >
                    {node.status.toUpperCase()}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-[#122130] text-center font-mono">
                  <div>
                    <div className="text-[9px] text-[#94a3b8] uppercase">Hashrate</div>
                    <div className="text-sm font-bold text-[#00F0FF]">{node.hashrate} TH/s</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#94a3b8] uppercase">Temp</div>
                    <div className="text-sm font-bold text-amber-400">{node.temperature}°C</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#94a3b8] uppercase">Shares</div>
                    <div className="text-sm font-bold text-emerald-400">{node.shareAcceptance}%</div>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-[#94a3b8] space-y-1">
                  <div className="flex justify-between">
                    <span>Power:</span>
                    <span className="text-white">{node.powerUsage}W</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Owner:</span>
                    <span className="text-[#00F0FF]">{node.userAddress ? `${node.userAddress.slice(0, 8)}...` : 'Core'}</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  {node.status === 'mining' ? (
                    <button
                      onClick={() => handleNodeAction(node.id, 'stop')}
                      className="flex-1 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/40 text-xs font-mono font-semibold transition-all flex items-center justify-center gap-1"
                    >
                      <span className="material-symbols-outlined text-[15px]">pause</span>
                      Pause
                    </button>
                  ) : (
                    <button
                      onClick={() => handleNodeAction(node.id, 'start')}
                      className="flex-1 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/40 text-xs font-mono font-semibold transition-all flex items-center justify-center gap-1"
                    >
                      <span className="material-symbols-outlined text-[15px]">play_arrow</span>
                      Start
                    </button>
                  )}

                  <button
                    onClick={() => handleNodeAction(node.id, 'restart')}
                    className="p-1.5 rounded-lg bg-[#122130] hover:bg-[#1c2b3b] text-[#d4e4fa] border border-[#1c2b3b] transition-all"
                    title="Cold Restart Rig"
                  >
                    <span className="material-symbols-outlined text-[16px]">restart_alt</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 4: LEDGER & TRANSACTIONS
         ============================================================ */}
      {activeSubTab === 'transactions' && (
        <div className="space-y-4">
          <div className="bg-[#0d1d2c] rounded-2xl border border-[#1c2b3b] overflow-hidden">
            <div className="p-4 border-b border-[#1c2b3b] flex items-center justify-between">
              <h3 className="font-bold text-white text-sm font-headline flex items-center gap-2">
                <span className="material-symbols-outlined text-blue-400">receipt_long</span>
                Master Transaction Ledger ({transactions.length} entries)
              </h3>
              <span className="text-xs text-[#94a3b8] font-mono">Synced from backend DB</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#122130] text-[#94a3b8] border-b border-[#1c2b3b]">
                    <th className="p-3.5">Tx ID</th>
                    <th className="p-3.5">User Address</th>
                    <th className="p-3.5">Type & Reason</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">BSC Tx Hash</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2b3b]/60">
                  {transactions.map((tx, idx) => (
                    <tr key={`${tx.id || 'tx'}-${idx}`} className="hover:bg-[#122130]/40 transition-colors">
                      <td className="p-3.5 text-white font-medium">{tx.id}</td>
                      <td className="p-3.5 text-[#00F0FF]">
                        {tx.userAddress ? `${tx.userAddress.slice(0, 8)}...` : 'System'}
                      </td>
                      <td className="p-3.5 text-white capitalize">{tx.rewardSource || tx.type}</td>
                      <td
                        className={`p-3.5 font-bold ${
                          tx.amount >= 0 ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        {tx.amount >= 0 ? `+${tx.amount.toFixed(2)}` : tx.amount.toFixed(2)} {tx.currency}
                      </td>
                      <td className="p-3.5 text-[#94a3b8]">
                        <span className="hover:text-[#00F0FF] cursor-pointer" title={tx.txHash}>
                          {tx.txHash ? `${tx.txHash.slice(0, 10)}...` : 'Pending'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                          {tx.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-[#94a3b8]">{tx.timestamp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 5: SYSTEM SETTINGS & YIELD
         ============================================================ */}
      {activeSubTab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
            <h3 className="text-lg font-bold font-headline text-white flex items-center gap-2">
              <span className="material-symbols-outlined text-purple-400">tune</span>
              Mining Protocol Configuration
            </h3>

            <div className="space-y-4 text-xs font-mono">
              <div>
                <label className="block text-[#94a3b8] mb-1">
                  Turbo Overclock Multiplier (Locked Standard)
                </label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={settingsForm.turboMultiplier || 10}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, turboMultiplier: Number(e.target.value) }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
                <span className="text-[10px] text-[#94a3b8] mt-1 block">
                  Current Turbo multiplier applied to ASIC mining nodes (Default: 10X).
                </span>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">
                  Base Hashrate Per $5 Mining Node (TH/s)
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0.1"
                    max="20"
                    step="0.05"
                    value={settingsForm.baseHashrateTh || 1.25}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, baseHashrateTh: Number(e.target.value) }))
                    }
                    className="flex-1 accent-[#00F0FF] cursor-pointer"
                  />
                  <input
                    type="number"
                    step="0.05"
                    value={settingsForm.baseHashrateTh || 1.25}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, baseHashrateTh: Number(e.target.value) }))
                    }
                    className="w-24 bg-[#122130] border border-[#1c2b3b] rounded-xl px-3 py-1.5 text-white font-mono text-center focus:outline-none focus:border-[#00F0FF]"
                  />
                  <span className="text-[#00F0FF] font-bold">TH/s</span>
                </div>
                <span className="text-[10px] text-emerald-400 mt-1 block">
                  Admin-controlled hashrate allocated to users upon $5 treasury deposit.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#94a3b8] mb-1">Mining Cycle Duration (Hours)</label>
                  <input
                    type="number"
                    min="1"
                    max="72"
                    value={settingsForm.miningCycleHours || 24}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, miningCycleHours: Number(e.target.value) }))
                    }
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  />
                  <span className="text-[10px] text-[#94a3b8] mt-1 block">Standard 24-hour cycle</span>
                </div>

                <div>
                  <label className="block text-[#94a3b8] mb-1">24h Claim Reward Yield (SPIKE)</label>
                  <input
                    type="number"
                    step="1"
                    value={settingsForm.dailyRewardSpk || 35.0}
                    onChange={(e) =>
                      setSettingsForm((prev) => ({ ...prev, dailyRewardSpk: Number(e.target.value) }))
                    }
                    className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  />
                  <span className="text-[10px] text-[#94a3b8] mt-1 block">Amount auto-bought via PancakeSwap</span>
                </div>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">PancakeSwap V2 Router Contract</label>
                <input
                  type="text"
                  value={settingsForm.pancakeRouterAddress || '0x10ED43C718714eb63d5aA57B78B54704E256024E'}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, pancakeRouterAddress: e.target.value }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-[#00F0FF]"
                />
                <span className="text-[10px] text-[#00F0FF]/80 mt-1 block">
                  Router executing smart contract auto-buy swaps into user's MetaMask/Web3 wallet upon claim.
                </span>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">PancakeSwap Liquidity Pool (Pair) Contract</label>
                <input
                  type="text"
                  value={settingsForm.pancakePairAddress || '0xdB75fAB72e56492CFE870344D115C57047992F3c'}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, pancakePairAddress: e.target.value }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-[#D4AF37]"
                />
                <span className="text-[10px] text-[#D4AF37] mt-1 block">
                  Official PancakeSwap AMM Liquidity Pool pair (0xdB75fAB72e56492CFE870344D115C57047992F3c) for SPIKE/USDT swaps &amp; mining claims.
                </span>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Daily Yield ROI (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={settingsForm.dailyYieldPercent || 3.88}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, dailyYieldPercent: Number(e.target.value) }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Stratum Pool Endpoint URL</label>
                <input
                  type="text"
                  value={settingsForm.stratumPoolUrl || ''}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, stratumPoolUrl: e.target.value }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">BSC Smart Contract Address</label>
                <input
                  type="text"
                  value={settingsForm.bscContractAddress || ''}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, bscContractAddress: e.target.value }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">
                  Official Protocol Treasury Wallet Address (BEP-20 / EVM)
                </label>
                <input
                  type="text"
                  value={treasuryAddressInput}
                  onChange={(e) => setTreasuryAddressInput(e.target.value)}
                  placeholder="0x..."
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white font-mono focus:outline-none focus:border-[#D4AF37]"
                />
                <span className="text-[10px] text-amber-300/80 mt-1 block">
                  Official company vault for all worldwide $5 USDT Step 1 deposits. Non-claimable by users.
                </span>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Minimum Claim / Withdrawal (USDT)</label>
                <input
                  type="number"
                  value={settingsForm.minWithdrawalUsdt || 5.0}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, minWithdrawalUsdt: Number(e.target.value) }))
                  }
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]">
                <div>
                  <div className="font-bold text-white">Emergency Maintenance Mode</div>
                  <div className="text-[10px] text-[#94a3b8]">
                    When active, pauses user claims & new activations.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={!!settingsForm.maintenanceMode}
                  onChange={(e) =>
                    setSettingsForm((prev) => ({ ...prev, maintenanceMode: e.target.checked }))
                  }
                  className="w-5 h-5 rounded accent-red-500 cursor-pointer"
                />
              </div>

              <button
                onClick={handleSaveSettings}
                className="w-full py-3 rounded-xl bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-bold text-sm transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)] mt-2"
              >
                Save Protocol Configuration to Database
              </button>
            </div>
          </div>

          {/* Right Column: Treasury Vault Controller + Access Control */}
          <div className="space-y-6">
            {/* OFFICIAL PROTOCOL TREASURY WALLET CONTROLLER CARD */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#D4AF37]/40 shadow-xl space-y-5 relative overflow-hidden">
              <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-[#D4AF37]/5 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                    <span className="material-symbols-outlined text-[24px]">account_balance</span>
                  </div>
                  <div>
                    <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                      <span>Official Treasury Vault Controller</span>
                    </h3>
                    <span className="text-[11px] text-amber-300 font-mono flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Company Official Vault • Non-Claimable Reserve
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-mono text-[#94a3b8] uppercase font-bold">Accumulated Vault Fund</div>
                  <div className="text-xl font-black font-headline text-[#D4AF37]">
                    ${treasuryInfo.treasuryBalanceUsdt.toLocaleString('en-US', { minimumFractionDigits: 2 })}{' '}
                    <span className="text-xs font-mono text-white">USDT</span>
                  </div>
                </div>
              </div>

              {/* Protocol Architecture Explanation */}
              <div className="p-3.5 rounded-xl bg-[#122130] border border-[#1c2b3b] space-y-2 text-xs font-mono">
                <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">verified_user</span>
                  <span>Protocol Architecture & Worldwide Rules:</span>
                </div>
                <ul className="space-y-1.5 text-[#94a3b8] text-[11px] pl-1">
                  <li className="flex items-start gap-1.5">
                    <span className="text-[#00F0FF]">1.</span>
                    <span>
                      <strong className="text-white">Worldwide Inflow:</strong> All users worldwide deposit their Step 1 ($5 USDT Protocol Entry Fee) directly to this address.
                    </span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-[#00F0FF]">2.</span>
                    <span>
                      <strong className="text-white">Non-Claimable by Users:</strong> Ye company ka official wallet hai. Is fund ko koi bhi regular user claim ya withdraw nahi kar sakta.
                    </span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-[#00F0FF]">3.</span>
                    <span>
                      <strong className="text-white">Mining Activation Gate:</strong> Treasury wallet me fund aane ke baad hi mining activation (Step 2: $10 USDT) proceed hoti hai.
                    </span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-[#00F0FF]">4.</span>
                    <span>
                      <strong className="text-white">Live User Synchronization:</strong> Is address ko yha change karne par user panel aur deposit modal me turant live implement ho jata hai.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Change / Edit Treasury Wallet Address Section */}
              <div className="space-y-3 pt-1">
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-1.5">
                    <label className="text-white font-bold flex items-center gap-1">
                      <span>Change Official Treasury Wallet Address</span>
                    </label>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        /^0x[a-fA-F0-9]{40}$/.test(treasuryAddressInput.trim())
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      }`}
                    >
                      {/^0x[a-fA-F0-9]{40}$/.test(treasuryAddressInput.trim())
                        ? '✓ Valid EVM Address'
                        : '⚠️ Enter 42-char 0x Address'}
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={treasuryAddressInput}
                      onChange={(e) => setTreasuryAddressInput(e.target.value)}
                      placeholder="0x..."
                      className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl pl-3.5 pr-20 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#D4AF37]"
                    />
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(treasuryAddressInput);
                        onNotify?.('Copied', 'Treasury address copied to clipboard', 'info');
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 rounded bg-[#1c2b3b] hover:bg-[#273647] text-[#00F0FF] text-[10px] font-mono"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                {/* Preset Chips */}
                <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono">
                  <span className="text-[#94a3b8]">Quick Presets:</span>
                  <button
                    type="button"
                    onClick={() => setTreasuryAddressInput('0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7')}
                    className="px-2 py-0.5 rounded bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-[#D4AF37]"
                    title="Default Protocol Multi-Sig Address"
                  >
                    Default Multi-Sig (0xDE7B...a4c7)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTreasuryAddressInput('0x96F86413D8E5d15ecE42E136CC8112c01b9A7306')}
                    className="px-2 py-0.5 rounded bg-[#122130] hover:bg-[#1c2b3b] border border-[#1c2b3b] text-[#00F0FF]"
                    title="BSC Testnet SPIKE Token Deployer Contract"
                  >
                    SPIKE Testnet (0x96F8...7306)
                  </button>
                </div>

                {/* Submit Update Button */}
                <button
                  type="button"
                  onClick={() => handleUpdateTreasuryAddress()}
                  disabled={isSavingTreasury || !/^0x[a-fA-F0-9]{40}$/.test(treasuryAddressInput.trim())}
                  className={`w-full py-3 rounded-xl font-bold font-headline text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                    isSavingTreasury || !/^0x[a-fA-F0-9]{40}$/.test(treasuryAddressInput.trim())
                      ? 'bg-gray-700 text-gray-400 cursor-not-allowed opacity-60'
                      : 'bg-gradient-to-r from-[#D4AF37] to-[#f59e0b] hover:from-[#ffe088] hover:to-[#fbbf24] text-[#051424] cursor-pointer shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                  }`}
                >
                  <span className="material-symbols-outlined text-[16px]">
                    {isSavingTreasury ? 'sync' : 'upgrade'}
                  </span>
                  <span>
                    {isSavingTreasury ? 'Updating Protocol Treasury...' : 'Save & Implement in User Panel'}
                  </span>
                </button>
                <div className="text-[10px] text-center text-[#94a3b8] font-mono">
                  Changes take effect immediately across all user screens without reloading.
                </div>
              </div>
            </div>

            {/* Access Control & Security Card */}
            <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-4">
              <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-[#D4AF37]">security</span>
                Access Control & Security
              </h3>
              <p className="text-xs text-[#94a3b8] leading-relaxed">
                All settings updates and database modifications trigger an automated entry in the system
                `audit_logs` collection. Every administrative command includes cryptographic timestamping.
              </p>
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b] text-xs font-mono text-emerald-400">
                🔒 Root Administrator Access: Active (Session Verified)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          TAB CONTENT 6: DATABASE HEALTH & AUDIT LOGS
         ============================================================ */}
      {activeSubTab === 'database' && (
        <div className="space-y-6">
          {/* FIREBASE FIRESTORE CLOUD INTEGRATION CARD */}
          <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <span className="material-symbols-outlined text-2xl">local_fire_department</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold font-headline text-white">
                      Google Firebase Firestore Cloud Storage
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      ACTIVE & CONNECTED
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Real-time cloud database persistent storage and Firebase Hosting configuration
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSyncFirebase}
                  disabled={syncingFirebase}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-[#0A0F1D] font-bold text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(245,158,11,0.3)] transition-all disabled:opacity-50"
                >
                  <span className={`material-symbols-outlined text-sm ${syncingFirebase ? 'animate-spin' : ''}`}>
                    sync
                  </span>
                  {syncingFirebase ? 'Syncing to Firestore...' : 'Sync All to Firestore'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]/60 space-y-1">
                <span className="text-[10px] uppercase font-mono text-[#94a3b8]">Cloud Project ID</span>
                <div className="text-xs font-mono font-bold text-amber-300 truncate">
                  glassy-fountain-lsmzh
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]/60 space-y-1">
                <span className="text-[10px] uppercase font-mono text-[#94a3b8]">Firestore Database</span>
                <div className="text-xs font-mono font-bold text-white truncate" title="ai-studio-spikeweb3cryptom-fdb9d06e-51b7-4001-8d57-7aeb0361ee6d">
                  ai-studio-spikeweb3cryptom...
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]/60 space-y-1">
                <span className="text-[10px] uppercase font-mono text-[#94a3b8]">Security Rules</span>
                <div className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">verified_user</span>
                  Hardened ABAC Deployed
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]/60 space-y-1">
                <span className="text-[10px] uppercase font-mono text-[#94a3b8]">Custom Domain Host</span>
                <div className="text-xs font-mono font-bold text-[#00F0FF]">
                  spikenodes.com
                </div>
              </div>
            </div>

            {/* Firestore Collections Blueprint */}
            <div className="p-4 rounded-xl bg-[#122130]/60 border border-[#1c2b3b]/60 space-y-3">
              <span className="text-xs font-mono text-[#94a3b8] block font-bold">
                Active Firestore Database Collections:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-lg bg-[#0d1d2c] border border-[#1c2b3b] text-center">
                  <div className="text-white font-bold">/users</div>
                  <div className="text-[10px] text-[#94a3b8]">{users.length} Wallets</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#0d1d2c] border border-[#1c2b3b] text-center">
                  <div className="text-white font-bold">/nodes</div>
                  <div className="text-[10px] text-[#94a3b8]">{nodes.length} Mining Units</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#0d1d2c] border border-[#1c2b3b] text-center">
                  <div className="text-white font-bold">/transactions</div>
                  <div className="text-[10px] text-[#94a3b8]">{transactions.length} Ledger TXs</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#0d1d2c] border border-[#1c2b3b] text-center">
                  <div className="text-white font-bold">/settings</div>
                  <div className="text-[10px] text-[#94a3b8]">spikenodes.com</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#0d1d2c] border border-[#1c2b3b] text-center">
                  <div className="text-white font-bold">/auditLogs</div>
                  <div className="text-[10px] text-[#94a3b8]">{auditLogs.length} Events</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0d1d2c] rounded-2xl p-6 border border-[#1c2b3b] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold font-headline text-white flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-400">terminal</span>
                Live Audit Logs & System Activity ({auditLogs.length})
              </h3>
              <span className="text-xs text-[#94a3b8] font-mono">Immutable audit stream</span>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-2 scrollbar-thin">
              {auditLogs.map((log, idx) => (
                <div
                  key={`${log.id || 'log'}-${idx}`}
                  className="p-3 rounded-xl bg-[#122130] border border-[#1c2b3b]/60 text-xs font-mono flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-400 border border-blue-500/40">
                        {log.action}
                      </span>
                      <span className="text-white font-bold">{log.target}</span>
                    </div>
                    <div className="text-[#94a3b8] text-[11px]">{log.details}</div>
                  </div>
                  <div className="text-[10px] text-[#94a3b8] shrink-0">
                    {new Date(log.timestamp).toLocaleString()} by {log.adminUser}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          MODAL: ADJUST WALLET BALANCE
         ============================================================ */}
      {adjustModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0d1d2c] rounded-2xl max-w-md w-full border border-[#1c2b3b] p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold font-headline text-white">Adjust Wallet Balance</h3>
              <button
                onClick={() => setAdjustModalUser(null)}
                className="text-[#94a3b8] hover:text-white"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="text-xs font-mono space-y-1">
              <div className="text-[#94a3b8]">Target Wallet:</div>
              <div className="text-[#00F0FF] font-bold break-all">{adjustModalUser.address}</div>
              <div className="text-[#94a3b8] pt-1">
                Current Balance:{' '}
                <span className="text-white font-bold">${adjustModalUser.balanceUsdt.toFixed(2)} USDT</span>
              </div>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div>
                <label className="block text-[#94a3b8] mb-1">Adjustment Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('credit')}
                    className={`py-2 rounded-lg font-bold transition-all ${
                      adjustType === 'credit'
                        ? 'bg-emerald-500 text-black'
                        : 'bg-[#122130] text-[#94a3b8] border border-[#1c2b3b]'
                    }`}
                  >
                    + Credit USDT
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('debit')}
                    className={`py-2 rounded-lg font-bold transition-all ${
                      adjustType === 'debit'
                        ? 'bg-red-500 text-white'
                        : 'bg-[#122130] text-[#94a3b8] border border-[#1c2b3b]'
                    }`}
                  >
                    - Debit USDT
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Amount (USDT)</label>
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(Number(e.target.value))}
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Reason / Note</label>
                <input
                  type="text"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setAdjustModalUser(null)}
                className="flex-1 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-[#94a3b8] font-mono text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteAdjustBalance}
                className="flex-1 py-2.5 rounded-xl bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-mono text-xs font-bold shadow-[0_0_15px_rgba(0,240,255,0.3)]"
              >
                Confirm in DB
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          MODAL: SET USER HASHRATE (IMAGE SPECIFICATION)
         ============================================================ */}
      {hashrateModalUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-[#0d1d2c] rounded-2xl max-w-lg w-full border border-[#00F0FF]/40 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1c2b3b] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00F0FF]">speed</span>
                <h3 className="text-lg font-bold font-headline text-white">Set Wallet Hashrate Level</h3>
              </div>
              <button
                onClick={() => setHashrateModalUser(null)}
                className="text-[#94a3b8] hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="text-xs font-mono space-y-1.5 p-3 rounded-xl bg-[#071322] border border-[#1c2b3b]">
              <div className="text-[#94a3b8]">Target Wallet:</div>
              <div className="text-[#00F0FF] font-bold break-all">{hashrateModalUser.address}</div>
              <div className="flex items-center gap-3 pt-1 text-[11px]">
                <span className="text-white font-bold">{hashrateModalUser.directPartners || 0} Directs</span>
                <span className="text-[#94a3b8]">·</span>
                <span className="text-[#D4AF37] font-bold">{hashrateModalUser.totalPartners || 0} Total Team</span>
                <span className="text-[#94a3b8]">·</span>
                <span className="text-emerald-400 font-bold">Current: {hashrateModalUser.hashrateInfo?.hashrate || 100} VH/s</span>
              </div>
            </div>

            {/* Presets Grid */}
            <div className="space-y-2">
              <label className="text-[11px] text-[#94a3b8] font-mono">Select Level Preset (Image Formula):</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                {HASHRATE_LEVEL_TIERS.map((tier) => (
                  <button
                    key={tier.level}
                    type="button"
                    onClick={() => {
                      setSelectedHashratePreset(tier.hashrate);
                      setCustomHashrateVal(String(tier.hashrate));
                    }}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                      Number(customHashrateVal) === tier.hashrate
                        ? 'bg-[#00F0FF]/15 border-[#00F0FF] text-white shadow-sm'
                        : 'bg-[#122130] border-[#1c2b3b] text-[#94a3b8] hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-white">{tier.level}</span>
                      <span className="text-[#00F0FF]">{tier.hashrate} VH/s</span>
                    </div>
                    <div className="text-[10px] text-[#D4AF37] mt-0.5">{tier.directs}</div>
                    <div className="text-[10px] text-emerald-400">1 SPK in {tier.targetDays} days</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div>
                <label className="block text-[#94a3b8] mb-1">Custom Hashrate (VH/s units)</label>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  value={customHashrateVal}
                  onChange={(e) => setCustomHashrateVal(e.target.value)}
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2.5 text-[#00F0FF] font-bold text-sm focus:outline-none focus:border-[#00F0FF]"
                />
                <div className="text-[10px] text-[#94a3b8] mt-1">
                  1 SPIKE mine hone ka time:{' '}
                  <span className="text-white font-bold">
                    {Number(customHashrateVal) > 0 ? +(6000 / Number(customHashrateVal)).toFixed(1) : 60} days
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[#94a3b8] mb-1">Reason / Admin Note</label>
                <input
                  type="text"
                  value={hashrateChangeReason}
                  onChange={(e) => setHashrateChangeReason(e.target.value)}
                  placeholder="e.g. VIP hashrate upgrade"
                  className="w-full bg-[#122130] border border-[#1c2b3b] rounded-xl px-4 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
              <button
                type="button"
                disabled={isUpdatingHashrate}
                onClick={() => handleSaveUserHashrate(hashrateModalUser.address, null, 'Reset to auto-calculated tier')}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#1c2b3b] hover:bg-[#273647] text-[#94a3b8] hover:text-white font-mono text-xs cursor-pointer"
                title="Remove custom lock and calculate from referrals"
              >
                Reset to Auto Tier
              </button>
              <div className="flex-1 w-full flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setHashrateModalUser(null)}
                  className="flex-1 py-2.5 rounded-xl bg-[#122130] hover:bg-[#1c2b3b] text-[#94a3b8] font-mono text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isUpdatingHashrate || !Number(customHashrateVal)}
                  onClick={() =>
                    handleSaveUserHashrate(
                      hashrateModalUser.address,
                      Number(customHashrateVal) || 100,
                      hashrateChangeReason
                    )
                  }
                  className="flex-1 py-2.5 rounded-xl bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-headline text-xs font-bold shadow-[0_0_15px_rgba(0,240,255,0.3)] disabled:opacity-40 cursor-pointer"
                >
                  {isUpdatingHashrate ? 'Saving...' : 'Apply Hashrate'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
