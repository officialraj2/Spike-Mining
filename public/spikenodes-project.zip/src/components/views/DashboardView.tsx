import React, { useState, useEffect, useMemo } from 'react';
import { MiningNode, RewardTransaction, HashrateLevelInfo, ReferralStatsData } from '../../types';
import { SPIKE_LOGO_URL } from '../../data/mockData';
import { TradingViewChart } from '../TradingViewChart';
import { GoldenHawkMiningSection } from '../GoldenHawkMiningSection';

const BSCSCAN_TOKEN_URL = 'https://bscscan.com/token/0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
export const PANCAKESWAP_PAIR_CONTRACT = '0xdB75fAB72e56492CFE870344D115C57047992F3c';
export const BSCSCAN_PAIR_URL = 'https://bscscan.com/address/0xdB75fAB72e56492CFE870344D115C57047992F3c';
export const PANCAKESWAP_ROUTER_ADDRESS = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
export const BSCSCAN_ROUTER_URL = 'https://bscscan.com/address/0x10ED43C718714eb63d5aA57B78B54704E256024E';
const PANCAKESWAP_ROUTER_URL = 'https://pancakeswap.finance/swap?outputCurrency=0x3471e07c4d2f7e11c155760a7b386e616b5c3715';

interface CandleTick {
  time: string;
  price: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isBuySurge?: boolean;
}

interface LiveTxn {
  id: string;
  type: 'buy' | 'sell';
  amountSpk: number;
  amountUsd: number;
  price: number;
  timeAgo: string;
  wallet: string;
  isWhale?: boolean;
}

interface DashboardViewProps {
  nodes: MiningNode[];
  rewards: RewardTransaction[];
  walletBalance: number;
  dailyEarnings: number;
  onRestartNode: (nodeId: string) => void;
  onStopNode: (nodeId: string) => void;
  onStartNode: (nodeId: string) => void;
  onOpenDeployModal: () => void;
  onOpenClaimModal: () => void;
  onOpenAuditModal: () => void;
  onOpenSwapModal?: (initialMode?: 'sellSpike' | 'buySpike') => void;
  onOpenDepositModal?: () => void;
  onSwapSuccess?: (fromToken: string, toToken: string, fromAmount: number, toAmount: number) => void;
  walletBNB?: number;
  onCopyText: (text: string) => void;
  walletAddress?: string;
  hashrateInfo?: HashrateLevelInfo | null;
  referralStats?: ReferralStatsData | null;
  onClaimReferralBonus?: (amount: number) => void;
  onNavigateToReferrals?: () => void;
  isRootWallet?: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  nodes,
  rewards,
  walletBalance,
  dailyEarnings,
  onRestartNode,
  onStopNode,
  onStartNode,
  onOpenDeployModal,
  onOpenClaimModal,
  onOpenAuditModal,
  onOpenSwapModal,
  onOpenDepositModal,
  onSwapSuccess,
  walletBNB = 0.005,
  onCopyText,
  walletAddress = '',
  hashrateInfo,
  referralStats,
  onClaimReferralBonus,
  onNavigateToReferrals,
  isRootWallet = false,
}) => {
  // Testnet Engine & Hashrate Auto-Buy States
  const [testnetWallet, setTestnetWallet] = useState<{
    address: string;
    testnetUsdt: number;
    testnetSpk: number;
    autoBuyEnabled: boolean;
    slippageTolerance: number;
    totalHarvestAutoBoughtSpk: number;
    totalUsdtSpentOnAutoBuy: number;
  }>(() => {
    let savedSpk = 0.0;
    try {
      if (walletAddress) {
        const cached = localStorage.getItem(`spike_spk_${walletAddress.toLowerCase()}`);
        if (cached !== null && !isNaN(Number(cached))) savedSpk = Number(cached);
      }
    } catch {}
    return {
      address: walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
      testnetUsdt: 1000.0,
      testnetSpk: savedSpk,
      autoBuyEnabled: true,
      slippageTolerance: 0.5,
      totalHarvestAutoBoughtSpk: savedSpk,
      totalUsdtSpentOnAutoBuy: 0.0,
    };
  });

  const [spikeTokenInfo, setSpikeTokenInfo] = useState<{
    name: string;
    symbol: string;
    totalSupply: number;
    circulatingSupply: number;
    currentPrice: number;
    poolSpkReserve: number;
    poolUsdtReserve: number;
    contractAddress: string;
    buyPressure: number;
    volume24h: number;
    change24h: number;
    high24h?: number;
    low24h?: number;
  }>({
    name: 'SPIKE',
    symbol: 'SPK',
    totalSupply: 50_000_000,
    circulatingSupply: 12_450_000,
    currentPrice: 1.12,
    poolSpkReserve: 2_500_000,
    poolUsdtReserve: 2_800_000,
    contractAddress: '0x96F86413D8E5d15ecE42E136CC8112c01b9A7306',
    buyPressure: 88.5,
    volume24h: 1_420_000,
    change24h: 8.42,
    high24h: 1.20,
    low24h: 1.00,
  });

  const [testnetTransactions, setTestnetTransactions] = useState<any[]>([]);
  const [isHarvestAutoBuying, setIsHarvestAutoBuying] = useState<boolean>(false);
  const [lastAutoBuyReceipt, setLastAutoBuyReceipt] = useState<any | null>(null);
  const [pendingMinedSpk, setPendingMinedSpk] = useState<number>(18.42);
  const [isTestnetFaucetLoading, setIsTestnetFaucetLoading] = useState<boolean>(false);
  const [testnetActiveTab, setTestnetActiveTab] = useState<'autobuy' | 'swap' | 'history'>('autobuy');
  const [testnetSwapFrom, setTestnetSwapFrom] = useState<'USDT' | 'SPK'>('USDT');
  const [testnetSwapAmount, setTestnetSwapAmount] = useState<string>('50');
  const [isTestnetSwapping, setIsTestnetSwapping] = useState<boolean>(false);
  const [testnetSwapSuccessTx, setTestnetSwapSuccessTx] = useState<any | null>(null);

  // Global Protocol Treasury State (Common for all users)
  const [treasuryData, setTreasuryData] = useState<{
    treasuryBalanceUsdt: number;
    treasuryWalletAddress: string;
    depositRequiredUsdt: number;
    miningCostUsdt: number;
    totalProjectCostUsdt: number;
  }>({
    treasuryBalanceUsdt: 0.0,
    treasuryWalletAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
    depositRequiredUsdt: 5.0,
    miningCostUsdt: 10.0,
    totalProjectCostUsdt: 15.0,
  });

  const fetchTreasuryInfo = async () => {
    try {
      const res = await fetch('/api/treasury');
      if (res.ok) {
        const data = await res.json();
        if (data && data.success) {
          setTreasuryData({
            treasuryBalanceUsdt: typeof data.treasuryBalanceUsdt === 'number' ? data.treasuryBalanceUsdt : 0.0,
            treasuryWalletAddress: data.treasuryWalletAddress || '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
            depositRequiredUsdt: data.depositRequiredUsdt || 5.0,
            miningCostUsdt: data.miningCostUsdt || 10.0,
            totalProjectCostUsdt: data.totalProjectCostUsdt || 15.0,
          });
        }
      }
    } catch {}
  };

  useEffect(() => {
    fetchTreasuryInfo();
    const interval = setInterval(fetchTreasuryInfo, 3500);
    const handleUpdated = () => fetchTreasuryInfo();
    window.addEventListener('spike_balance_updated', handleUpdated);
    window.addEventListener('treasuryUpdated', handleUpdated);
    window.addEventListener('focus', handleUpdated);
    return () => {
      clearInterval(interval);
      window.removeEventListener('spike_balance_updated', handleUpdated);
      window.removeEventListener('treasuryUpdated', handleUpdated);
      window.removeEventListener('focus', handleUpdated);
    };
  }, []);

  // Load live testnet data from backend
  useEffect(() => {
    const fetchTestnetData = async () => {
      try {
        const addr = walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
        const [tokenRes, walletRes] = await Promise.all([
          fetch('/api/testnet/spike/info'),
          fetch(`/api/testnet/wallet/${addr}`),
        ]);
        if (tokenRes.ok) {
          const tData = await tokenRes.json();
          if (tData.token) setSpikeTokenInfo(tData.token);
        }
        if (walletRes.ok) {
          const wData = await walletRes.json();
          if (wData.wallet) setTestnetWallet(wData.wallet);
          if (wData.transactions) setTestnetTransactions(wData.transactions);
        }
      } catch (err) {
        console.error('Failed to load testnet state:', err);
      }
    };
    fetchTestnetData();
  }, [walletAddress]);

  // DEX Swap System State (Inside Dashboard)
  const [dashFromToken, setDashFromToken] = useState<string>('SPIKE');
  const [dashToToken, setDashToToken] = useState<string>('USDT');
  const [dashFromAmount, setDashFromAmount] = useState<string>('100');
  const [dashIsSwapping, setDashIsSwapping] = useState<boolean>(false);
  const [dashSwapSuccessTx, setDashSwapSuccessTx] = useState<string | null>(null);

  const dashTokens: Record<string, { symbol: string; name: string; balance: number; rate: number; isSpike?: boolean; icon?: string }> = {
    SPIKE: { symbol: 'SPIKE', name: 'SPIKE Protocol', balance: walletBalance, rate: 1.0, isSpike: true },
    USDT: { symbol: 'USDT', name: 'Tether USD (BEP-20)', balance: walletBalance, rate: 1.0, icon: 'attach_money' },
    BNB: { symbol: 'BNB', name: 'BNB Smart Chain', balance: walletBNB ?? 0.005, rate: 620.0, icon: 'token' },
  };

  const currentFrom = dashTokens[dashFromToken] || dashTokens.SPIKE;
  const currentTo = dashTokens[dashToToken] || dashTokens.USDT;
  const numFromAmount = parseFloat(dashFromAmount) || 0;
  const dashRate = currentFrom.rate / currentTo.rate;
  const calculatedToAmount = numFromAmount * dashRate;

  const handleFlipDashTokens = () => {
    setDashFromToken(dashToToken);
    setDashToToken(dashFromToken);
  };

  const handleExecuteDashSwap = () => {
    if (numFromAmount <= 0 || numFromAmount > currentFrom.balance) return;
    setDashIsSwapping(true);
    setDashSwapSuccessTx(null);
    setTimeout(() => {
      setDashIsSwapping(false);
      const fakeTx = `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      setDashSwapSuccessTx(fakeTx);
      onSwapSuccess?.(currentFrom.symbol, currentTo.symbol, numFromAmount, calculatedToAmount);
    }, 1100);
  };

  const [chartMode, setChartMode] = useState<'animated-stream' | 'hashrate'>('animated-stream');
  const [timeframe, setTimeframe] = useState<'24H' | '7D' | '30D'>('24H');
  const [streamInterval, setStreamInterval] = useState<'1M' | '5M' | '15M' | '1H' | '24H'>('1M');
  const [currentPrice, setCurrentPrice] = useState<number>(1.1245);
  const [priceChange24h, setPriceChange24h] = useState<number>(8.42);
  const [lastTickDirection, setLastTickDirection] = useState<'up' | 'down'>('up');
  const [hoveredCandle, setHoveredCandle] = useState<{
    x: number;
    y: number;
    tick: CandleTick;
  } | null>(null);

  // Initial live ticks series around SPIKE spot price ($1.00 - $1.20 USDT)
  const [ticks, setTicks] = useState<CandleTick[]>([
    { time: '10:14', open: 1.025, high: 1.055, low: 1.018, close: 1.048, price: 1.048, volume: 14200, isBuySurge: true },
    { time: '10:15', open: 1.048, high: 1.078, low: 1.035, close: 1.065, price: 1.065, volume: 18500, isBuySurge: true },
    { time: '10:16', open: 1.065, high: 1.095, low: 1.050, close: 1.082, price: 1.082, volume: 9200, isBuySurge: true },
    { time: '10:17', open: 1.082, high: 1.115, low: 1.070, close: 1.104, price: 1.104, volume: 24000, isBuySurge: true },
    { time: '10:18', open: 1.104, high: 1.140, low: 1.095, close: 1.125, price: 1.125, volume: 16800, isBuySurge: true },
    { time: '10:19', open: 1.125, high: 1.155, low: 1.110, close: 1.138, price: 1.138, volume: 21000, isBuySurge: true },
    { time: '10:20', open: 1.138, high: 1.168, low: 1.125, close: 1.152, price: 1.152, volume: 11500, isBuySurge: true },
    { time: '10:21', open: 1.152, high: 1.185, low: 1.135, close: 1.168, price: 1.168, volume: 32000, isBuySurge: true },
    { time: '10:22', open: 1.168, high: 1.192, low: 1.145, close: 1.158, price: 1.158, volume: 28500, isBuySurge: true },
  ]);

  // Live Buy/Sell Transactions Stream for SPIKE ($1.00 - $1.20)
  const [liveTxns, setLiveTxns] = useState<LiveTxn[]>([
    { id: 'tx-1', type: 'buy', amountSpk: 1250, amountUsd: 1405.00, price: 1.124, timeAgo: 'Just now', wallet: '0x8a92...3f1c', isWhale: false },
    { id: 'tx-2', type: 'buy', amountSpk: 6500, amountUsd: 7371.00, price: 1.134, timeAgo: '2s ago', wallet: '0x4f11...9cb2', isWhale: true },
    { id: 'tx-3', type: 'buy', amountSpk: 850, amountUsd: 952.00, price: 1.120, timeAgo: '5s ago', wallet: '0xd340...e17a', isWhale: false },
    { id: 'tx-4', type: 'sell', amountSpk: 220, amountUsd: 244.20, price: 1.110, timeAgo: '9s ago', wallet: '0x12bb...a840', isWhale: false },
    { id: 'tx-5', type: 'buy', amountSpk: 2400, amountUsd: 2712.00, price: 1.130, timeAgo: '12s ago', wallet: '0x99cc...451a', isWhale: false },
    { id: 'tx-6', type: 'buy', amountSpk: 15000, amountUsd: 17175.00, price: 1.145, timeAgo: '16s ago', wallet: '0x6e90...bb44', isWhale: true },
  ]);
  const [buyPressure, setBuyPressure] = useState<number>(84.5);
  const [totalBuysCount, setTotalBuysCount] = useState<number>(1420);
  const [totalSellsCount, setTotalSellsCount] = useState<number>(270);

  // Real-time animation ticker: gently moves price between $1.00 and $1.20
  useEffect(() => {
    const interval = setInterval(() => {
      setTicks((prev) => {
        const last = prev[prev.length - 1];
        // Mean reversion toward 1.10 with realistic random volatility, tightly bounded between $1.00 and $1.20
        const center = 1.10;
        const pull = (center - last.close) * 0.04;
        const noise = (Math.random() - 0.48) * 0.012;
        let newPrice = +(last.close + pull + noise).toFixed(4);
        if (newPrice < 1.005) newPrice = +(1.005 + Math.random() * 0.02).toFixed(4);
        if (newPrice > 1.195) newPrice = +(1.195 - Math.random() * 0.02).toFixed(4);

        const isUp = newPrice >= last.close;
        const newHigh = +(Math.min(1.20, Math.max(last.close, newPrice) + Math.random() * 0.008)).toFixed(4);
        const newLow = +(Math.max(1.00, Math.min(last.close, newPrice) - Math.random() * 0.008)).toFixed(4);
        
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;

        setCurrentPrice(newPrice);
        setLastTickDirection(isUp ? 'up' : 'down');
        setSpikeTokenInfo((prev) => ({
          ...prev,
          currentPrice: newPrice,
          high24h: Math.max(prev.high24h ?? 1.20, newHigh),
          low24h: Math.min(prev.low24h ?? 1.00, newLow),
        }));

        const newTick: CandleTick = {
          time: timeStr,
          open: last.close,
          close: newPrice,
          high: newHigh,
          low: newLow,
          price: newPrice,
          volume: Math.floor(1200 + Math.random() * 4500),
          isBuySurge: isUp,
        };

        // Create new live trade (85% buy, 15% sell)
        const isBuyTrade = Math.random() < 0.85;
        const isWhaleTrade = isBuyTrade && Math.random() < 0.22;
        const tradeAmount = isWhaleTrade
          ? Math.floor(4000 + Math.random() * 12000)
          : isBuyTrade
          ? Math.floor(350 + Math.random() * 2200)
          : Math.floor(80 + Math.random() * 450);
        const tradeUsd = Number((tradeAmount * newPrice).toFixed(2));
        const randomHex = Math.random().toString(16).substring(2, 6);
        const randomEnd = Math.random().toString(16).substring(2, 6);

        const newTx: LiveTxn = {
          id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          type: isBuyTrade ? 'buy' : 'sell',
          amountSpk: tradeAmount,
          amountUsd: tradeUsd,
          price: newPrice,
          timeAgo: 'Just now',
          wallet: `0x${randomHex}...${randomEnd}`,
          isWhale: isWhaleTrade,
        };

        setLiveTxns((prevTx) => [newTx, ...prevTx.slice(0, 5)]);
        if (isBuyTrade) {
          setTotalBuysCount((c) => c + 1);
          setBuyPressure((p) => Math.min(94, Math.max(79, Number((p + 0.1).toFixed(1)))));
        } else {
          setTotalSellsCount((c) => c + 1);
          setBuyPressure((p) => Math.max(76, Number((p - 0.2).toFixed(1))));
        }

        const updated = [...prev.slice(prev.length >= 12 ? 1 : 0), newTick];
        return updated;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Listen to completed trade events (from DEX swaps or Harvest claims) to drive graph
  useEffect(() => {
    const handleTradeExecuted = (e: any) => {
      const detail = e.detail;
      if (!detail) return;
      const isBuy = detail.toToken === 'SPIKE' || detail.toToken === 'SPK';
      const spkAmount = isBuy ? detail.toAmount : detail.fromAmount;
      const usdtAmount = isBuy ? detail.fromAmount : detail.toAmount;
      const tradePrice = spkAmount > 0 ? +(usdtAmount / spkAmount).toFixed(5) : currentPrice;
      const userWallet = detail.walletAddress || walletAddress || '0xUser...Wallet';
      const shortW = `${userWallet.substring(0, 6)}...${userWallet.substring(userWallet.length - 4)}`;

      const tradeTx: LiveTxn = {
        id: `user-tx-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: isBuy ? 'buy' : 'sell',
        amountSpk: Math.round(spkAmount),
        amountUsd: +usdtAmount.toFixed(2),
        price: tradePrice,
        timeAgo: 'Just now',
        wallet: shortW,
        isWhale: spkAmount >= 5000,
      };

      setLiveTxns((prev) => [tradeTx, ...prev.slice(0, 5)]);
      if (isBuy) {
        setTotalBuysCount((c) => c + 1);
        setBuyPressure((p) => Math.min(96, +(p + 0.3).toFixed(1)));
        setCurrentPrice((prev) => +(prev + 0.00015).toFixed(5));
      } else {
        setTotalSellsCount((c) => c + 1);
        setBuyPressure((p) => Math.max(70, +(p - 0.4).toFixed(1)));
        setCurrentPrice((prev) => Math.max(0.01, +(prev - 0.00015).toFixed(5)));
      }
    };

    window.addEventListener('spike_trade_executed', handleTradeExecuted);
    return () => window.removeEventListener('spike_trade_executed', handleTradeExecuted);
  }, [currentPrice, walletAddress]);

  // Synchronize testnet wallet balances on balance updates (e.g. 24h mining harvest claim)
  useEffect(() => {
    const handleBalanceUpdated = (e: any) => {
      const detail = e.detail;
      if (!detail) return;
      if (detail.balanceSpk !== undefined) {
        setTestnetWallet((prev) => ({
          ...prev,
          testnetSpk: Number(detail.balanceSpk),
        }));
      }
    };
    window.addEventListener('spike_balance_updated', handleBalanceUpdated);
    return () => window.removeEventListener('spike_balance_updated', handleBalanceUpdated);
  }, []);

  const [hoveredDataPoint, setHoveredDataPoint] = useState<{
    x: number;
    y: number;
    hashrate: string;
    time: string;
  } | null>(null);

  // Calculate live total hashrate from active mining nodes
  const activeMiningNodes = nodes.filter((n) => n.status === 'mining');
  const totalHashrate = activeMiningNodes.reduce((acc, curr) => acc + curr.hashrate, 0);
  const activeNodeCount = activeMiningNodes.length;
  const operationalEfficiency = nodes.length > 0 ? Math.round((activeNodeCount / nodes.length) * 100) : 0;

  // Timeframe chart curve data configurations
  const chartConfigs = {
    '24H': {
      points: [
        { cx: 50, cy: 155, rate: '1.18 TH/s', time: '00:00 UTC' },
        { cx: 200, cy: 110, rate: '1.21 TH/s', time: '06:00 UTC' },
        { cx: 400, cy: 125, rate: '1.20 TH/s', time: '12:00 UTC' },
        { cx: 600, cy: 75, rate: '1.23 TH/s', time: '18:00 UTC' },
        { cx: 780, cy: 45, rate: `${totalHashrate.toFixed(2)} TH/s`, time: 'Now' },
      ],
      pathD: 'M 0 160 Q 100 135, 200 110 T 400 125 T 600 75 T 780 45 L 800 40',
      fillD: 'M 0 160 Q 100 135, 200 110 T 400 125 T 600 75 T 780 45 L 800 40 L 800 200 L 0 200 Z',
      timeLabels: ['00:00 UTC', '06:00 UTC', '12:00 UTC', '18:00 UTC', `Now (${totalHashrate.toFixed(2)} TH/s)`],
    },
    '7D': {
      points: [
        { cx: 50, cy: 140, rate: '1.12 TH/s', time: 'Day 1' },
        { cx: 200, cy: 95, rate: '1.25 TH/s', time: 'Day 3' },
        { cx: 400, cy: 130, rate: '1.16 TH/s', time: 'Day 5' },
        { cx: 600, cy: 65, rate: '1.28 TH/s', time: 'Day 6' },
        { cx: 780, cy: 45, rate: `${totalHashrate.toFixed(2)} TH/s`, time: 'Today' },
      ],
      pathD: 'M 0 145 Q 100 110, 200 95 T 400 130 T 600 65 T 780 45 L 800 40',
      fillD: 'M 0 145 Q 100 110, 200 95 T 400 130 T 600 65 T 780 45 L 800 40 L 800 200 L 0 200 Z',
      timeLabels: ['7 Days Ago', '5 Days Ago', '3 Days Ago', 'Yesterday', `Now (${totalHashrate.toFixed(2)} TH/s)`],
    },
    '30D': {
      points: [
        { cx: 50, cy: 165, rate: '0.98 TH/s', time: 'Week 1' },
        { cx: 200, cy: 120, rate: '1.10 TH/s', time: 'Week 2' },
        { cx: 400, cy: 90, rate: '1.22 TH/s', time: 'Week 3' },
        { cx: 600, cy: 60, rate: '1.26 TH/s', time: 'Week 4' },
        { cx: 780, cy: 45, rate: `${totalHashrate.toFixed(2)} TH/s`, time: 'Current' },
      ],
      pathD: 'M 0 170 Q 100 140, 200 120 T 400 90 T 600 60 T 780 45 L 800 40',
      fillD: 'M 0 170 Q 100 140, 200 120 T 400 90 T 600 60 T 780 45 L 800 40 L 800 200 L 0 200 Z',
      timeLabels: ['30 Days Ago', '20 Days Ago', '10 Days Ago', '5 Days Ago', `Now (${totalHashrate.toFixed(2)} TH/s)`],
    },
  };

  const currentChart = chartConfigs[timeframe];

  // SVG Scaled coordinates for the Live Animated Chart
  const svgMetrics = useMemo(() => {
    if (!ticks.length) return { pathD: '', fillD: '', coords: [], minP: 0, maxP: 1 };
    const allLows = ticks.map((t) => t.low);
    const allHighs = ticks.map((t) => t.high);
    const minP = Math.min(...allLows) * 0.9992;
    const maxP = Math.max(...allHighs) * 1.0008;
    const range = maxP - minP || 0.00001;

    const width = 800;
    const height = 200;
    const paddingX = 40;
    const paddingY = 25;
    const plotWidth = width - paddingX * 2;
    const plotHeight = height - paddingY * 2;

    const coords = ticks.map((t, idx) => {
      const x = paddingX + (idx / (ticks.length - 1 || 1)) * plotWidth;
      const yClose = paddingY + plotHeight - ((t.close - minP) / range) * plotHeight;
      const yOpen = paddingY + plotHeight - ((t.open - minP) / range) * plotHeight;
      const yHigh = paddingY + plotHeight - ((t.high - minP) / range) * plotHeight;
      const yLow = paddingY + plotHeight - ((t.low - minP) / range) * plotHeight;
      return { x, yClose, yOpen, yHigh, yLow, tick: t };
    });

    let pathD = `M ${coords[0].x} ${coords[0].yClose}`;
    for (let i = 1; i < coords.length; i++) {
      const prev = coords[i - 1];
      const curr = coords[i];
      const midX = (prev.x + curr.x) / 2;
      pathD += ` C ${midX} ${prev.yClose}, ${midX} ${curr.yClose}, ${curr.x} ${curr.yClose}`;
    }

    const last = coords[coords.length - 1];
    const first = coords[0];
    const fillD = `${pathD} L ${last.x} ${height} L ${first.x} ${height} Z`;

    return { pathD, fillD, coords, minP, maxP };
  }, [ticks]);

  // Live Hashrate accumulator for pending mined SPK
  useEffect(() => {
    const interval = setInterval(() => {
      const activeHash = totalHashrate > 0 ? totalHashrate : 1.25;
      const ratePerSec = activeHash * 0.025;
      setPendingMinedSpk((prev) => Number((prev + ratePerSec).toFixed(3)));
    }, 2000);
    return () => clearInterval(interval);
  }, [totalHashrate]);

  // Calculated required USDT for auto-buying current pending mined SPK
  const requiredUsdtForPending = useMemo(() => {
    return Number((pendingMinedSpk * spikeTokenInfo.currentPrice).toFixed(4));
  }, [pendingMinedSpk, spikeTokenInfo.currentPrice]);

  // Execute Harvest & Auto-Buy via backend testnet engine
  const handleExecuteHarvestAutoBuy = async () => {
    if (pendingMinedSpk <= 0) return;
    setIsHarvestAutoBuying(true);
    try {
      const addr = walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
      const res = await fetch('/api/testnet/harvest-autobuy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address: addr,
          minedSpkAmount: pendingMinedSpk,
          hashrate: totalHashrate || 1.25,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setTestnetWallet(data.wallet);
        setSpikeTokenInfo(data.token);
        setLastAutoBuyReceipt(data.tx);
        setTestnetTransactions((prev) => [data.tx, ...prev]);
        setPendingMinedSpk(0.25); // reset with tiny seed

        // Push bullish trade to order stream
        const newTrade: LiveTxn = {
          id: `tx-spk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          type: 'buy',
          amountSpk: Math.round(data.tx.spkAmount),
          amountUsd: Number(data.tx.usdtAmount.toFixed(2)),
          price: data.tx.priceUsdt,
          timeAgo: 'Just now',
          wallet: addr ? `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}` : '0xAuto...Miner',
          isWhale: data.tx.spkAmount > 50,
        };
        setLiveTxns((prev) => [newTrade, ...prev.slice(0, 5)]);
      } else {
        alert(data.error || 'Failed to execute auto-buy transaction');
      }
    } catch (err: any) {
      console.error('Harvest auto-buy error:', err);
    } finally {
      setIsHarvestAutoBuying(false);
    }
  };

  // 1-Click Faucet topup
  const handleClaimTestnetFaucet = async () => {
    setIsTestnetFaucetLoading(true);
    try {
      const addr = walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
      const res = await fetch('/api/testnet/wallet/faucet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address: addr,
          usdtAmount: 500,
          spkAmount: 100,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setTestnetWallet(data.wallet);
        setTestnetTransactions((prev) => [data.tx, ...prev]);
      }
    } catch (err) {
      console.error('Faucet error:', err);
    } finally {
      setIsTestnetFaucetLoading(false);
    }
  };

  // Toggle Auto-buy automation
  const handleToggleAutoBuySetting = async (enabled: boolean) => {
    try {
      const addr = walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
      const res = await fetch('/api/testnet/wallet/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address: addr,
          autoBuyEnabled: enabled,
          slippageTolerance: testnetWallet.slippageTolerance,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setTestnetWallet(data.wallet);
      }
    } catch (err) {
      console.error('Settings error:', err);
    }
  };

  // Manual Testnet Swap
  const handleExecuteManualTestnetSwap = async () => {
    const num = parseFloat(testnetSwapAmount) || 0;
    if (num <= 0) return;
    setIsTestnetSwapping(true);
    setTestnetSwapSuccessTx(null);
    try {
      const addr = walletAddress || '0x71C8a914B97e889F12A0987cB32456Fa12349A2';
      const toToken = testnetSwapFrom === 'USDT' ? 'SPK' : 'USDT';
      const res = await fetch('/api/testnet/swap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address: addr,
          fromToken: testnetSwapFrom,
          toToken,
          amountIn: num,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setTestnetWallet(data.wallet);
        setSpikeTokenInfo(data.token);
        setTestnetSwapSuccessTx(data.tx);
        setTestnetTransactions((prev) => [data.tx, ...prev]);
      } else {
        alert(data.error || 'Swap failed');
      }
    } catch (err) {
      console.error('Swap error:', err);
    } finally {
      setIsTestnetSwapping(false);
    }
  };

  return (
    <div className="flex flex-col w-full space-y-6 md:space-y-8 pb-12">
      {/* ============================================================
          GOLDEN HAWK (BAAZ) APEX MINING PROTOCOL ENGINE
         ============================================================ */}
      <GoldenHawkMiningSection
        totalHashrate={totalHashrate}
        walletBalance={walletBalance}
        walletAddress={walletAddress}
        hashrateInfo={hashrateInfo}
        isNodeActive={activeNodeCount > 0}
        activeNodesCount={activeNodeCount}
        onClaimReward={onClaimReferralBonus}
        onDeployMoreNodes={onOpenDeployModal}
        onOpenDepositModal={onOpenDepositModal}
        isRootWallet={isRootWallet}
        onAutoBuySuccess={(tx, wallet, token) => {
          if (wallet) setTestnetWallet(wallet);
          if (token) setSpikeTokenInfo(token);
          if (tx) {
            setLastAutoBuyReceipt(tx);
            setTestnetTransactions((prev) => [tx, ...prev]);
            const newTrade: LiveTxn = {
              id: `tx-spk-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
              type: 'buy',
              amountSpk: Math.round(tx.spkAmount),
              amountUsd: Number(tx.usdtAmount.toFixed(2)),
              price: tx.priceUsdt,
              timeAgo: 'Just now',
              wallet: walletAddress ? `${walletAddress.substring(0, 6)}...${walletAddress.substring(walletAddress.length - 4)}` : '0xAuto...Miner',
              isWhale: tx.spkAmount > 50,
            };
            setLiveTxns((prev) => [newTrade, ...prev.slice(0, 5)]);
          }
        }}
      />

      {/* 3 Primary Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Card 1: Protocol Hashrate Velocity (Image Spec: Direct Referral Tier) */}
        <div className="bg-[#122130] rounded-xl p-5 md:p-6 flex flex-col justify-between relative overflow-hidden shadow-md group hover:bg-[#1c2b3b] transition-all border border-[#1c2b3b]/60">
          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-[#00F0FF]/5 rounded-full blur-xl group-hover:bg-[#00F0FF]/15 transition-all"></div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-[#94a3b8] font-mono text-[11px] font-semibold uppercase tracking-[0.14em] block">
                Hashrate Tier
              </span>
              <div className="flex items-center gap-1.5 mt-1">
                <span className={`inline-flex items-center gap-1 text-[10px] font-bold font-mono px-2 py-0.5 rounded-full ${
                  hashrateInfo?.isCustomOverride
                    ? 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40'
                    : 'bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30'
                }`}>
                  {hashrateInfo?.level || 'Fresh user'}
                  {hashrateInfo?.isCustomOverride && ' (Admin Override)'}
                </span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/10 flex items-center justify-center text-[#00F0FF]">
              <span className="material-symbols-outlined text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                speed
              </span>
            </div>
          </div>
          <div>
            <div className="text-3xl lg:text-[38px] leading-tight font-extrabold font-headline text-white mb-1 tabular-nums tracking-tight flex items-baseline gap-2">
              <span>{hashrateInfo?.hashrate ?? 100}</span>
              <span className="text-lg lg:text-xl text-[#00F0FF] font-semibold tracking-normal">VH/s</span>
              <span className="text-xs text-[#94a3b8] font-mono font-normal">
                ({totalHashrate > 0 ? totalHashrate.toFixed(2) : '1.25'} TH/s cluster)
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-[#7df4ff] font-mono font-medium pt-1.5 border-t border-[#1c2b3b]/60">
              <span className="text-emerald-400">1 SPK in {hashrateInfo?.targetDays || 60} Days</span>
              <span className="text-[#00F0FF] font-bold">
                {Math.max(referralStats?.directPartners ?? 0, hashrateInfo?.directCount ?? 0)} Directs
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-[#94a3b8] font-mono pt-1">
              <span>Total Team: <strong className="text-white font-bold">{Math.max(referralStats?.totalPartners ?? 0, hashrateInfo?.totalTeamCount ?? 0)}</strong></span>
              {hashrateInfo?.nextTier && (
                <span className="text-[#D4AF37] truncate">
                  Next: {hashrateInfo.nextTier.level} ({hashrateInfo.nextTier.neededDirects} needed)
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Card 2: Active Nodes */}
        <div className="bg-[#122130] rounded-xl p-5 md:p-6 flex flex-col justify-between relative overflow-hidden shadow-md group hover:bg-[#1c2b3b] transition-all border border-[#1c2b3b]/60">
          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-[#D4AF37]/5 rounded-full blur-xl group-hover:bg-[#D4AF37]/15 transition-all"></div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-[#94a3b8] font-mono text-[11px] font-semibold uppercase tracking-[0.14em]">
              Active Nodes
            </span>
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
              <span className="material-symbols-outlined text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                dns
              </span>
            </div>
          </div>
          <div>
            <div className="text-3xl lg:text-[40px] leading-tight font-extrabold font-headline text-white mb-1 tabular-nums tracking-tight">
              {activeNodeCount}{' '}
              <span className="text-lg lg:text-xl text-[#94a3b8] font-semibold tracking-normal">/ {nodes.length} online</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-[#D4AF37] font-medium">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse"></span>
              <span>{operationalEfficiency}% Operational Efficiency</span>
            </div>
          </div>
        </div>

        {/* Card 3: SPIKE Balance with Instant PancakeSwap Sell Route */}
        <div className="bg-[#122130] rounded-xl p-5 md:p-6 flex flex-col justify-between relative overflow-hidden shadow-md group hover:bg-[#1c2b3b] transition-all border border-[#1c2b3b]/60">
          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-[#D4AF37]/5 rounded-full blur-xl group-hover:bg-[#D4AF37]/15 transition-all pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-[#94a3b8] font-mono text-[11px] font-semibold uppercase tracking-[0.14em]">
                SPIKE Balance
              </span>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#f59e0b]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shadow-[0_0_12px_rgba(212,175,55,0.25)] shrink-0">
                <img
                  src={SPIKE_LOGO_URL}
                  alt="SPIKE Token Medallion"
                  className="w-7 h-7 object-contain drop-shadow-[0_0_8px_rgba(212,175,55,0.5)] group-hover:scale-110 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div>
              <div className="text-3xl lg:text-[40px] leading-tight font-extrabold font-headline text-white mb-0.5 tabular-nums tracking-tight flex items-baseline gap-2">
                <span>{(testnetWallet?.testnetSpk ?? 0.0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                <span className="text-lg lg:text-xl text-[#D4AF37] font-semibold tracking-normal font-headline">SPK</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono mb-2">
                <span className="text-emerald-400 font-bold">
                  ≈ ${(((testnetWallet?.testnetSpk ?? 0.0)) * (spikeTokenInfo?.currentPrice || 1.12)).toFixed(2)} USDT
                </span>
                <span className="text-[#475569]">•</span>
                <span className="text-[#94a3b8] text-[11px]">
                  1 SPK = ${(spikeTokenInfo?.currentPrice || 1.12).toFixed(4)}
                </span>
              </div>
              <div className="flex items-center gap-2.5 mt-1.5">
                <button
                  onClick={() => {
                    if (onOpenSwapModal) {
                      onOpenSwapModal('sellSpike');
                    }
                  }}
                  className="text-xs text-[#D4AF37] hover:underline font-headline font-semibold flex items-center gap-1 transition-all group/btn cursor-pointer"
                  title="Open PancakeSwap Sell Route: Sell up to 10% of your SPIKE balance for USDT"
                >
                  <span>Swap Now (10% Sell Limit)</span>
                  <span className="material-symbols-outlined text-[14px] group-hover/btn:translate-x-0.5 transition-transform">
                    arrow_forward
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Direct Partner & Team Referral Network Live Sync Bar */}
      <div className="bg-gradient-to-r from-[#122130] via-[#0d1d2c] to-[#122130] border border-[#1c2b3b] rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/15 border border-[#00F0FF]/35 text-[#00F0FF] flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(0,240,255,0.25)]">
            <span className="material-symbols-outlined text-[22px]">groups</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-headline font-bold text-white uppercase tracking-wider">
                Direct Referral &amp; Team Network
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Network Sync
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#94a3b8] font-mono mt-1">
              <span>Direct Partners: <strong className="text-[#00F0FF] text-sm font-bold">{Math.max(referralStats?.directPartners ?? 0, hashrateInfo?.directCount ?? 0)}</strong></span>
              <span className="text-[#334155]">•</span>
              <span>Total Team: <strong className="text-white text-sm font-bold">{Math.max(referralStats?.totalPartners ?? 0, hashrateInfo?.totalTeamCount ?? 0)}</strong></span>
              <span className="text-[#334155]">•</span>
              <span>Active Rate: <strong className="text-[#D4AF37] font-semibold">{hashrateInfo?.level || 'Fresh user'} ({hashrateInfo?.hashrate ?? 100} VH/s)</strong></span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
          <button
            onClick={() => onNavigateToReferrals?.()}
            className="px-4 py-2 rounded-xl bg-[#00F0FF] hover:bg-[#7df4ff] text-[#0A0F1D] font-headline font-bold text-xs flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(0,240,255,0.3)] cursor-pointer hover:scale-105 active:scale-95"
          >
            <span>View Team &amp; Referral System</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Main Section: Live Performance Chart (2 cols) & Pool Metrics (1 col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Container (2 Cols) */}
        <div className="lg:col-span-2 bg-[#122130] rounded-xl p-5 md:p-6 flex flex-col justify-between shadow-md border border-[#1c2b3b]/60">
          {/* Header Bar with BSCScan Link & Mode Switchers */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-3 border-b border-[#1c2b3b]/80">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <div className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-[#D4AF37]/20 to-[#00F0FF]/20 border border-[#D4AF37]/40 text-white font-headline font-bold text-xs flex items-center gap-1.5 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
                  <span>SPIKE (SPK) / USDT</span>
                </div>

                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40">
                  BEP-20 • 50M Supply
                </span>
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>TESTNET LIVE</span>
                  <span className="tabular-nums font-semibold">${spikeTokenInfo.currentPrice.toFixed(4)} USDT</span>
                  <span className="text-[9px] text-emerald-300 font-normal">(+{spikeTokenInfo.change24h}%)</span>
                </div>
              </div>

              <h2 className="text-lg md:text-xl font-bold font-headline text-white tracking-tight flex items-center gap-2">
                <span>SPIKE (SPK) / USDT Live Trading Terminal</span>
              </h2>
            </div>

            {/* Actions: BSCScan Verified Contract & Tab Switchers */}
            <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
              <a
                href={BSCSCAN_TOKEN_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-[#00F0FF]/15 hover:bg-[#00F0FF]/25 border border-[#00F0FF]/40 text-[#00F0FF] text-xs font-headline font-bold flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(0,240,255,0.25)] hover:scale-102"
                title="View Verified SPIKE Contract on BSCScan"
              >
                <span>BSCScan</span>
                <span className="material-symbols-outlined text-[15px]">open_in_new</span>
              </a>

              {/* Chart Mode Toggle */}
              <div className="flex items-center gap-1 bg-[#1c2b3b] p-1 rounded-xl">
                <button
                  onClick={() => setChartMode('animated-stream')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-headline font-semibold tracking-wide transition-all flex items-center gap-1 ${
                    chartMode === 'animated-stream'
                      ? 'bg-[#00F0FF] text-[#0A0F1D] shadow-[0_0_12px_rgba(0,240,255,0.35)] font-bold'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                  title="Live Candlestick & Trading Terminal"
                >
                  <span className="material-symbols-outlined text-[14px]">show_chart</span>
                  <span>Live Stream</span>
                </button>

                <button
                  onClick={() => setChartMode('hashrate')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-headline font-semibold tracking-wide transition-all flex items-center gap-1 ${
                    chartMode === 'hashrate'
                      ? 'bg-[#00F0FF] text-[#0A0F1D] shadow-[0_0_12px_rgba(0,240,255,0.35)] font-bold'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                  title="BSC Hashrate Telemetry Wave"
                >
                  <span className="material-symbols-outlined text-[14px]">speed</span>
                  <span>Hashrate</span>
                </button>
              </div>
            </div>
          </div>

          {/* ============================================================
              VIEW 1: LIVE ANIMATED CHART WITH DYNAMIC TICKS & BEACON
             ============================================================ */}
          {chartMode === 'animated-stream' && (
            <div className="w-full flex flex-col justify-between relative py-1 space-y-3">
              {/* MEGA LIVE PRICE & HYPE BANNER */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#0d1f30] via-[#091a2a] to-[#071524] border border-[#00F0FF]/40 shadow-[0_0_20px_rgba(0,240,255,0.15)] flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                    <span className="text-[11px] font-mono font-extrabold uppercase tracking-wider text-emerald-400">
                      SPIKE (SPK) / USDT · LIVE AMM PRICE
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                      Range: $1.00 – $1.20
                    </span>
                  </div>
                  <div className="flex flex-wrap items-baseline gap-2.5">
                    <span className="text-3xl sm:text-4xl font-extrabold font-headline text-white tracking-tight tabular-nums drop-shadow-[0_0_15px_rgba(0,240,255,0.4)]">
                      ${spikeTokenInfo.currentPrice.toFixed(4)}
                    </span>
                    <span className="text-xs sm:text-sm font-headline font-bold text-emerald-400 flex items-center gap-0.5">
                      <span className="material-symbols-outlined text-[16px]">trending_up</span>
                      <span>
                        +{spikeTokenInfo.change24h}% (Steady AMM Dynamic Range)
                      </span>
                    </span>
                  </div>
                </div>

                {/* Quick Stats Grid */}
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs font-mono">
                  <div className="px-3 py-1.5 rounded-xl bg-[#051424] border border-[#1c2b3b]">
                    <div className="text-[10px] text-[#94a3b8] uppercase">24h High</div>
                    <div className="text-white font-bold tabular-nums">
                      ${(spikeTokenInfo.high24h ?? 1.20).toFixed(4)}
                    </div>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-[#051424] border border-[#1c2b3b]">
                    <div className="text-[10px] text-[#94a3b8] uppercase">24h Low</div>
                    <div className="text-white font-bold tabular-nums">
                      ${(spikeTokenInfo.low24h ?? 1.00).toFixed(4)}
                    </div>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-[#051424] border border-[#1c2b3b]">
                    <div className="text-[10px] text-[#94a3b8] uppercase">Pool Liquidity</div>
                    <div className="text-[#D4AF37] font-bold">
                      ${spikeTokenInfo.poolUsdtReserve.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* BUY VS SELL PRESSURE HYPE METER */}
              <div className="p-3 rounded-xl bg-[#081321] border border-[#1c2b3b] space-y-1.5">
                <div className="flex justify-between items-center text-xs font-mono">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span>BUY PRESSURE: {buyPressure.toFixed(1)}% (EXTREME BULLISH)</span>
                    <span className="text-[10px] text-[#94a3b8]">({totalBuysCount} Buys)</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-red-400 font-bold">
                    <span>SELL PRESSURE: {(100 - buyPressure).toFixed(1)}%</span>
                    <span className="text-[10px] text-[#94a3b8]">({totalSellsCount} Sells)</span>
                  </div>
                </div>

                {/* Pressure Progress Bar */}
                <div className="w-full h-2.5 bg-red-500/30 rounded-full overflow-hidden flex shadow-inner">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 via-[#00F0FF] to-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.6)] transition-all duration-500 rounded-full"
                    style={{ width: `${buyPressure}%` }}
                  />
                </div>
              </div>

              {/* TRADINGVIEW LIVE CANDLESTICK TERMINAL ACCORDING TO SPIKE & USDT TRANSACTIONS */}
              <TradingViewChart
                pairName="SPIKE (SPK) / USDT [BEP-20]"
                routerAddress={PANCAKESWAP_ROUTER_ADDRESS}
                transactions={liveTxns}
                currentPrice={currentPrice}
                onCopyText={onCopyText}
                onBuyClick={() => {
                  if (onOpenSwapModal) {
                    onOpenSwapModal('buySpike');
                  } else {
                    onCopyText(spikeTokenInfo.contractAddress);
                  }
                }}
              />

              {/* Bottom Quick Bar with Direct Contract Details & PancakeSwap Router Details */}
              <div className="flex flex-wrap items-center justify-between gap-3 mt-2 pt-2 border-t border-[#1c2b3b]/70 text-xs font-mono text-[#94a3b8]">
                <div className="flex flex-wrap items-center gap-3">
                  {/* SPIKE BEP-20 Token Contract */}
                  <div className="flex items-center gap-1.5 bg-[#0a1827] px-2.5 py-1 rounded-lg border border-[#1e2d42]">
                    <span className="text-[#94a3b8]">SPIKE (BEP-20):</span>
                    <button
                      onClick={() => onCopyText(spikeTokenInfo.contractAddress)}
                      className="text-[#00F0FF] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                      title="Click to copy SPIKE Token Contract"
                    >
                      <span>
                        {`${spikeTokenInfo.contractAddress.substring(0, 8)}...${spikeTokenInfo.contractAddress.substring(spikeTokenInfo.contractAddress.length - 4)}`}
                      </span>
                      <span className="material-symbols-outlined text-[13px]">content_copy</span>
                    </button>
                  </div>

                  {/* Official PancakeSwap Liquidity Pool Contract */}
                  <div className="flex items-center gap-1.5 bg-[#0a1827] px-2.5 py-1 rounded-lg border border-[#D4AF37]/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
                    <span className="text-[#94a3b8]">Pool (Pair):</span>
                    <button
                      onClick={() => onCopyText(PANCAKESWAP_PAIR_CONTRACT)}
                      className="text-[#D4AF37] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                      title="Click to copy PancakeSwap Liquidity Pool Contract (0xdB75fAB72e56492CFE870344D115C57047992F3c)"
                    >
                      <span>
                        {`${PANCAKESWAP_PAIR_CONTRACT.substring(0, 8)}...${PANCAKESWAP_PAIR_CONTRACT.substring(PANCAKESWAP_PAIR_CONTRACT.length - 4)}`}
                      </span>
                      <span className="material-symbols-outlined text-[13px]">content_copy</span>
                    </button>
                    <a
                      href={BSCSCAN_PAIR_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[#94a3b8] hover:text-[#D4AF37]"
                      title="Open PancakeSwap Pool on BSCScan"
                    >
                      <span className="material-symbols-outlined text-[13px]">open_in_new</span>
                    </a>
                  </div>

                  {/* Official PancakeSwap Router Contract */}
                  <div className="flex items-center gap-1.5 bg-[#0a1827] px-2.5 py-1 rounded-lg border border-[#00F0FF]/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[#94a3b8]">Router:</span>
                    <button
                      onClick={() => onCopyText(PANCAKESWAP_ROUTER_ADDRESS)}
                      className="text-emerald-400 hover:underline flex items-center gap-1 font-bold cursor-pointer"
                      title="Click to copy PancakeSwap Router Contract"
                    >
                      <span>
                        {`${PANCAKESWAP_ROUTER_ADDRESS.substring(0, 8)}...${PANCAKESWAP_ROUTER_ADDRESS.substring(PANCAKESWAP_ROUTER_ADDRESS.length - 4)}`}
                      </span>
                      <span className="material-symbols-outlined text-[13px]">content_copy</span>
                    </button>
                    <a
                      href={BSCSCAN_ROUTER_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[#94a3b8] hover:text-white"
                      title="Open PancakeSwap Router on BSCScan"
                    >
                      <span className="material-symbols-outlined text-[13px]">open_in_new</span>
                    </a>
                  </div>
                </div>

                {onOpenSwapModal && (
                  <button
                    onClick={() => onOpenSwapModal()}
                    className="text-xs text-[#00F0FF] hover:text-[#7df4ff] flex items-center gap-1.5 font-headline font-bold cursor-pointer transition-colors bg-[#00F0FF]/10 hover:bg-[#00F0FF]/20 px-3 py-1.5 rounded-xl border border-[#00F0FF]/30"
                  >
                    <span className="material-symbols-outlined text-[16px]">swap_horiz</span>
                    <span>Launch SPIKE DEX Swap Terminal</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ============================================================
              VIEW 3: HASHRATE TELEMETRY (Original)
             ============================================================ */}
          {chartMode === 'hashrate' && (
            <div className="w-full h-56 md:h-64 flex flex-col justify-end relative py-2">
              <div className="flex justify-between items-center text-xs font-mono text-[#94a3b8] mb-2">
                <span>Active Global Hashrate Output</span>
                <div className="flex items-center gap-1">
                  {(['24H', '7D', '30D'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setTimeframe(t)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        timeframe === t ? 'bg-[#00F0FF] text-[#0A0F1D]' : 'hover:text-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Background Grid Lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-20">
                <div className="w-full h-[1px] bg-[#46464c]"></div>
                <div className="w-full h-[1px] bg-[#46464c]"></div>
                <div className="w-full h-[1px] bg-[#46464c]"></div>
                <div className="w-full h-[1px] bg-[#46464c]"></div>
              </div>

              {/* SVG Wave */}
              <div className="relative w-full h-44 overflow-visible">
                <svg
                  className="w-full h-full overflow-visible"
                  preserveAspectRatio="none"
                  viewBox="0 0 800 200"
                >
                  <defs>
                    <linearGradient id="chartGradientLive" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.35" />
                      <stop offset="100%" stopColor="#00F0FF" stopOpacity="0.0" />
                    </linearGradient>
                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="3" result="glow" />
                      <feComposite in="SourceGraphic" in2="glow" operator="over" />
                    </filter>
                  </defs>

                  {/* Shaded Area */}
                  <path d={currentChart.fillD} fill="url(#chartGradientLive)" />

                  {/* Main Curve */}
                  <path
                    d={currentChart.pathD}
                    fill="none"
                    stroke="#00F0FF"
                    strokeLinecap="round"
                    strokeWidth="3.5"
                    filter="url(#glow)"
                  />

                  {/* Interactive Points */}
                  {currentChart.points.map((pt, idx) => {
                    const isLast = idx === currentChart.points.length - 1;
                    return (
                      <g key={idx}>
                        <circle
                          cx={pt.cx}
                          cy={pt.cy}
                          r={isLast ? 6 : 5}
                          fill={isLast ? '#00F0FF' : '#0A0F1D'}
                          stroke={isLast ? '#FFFFFF' : '#00F0FF'}
                          strokeWidth={isLast ? 2.5 : 3}
                          className="cursor-pointer transition-transform hover:scale-150"
                          onMouseEnter={() =>
                            setHoveredDataPoint({
                              x: pt.cx,
                              y: pt.cy,
                              hashrate: pt.rate,
                              time: pt.time,
                            })
                          }
                          onMouseLeave={() => setHoveredDataPoint(null)}
                        />
                      </g>
                    );
                  })}
                </svg>

                {/* Hover Tooltip */}
                {hoveredDataPoint && (
                  <div
                    className="absolute pointer-events-none bg-[#0a0f1d] border border-[#00F0FF] rounded-lg px-2.5 py-1.5 shadow-xl text-xs font-mono transform -translate-x-1/2 -translate-y-full mb-2 z-20"
                    style={{
                      left: `${(hoveredDataPoint.x / 800) * 100}%`,
                      top: `${(hoveredDataPoint.y / 200) * 100}%`,
                    }}
                  >
                    <div className="text-[#00F0FF] font-bold tabular-nums">{hoveredDataPoint.hashrate}</div>
                    <div className="text-[10px] text-[#94a3b8]">{hoveredDataPoint.time}</div>
                  </div>
                )}
              </div>

              {/* Time labels matching Image 2 */}
              <div className="flex justify-between text-xs text-[#94a3b8] mt-4 font-mono">
                {currentChart.timeLabels.map((lbl, idx) => (
                  <span
                    key={idx}
                    className={idx === currentChart.timeLabels.length - 1 ? 'text-[#00F0FF] font-bold' : ''}
                  >
                    {lbl}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Quick Stats / Pool Info (1 Col) */}
        <div className="bg-[#122130] rounded-xl p-5 md:p-6 flex flex-col justify-between shadow-md border border-[#1c2b3b]/60">
          <div>
            <h2 className="text-lg md:text-xl font-bold font-headline text-white mb-1 tracking-tight">
              Pool Metrics
            </h2>
            <p className="text-xs text-[#94a3b8] mb-5">BSC Smart Contract Overview</p>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#1c2b3b] border border-[#1c2b3b]/60">
                <span className="text-[#94a3b8] text-xs font-medium">Network Difficulty</span>
                <span className="text-white font-headline font-semibold text-sm tabular-nums">
                  48.25 P
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#1c2b3b] border border-[#1c2b3b]/60">
                <span className="text-[#94a3b8] text-xs font-medium">Current Block Reward</span>
                <span className="text-[#D4AF37] font-headline font-semibold text-sm tabular-nums">
                  3.20 USDT
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#1c2b3b] border border-[#1c2b3b]/60">
                <span className="text-[#94a3b8] text-xs font-medium">Gas Fee Estimate</span>
                <span className="text-white font-mono font-medium text-xs tabular-nums">
                  0.00042 BNB
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#1c2b3b] border border-[#1c2b3b]/60">
                <span className="text-[#94a3b8] text-xs font-medium">Contract Uptime</span>
                <span className="text-[#00F0FF] font-headline font-semibold text-sm tabular-nums">
                  99.98%
                </span>
              </div>
            </div>
          </div>

          {/* Audited Contract Card */}
          <div className="mt-5 pt-3">
            <div
              onClick={onOpenAuditModal}
              className="p-3.5 rounded-xl bg-[#010f1e] hover:bg-[#0a0f1d] border border-[#1c2b3b] flex items-center justify-between cursor-pointer transition-colors group"
            >
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[#D4AF37] text-[24px]">
                  verified_user
                </span>
                <div>
                  <div className="text-xs font-bold font-headline text-white group-hover:text-[#00F0FF] transition-colors tracking-wide">
                    Audited Contract
                  </div>
                  <div className="text-[11px] text-[#94a3b8] font-mono">CertiK Secure Level 2</div>
                </div>
              </div>
              <span className="material-symbols-outlined text-[#94a3b8] text-sm group-hover:text-[#00F0FF] group-hover:translate-x-0.5 transition-all">
                open_in_new
              </span>
            </div>
          </div>
        </div>
      </div>


    </div>
  );
};
