import fs from 'fs';
import path from 'path';

export interface DbUser {
  address: string;
  balanceUsdt: number;
  balanceBnb: number;
  totalMined: number;
  referralCode: string;
  referredBy: string | null;
  role: 'master' | 'admin' | 'user' | 'moderator';
  status: 'active' | 'frozen' | 'banned';
  hasDepositedTreasury?: boolean;
  hasActivatedMining?: boolean;
  createdAt: string;
  lastActive: string;
  notes?: string;
  customHashrate?: number | null;
  customHashrateReason?: string;
  balanceSpk?: number;
  miningCycleStartTime?: number;
}

export interface DbMiningNode {
  id: string;
  userAddress: string;
  name: string;
  region: string;
  status: 'mining' | 'idle' | 'syncing' | 'stopped';
  hashrate: number;
  temperature: number;
  shareAcceptance: number;
  fanSpeed: number;
  powerUsage: number;
  uptimeDays: number;
  algorithm: string;
  logs: string[];
  costUsdt: number;
  deployedAt: string;
}

export interface DbTransaction {
  id: string;
  userAddress: string;
  txHash: string;
  type: 'activation' | 'claim' | 'swap' | 'referral_bonus' | 'faucet' | 'admin_adjustment' | 'deposit' | 'milestone_reward' | 'payout';
  amount: number;
  currency: string;
  timestamp: string;
  status: 'Confirmed' | 'Pending' | 'Rejected';
  details: string;
  blockNumber: number;
}

export interface DbReferral {
  id: string;
  referrerAddress: string;
  refereeAddress: string;
  tier: number;
  commissionUsdt: number;
  volumeUsdt: number;
  createdAt: string;
}

export interface DbAnnouncement {
  id: string;
  title: string;
  content: string;
  badge: string;
  priority: 'high' | 'medium' | 'low';
  author: string;
  isActive: boolean;
  createdAt: string;
}

export interface DbSettings {
  turboMultiplier: number;
  dailyYieldPercent: number;
  baseHashrateTh: number;
  miningCycleHours: number;
  dailyRewardSpk: number;
  minDepositUsdt: number;
  pancakeRouterAddress: string;
  pancakePairAddress: string;
  testnetFastCycleEnabled: boolean;
  maintenanceMode: boolean;
  maintenanceMessage?: string;
  stratumPoolUrl: string;
  bscContractAddress: string;
  treasuryWalletAddress: string;
  treasuryBalanceUsdt: number;
  minWithdrawalUsdt: number;
  autoPayoutEnabled: boolean;
  updatedAt: string;
  primaryDomain: string;
  protocolUrl: string;
  apiBaseUrl: string;
  docsUrl: string;
  rpcUrl: string;
  telegramUrl: string;
  twitterUrl: string;
  supportEmail: string;
  masterWalletAddresses: string[];
  nodeCostUsdt: number;
  tier1CommissionPercent: number;
  tier2CommissionPercent: number;
  level1DirectsRequired: number;
  level2DirectsRequired: number;
  level3DirectsRequired: number;
  level1HashrateBoost: number;
  level2HashrateBoost: number;
  level3HashrateBoost: number;
}

export interface DbAuditLog {
  id: string;
  adminUser: string;
  action: string;
  target: string;
  details: string;
  timestamp: string;
}

export interface DbTestnetWallet {
  address: string;
  testnetUsdt: number;
  testnetSpk: number;
  autoBuyEnabled: boolean;
  slippageTolerance: number;
  totalHarvestAutoBoughtSpk: number;
  totalUsdtSpentOnAutoBuy: number;
  lastAutoBuyAt?: string;
}

export interface DbTestnetTx {
  id: string;
  userAddress: string;
  txHash: string;
  type: 'harvest_autobuy' | 'swap_buy' | 'swap_sell' | 'faucet';
  spkAmount: number;
  usdtAmount: number;
  priceUsdt: number;
  status: 'Confirmed' | 'Pending';
  blockNumber: number;
  gasFeeBnb: number;
  details: string;
  timestamp: string;
}

export interface DbTestnetSpikeToken {
  name: string;
  symbol: string;
  totalSupply: number; // 50,000,000 SPK
  circulatingSupply: number;
  decimals: number;
  contractAddress: string;
  pair: string;
  poolSpkReserve: number;
  poolUsdtReserve: number;
  currentPrice: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  change24h: number;
  buyPressure: number;
}

export interface DbWithdrawalRequest {
  id: string;
  userAddress: string;
  destinationAddress: string;
  amount: number;
  source: string;
  milestoneLabel?: string;
  status: 'pending' | 'approved' | 'rejected';
  txHash?: string;
  adminNote?: string;
  requestedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface DatabaseSchema {
  version: number;
  lastSaved: string;
  users: DbUser[];
  nodes: DbMiningNode[];
  transactions: DbTransaction[];
  referrals: DbReferral[];
  announcements: DbAnnouncement[];
  settings: DbSettings;
  auditLogs: DbAuditLog[];
  withdrawalRequests: DbWithdrawalRequest[];
  testnetWallets: DbTestnetWallet[];
  testnetTransactions: DbTestnetTx[];
  testnetSpikeToken: DbTestnetSpikeToken;
}

const DATA_DIR = path.resolve('.data');
const DB_FILE = path.join(DATA_DIR, 'spike_database.json');
const BACKUP_FILE = path.join(DATA_DIR, 'spike_database.bak.json');

const INITIAL_DATA: DatabaseSchema = {
  version: 1,
  lastSaved: new Date().toISOString(),
  users: [
    {
      address: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
      balanceUsdt: 0.0,
      balanceBnb: 0.0,
      totalMined: 0.0,
      balanceSpk: 0.0,
      referralCode: 'SPK-3471E0',
      referredBy: null,
      role: 'master',
      status: 'active',
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      notes: 'Master Creator & Protocol Root Authority',
    },
  ],
  nodes: [],
  transactions: [],
  referrals: [],
  announcements: [],
  settings: {
    turboMultiplier: 10,
    dailyYieldPercent: 3.88,
    baseHashrateTh: 1.25,
    miningCycleHours: 24,
    dailyRewardSpk: 35.0,
    minDepositUsdt: 5.0,
    pancakeRouterAddress: '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4',
    pancakePairAddress: '0xdB75fAB72e56492CFE870344D115C57047992F3c',
    testnetFastCycleEnabled: false,
    maintenanceMode: false,
    stratumPoolUrl: 'stratum+tcp://pool.spikenodes.com:443',
    bscContractAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
    treasuryWalletAddress: '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7',
    treasuryBalanceUsdt: 0.0,
    minWithdrawalUsdt: 5.0,
    autoPayoutEnabled: true,
    updatedAt: new Date().toISOString(),
    primaryDomain: 'spikenodes.com',
    protocolUrl: 'https://spikenodes.com',
    apiBaseUrl: 'https://spikenodes.com/api',
    docsUrl: 'https://docs.spikenodes.com',
    rpcUrl: 'https://bsc-dataseed.binance.org/',
    telegramUrl: 'https://t.me/spikenodes',
    twitterUrl: 'https://x.com/spikenodes',
    supportEmail: 'contact@spikenodes.com',
    masterWalletAddresses: [
      '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
    ],
    maintenanceMessage: 'Spike Stratum Protocol is currently undergoing scheduled network maintenance.',
    nodeCostUsdt: 15.0,
    tier1CommissionPercent: 15,
    tier2CommissionPercent: 5,
    level1DirectsRequired: 10,
    level2DirectsRequired: 25,
    level3DirectsRequired: 50,
    level1HashrateBoost: 200,
    level2HashrateBoost: 400,
    level3HashrateBoost: 600,
  },
  auditLogs: [
    {
      id: 'audit-init',
      adminUser: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
      action: 'SYSTEM_BOOTSTRAP',
      target: 'spike_database',
      details: 'Clean mainnet baseline initialized: Treasury 0.0 USDT, 0 SPK balance, clean nodes and transactions.',
      timestamp: new Date().toISOString(),
    },
  ],
  withdrawalRequests: [],
  testnetWallets: [],
  testnetTransactions: [],
  testnetSpikeToken: {
    name: 'SPIKE',
    symbol: 'SPK',
    totalSupply: 50_000_000,
    circulatingSupply: 0,
    decimals: 18,
    contractAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
    pair: '0xdB75fAB72e56492CFE870344D115C57047992F3c',
    poolSpkReserve: 10_000_000,
    poolUsdtReserve: 345_000,
    currentPrice: 1.12,
    volume24h: 0,
    high24h: 1.20,
    low24h: 1.00,
    change24h: 0,
    buyPressure: 50,
  },
};

class PersistentDatabase {
  private data: DatabaseSchema;
  private isSaving = false;
  private onSaveCallback?: (data: DatabaseSchema) => void;

  constructor() {
    this.ensureDirectory();
    this.data = this.load();
  }

  public setOnSaveCallback(cb: (data: DatabaseSchema) => void) {
    this.onSaveCallback = cb;
  }

  private ensureDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version) {
          const loadedSettings = {
            ...INITIAL_DATA.settings,
            ...(parsed.settings || {}),
          };
          if (!loadedSettings.primaryDomain || loadedSettings.primaryDomain.includes('spike.network') || loadedSettings.primaryDomain.includes('spike.finance')) {
            loadedSettings.primaryDomain = 'spikenodes.com';
            loadedSettings.protocolUrl = 'https://spikenodes.com';
            loadedSettings.apiBaseUrl = 'https://spikenodes.com/api';
            loadedSettings.docsUrl = 'https://docs.spikenodes.com';
            loadedSettings.rpcUrl = 'https://rpc.spikenodes.com';
          }
          if (loadedSettings.stratumPoolUrl?.includes('spike.network')) {
            loadedSettings.stratumPoolUrl = 'stratum+tcp://pool.spikenodes.com:443';
          }
          if (!loadedSettings.treasuryWalletAddress) {
            loadedSettings.treasuryWalletAddress = '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7';
          }
          if (!loadedSettings.pancakeRouterAddress) {
            loadedSettings.pancakeRouterAddress = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
          }
          if (!loadedSettings.pancakePairAddress) {
            loadedSettings.pancakePairAddress = '0xdB75fAB72e56492CFE870344D115C57047992F3c';
          }
          if (typeof loadedSettings.treasuryBalanceUsdt !== 'number') {
            loadedSettings.treasuryBalanceUsdt = 0.0;
          }
          if (!Array.isArray(loadedSettings.masterWalletAddresses) || loadedSettings.masterWalletAddresses.length === 0) {
            loadedSettings.masterWalletAddresses = [
              '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
              '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
            ];
          } else if (!loadedSettings.masterWalletAddresses.map((a: string) => a.toLowerCase()).includes('0x3471e07c4d2f7e11c155760a7b386e616b5c3715')) {
            loadedSettings.masterWalletAddresses.push('0x3471e07c4d2f7e11c155760a7b386e616b5c3715');
          }
          if (typeof loadedSettings.tier1CommissionPercent !== 'number') loadedSettings.tier1CommissionPercent = 15;
          if (typeof loadedSettings.tier2CommissionPercent !== 'number') loadedSettings.tier2CommissionPercent = 5;
          if (typeof loadedSettings.level1DirectsRequired !== 'number') loadedSettings.level1DirectsRequired = 10;
          if (typeof loadedSettings.level2DirectsRequired !== 'number') loadedSettings.level2DirectsRequired = 25;
          if (typeof loadedSettings.level3DirectsRequired !== 'number') loadedSettings.level3DirectsRequired = 50;
          if (typeof loadedSettings.level1HashrateBoost !== 'number') loadedSettings.level1HashrateBoost = 200;
          if (typeof loadedSettings.level2HashrateBoost !== 'number') loadedSettings.level2HashrateBoost = 400;
          if (typeof loadedSettings.level3HashrateBoost !== 'number') loadedSettings.level3HashrateBoost = 600;
          if (typeof loadedSettings.nodeCostUsdt !== 'number') loadedSettings.nodeCostUsdt = 15.0;
          if (!loadedSettings.maintenanceMessage) {
            loadedSettings.maintenanceMessage = 'Spike Stratum Protocol is currently undergoing scheduled network maintenance.';
          }
          const sanitizedUsers = (parsed.users || INITIAL_DATA.users).map((u: DbUser) => {
            if (u.referredBy && (u.referredBy.toLowerCase() === u.address.toLowerCase() || u.referredBy.toLowerCase() === (u.referralCode || '').toLowerCase())) {
              return { ...u, referredBy: null };
            }
            return u;
          });
          return {
            ...INITIAL_DATA,
            ...parsed,
            users: sanitizedUsers,
            settings: loadedSettings,
            withdrawalRequests: Array.isArray(parsed.withdrawalRequests) ? parsed.withdrawalRequests : [],
            testnetWallets: Array.isArray(parsed.testnetWallets) && parsed.testnetWallets.length ? parsed.testnetWallets : INITIAL_DATA.testnetWallets,
            testnetTransactions: Array.isArray(parsed.testnetTransactions) && parsed.testnetTransactions.length ? parsed.testnetTransactions : INITIAL_DATA.testnetTransactions,
            testnetSpikeToken: parsed.testnetSpikeToken || INITIAL_DATA.testnetSpikeToken,
          };
        }
      }
    } catch (err) {
      console.error('[DB] Error loading database file, checking backup:', err);
      try {
        if (fs.existsSync(BACKUP_FILE)) {
          const raw = fs.readFileSync(BACKUP_FILE, 'utf-8');
          const parsedBackup = JSON.parse(raw);
          return {
            ...INITIAL_DATA,
            ...parsedBackup,
            testnetWallets: parsedBackup.testnetWallets || INITIAL_DATA.testnetWallets,
            testnetTransactions: parsedBackup.testnetTransactions || INITIAL_DATA.testnetTransactions,
            testnetSpikeToken: parsedBackup.testnetSpikeToken || INITIAL_DATA.testnetSpikeToken,
          };
        }
      } catch (backupErr) {
        console.error('[DB] Backup load failed too:', backupErr);
      }
    }

    // If no existing file, write initial data
    this.saveDirect(INITIAL_DATA);
    return JSON.parse(JSON.stringify(INITIAL_DATA));
  }

  private saveDirect(dataToSave: DatabaseSchema) {
    try {
      this.ensureDirectory();
      dataToSave.lastSaved = new Date().toISOString();
      const content = JSON.stringify(dataToSave, null, 2);
      const tempFile = path.join(DATA_DIR, `spike_database.${Date.now()}.tmp`);
      fs.writeFileSync(tempFile, content, 'utf-8');
      fs.renameSync(tempFile, DB_FILE);

      // Create backup copy periodically
      try {
        fs.writeFileSync(BACKUP_FILE, content, 'utf-8');
      } catch {
        // backup failure non-fatal
      }

      if (this.onSaveCallback) {
        try {
          this.onSaveCallback(dataToSave);
        } catch {
          // ignore callback failure
        }
      }
    } catch (err) {
      console.error('[DB] Failed to save database to disk:', err);
    }
  }

  public save() {
    if (this.isSaving) return;
    this.isSaving = true;
    setTimeout(() => {
      this.saveDirect(this.data);
      this.isSaving = false;
    }, 50);
  }

  // ---- System Statistics ----
  public getStats() {
    const totalUsers = this.data.users.length;
    const activeNodes = this.data.nodes.filter((n) => n.status === 'mining').length;
    const totalNodes = this.data.nodes.length;
    const totalHashrate = this.data.nodes
      .filter((n) => n.status === 'mining')
      .reduce((sum, n) => sum + (n.hashrate || 0), 0);
    const totalMinedUsdt = this.data.users.reduce((sum, u) => sum + (u.totalMined || 0), 0);
    const totalUserBalance = this.data.users.reduce((sum, u) => sum + (u.balanceUsdt || 0), 0);
    const totalTransactions = this.data.transactions.length;

    let dbSizeKb = 0;
    try {
      if (fs.existsSync(DB_FILE)) {
        dbSizeKb = Math.round(fs.statSync(DB_FILE).size / 1024);
      }
    } catch {
      dbSizeKb = 0;
    }

    return {
      totalUsers,
      activeNodes,
      totalNodes,
      totalHashrate: +totalHashrate.toFixed(2),
      totalMinedUsdt: +totalMinedUsdt.toFixed(2),
      totalUserBalance: +totalUserBalance.toFixed(2),
      totalTransactions,
      dbSizeKb,
      lastSaved: this.data.lastSaved,
      maintenanceMode: this.data.settings.maintenanceMode,
      turboMultiplier: this.data.settings.turboMultiplier,
      dailyYieldPercent: this.data.settings.dailyYieldPercent,
    };
  }

  // ---- Hashrate Level Calculation (Image Spec) ----
  // Formula: Required Hashrate = 100 * (60 / Target Days)
  // Fresh user: 0 referrals -> 60 days -> 100 VH/s
  // Level 1: 10 directs -> 30 days -> 200 VH/s
  // Level 2: 100 total team -> 15 days -> 400 VH/s
  // Level 3: 1,000 total team -> 10 days -> 600 VH/s
  // Level 4: 5,000 total team -> 7 days -> 857.14 VH/s
  public getUserTeamStats(userAddress: string): {
    directCount: number;
    downlineCount: number;
    totalTeamCount: number;
    levelCounts: Record<number, number>;
    levelMembers: Record<number, string[]>;
  } {
    const norm = (userAddress || '').toLowerCase();
    if (!norm) return {
      directCount: 0,
      downlineCount: 0,
      totalTeamCount: 0,
      levelCounts: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 },
      levelMembers: { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: [], 9: [] }
    };

    const slice6 = norm.startsWith('0x') ? norm.slice(2, 8) : norm.replace(/^(spike-|spk-)/i, '');
    const userCode = `spk-${slice6}`.toLowerCase();

    // Level 1: Match both canonical 0x address, referral code (e.g. SPK-3471E0), and slice
    const directs = this.data.referrals.filter((r) => {
      const ref = (r.referrerAddress || '').toLowerCase();
      return (
        ref === norm ||
        ref === userCode ||
        ref === `spike-${slice6}` ||
        ref === slice6 ||
        ref.includes(slice6)
      );
    });

    // Deduplicate unique direct referee wallets (Level 1)
    const uniqueDirects = new Set<string>();
    directs.forEach((d) => {
      const refAddr = (d.refereeAddress || '').toLowerCase().trim();
      if (refAddr && refAddr !== norm && refAddr !== userCode) {
        uniqueDirects.add(refAddr);
      }
    });

    // ALSO check registered users table for any referee linked via referredBy
    this.data.users.forEach((u) => {
      if (u.referredBy) {
        const rb = u.referredBy.toLowerCase().trim();
        if (
          rb === norm ||
          rb === userCode ||
          rb === `spike-${slice6}` ||
          rb === slice6 ||
          rb.includes(slice6)
        ) {
          const uAddr = u.address.toLowerCase().trim();
          if (uAddr && uAddr !== norm && uAddr !== userCode) {
            uniqueDirects.add(uAddr);
          }
        }
      }
    });

    const directCount = uniqueDirects.size;

    // Track level by level (Unilevel Tree: Level 1, Level 2, Level 3, Level 4... up to Level 9)
    const levelCounts: Record<number, number> = {
      1: directCount,
      2: 0,
      3: 0,
      4: 0,
      5: 0,
      6: 0,
      7: 0,
      8: 0,
      9: 0,
    };

    const levelMembers: Record<number, string[]> = {
      1: Array.from(uniqueDirects),
      2: [],
      3: [],
      4: [],
      5: [],
      6: [],
      7: [],
      8: [],
      9: [],
    };

    const visited = new Set<string>();
    visited.add(norm);
    visited.add(userCode);
    uniqueDirects.forEach((a) => visited.add(a));

    let queue = Array.from(uniqueDirects);
    let downlineCount = 0;
    let currentLevel = 2;

    while (queue.length > 0 && currentLevel <= 9) {
      const nextTier: string[] = [];
      for (const parent of queue) {
        const pSlice = parent.startsWith('0x') ? parent.slice(2, 8) : parent.replace(/^(spike-|spk-)/i, '').slice(0, 6);
        const subReferrals = this.data.referrals.filter((r) => {
          const ref = (r.referrerAddress || '').toLowerCase().trim();
          return ref === parent || (pSlice && ref.includes(pSlice));
        });
        for (const sr of subReferrals) {
          const child = (sr.refereeAddress || '').toLowerCase().trim();
          if (child && !visited.has(child)) {
            visited.add(child);
            nextTier.push(child);
            downlineCount++;
          }
        }
        // Also traverse downline via users table
        this.data.users.forEach((u) => {
          if (u.referredBy) {
            const rb = u.referredBy.toLowerCase().trim();
            if (rb === parent || (pSlice && rb.includes(pSlice))) {
              const child = u.address.toLowerCase().trim();
              if (child && !visited.has(child)) {
                visited.add(child);
                nextTier.push(child);
                downlineCount++;
              }
            }
          }
        });
      }
      levelCounts[currentLevel] = nextTier.length;
      levelMembers[currentLevel] = nextTier;
      queue = nextTier;
      currentLevel++;
    }

    return {
      directCount,
      downlineCount,
      totalTeamCount: directCount + downlineCount,
      levelCounts,
      levelMembers,
    };
  }

  public calculateUserHashrate(address: string) {
    const norm = (address || '').toLowerCase();
    const user = this.getUser(norm);
    const teamStats = this.getUserTeamStats(norm);
    const { directCount, totalTeamCount, levelCounts } = teamStats;
    const l1Count = levelCounts[1] || directCount;
    const l2Count = levelCounts[2] || 0;
    const l3Count = levelCounts[3] || 0;
    const l4Count = levelCounts[4] || 0;

    // If admin has set a custom hashrate override for this wallet address
    if (user && typeof user.customHashrate === 'number' && user.customHashrate > 0) {
      const customDays = +(6000 / user.customHashrate).toFixed(1);
      return {
        level: 'Custom Admin',
        levelNumber: -1,
        hashrate: user.customHashrate,
        unit: 'VH/s',
        targetDays: customDays,
        dailySpkYield: +(user.customHashrate / 6000).toFixed(5),
        requirementText: `Admin Override (${user.customHashrateReason || 'Manual Rate'})`,
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: true,
        nextTier: null,
      };
    }

    const l1Hash = 200; // 2x
    const l2Hash = 400; // 4x
    const l3Hash = 600; // 6x
    const l4Hash = 857.14; // 8.5x

    // User exact specifications:
    // Level 4 (Apex Fleet Milestone): Criteria: 5,000 Total Team in level 4 -> 857.14 VH/s (7 Days)
    // Level 3 (Community Milestone): Criteria: 1,000 Total Team in level 3 -> 600 VH/s (10 Days)
    // Level 2 (Team Milestone): Criteria: 100 Total Team in level 2 (through level 1 directs) -> 400 VH/s (15 Days)
    // Level 1 (Direct Milestone): Criteria: 10 Direct Referrals in level 1 -> 200 VH/s (30 Days)
    // Fresh user: 0 referrals -> 100 VH/s (60 Days)

    if (l4Count >= 5000 || totalTeamCount >= 5000) {
      return {
        level: 'Level 4',
        levelNumber: 4,
        hashrate: l4Hash,
        unit: 'VH/s',
        targetDays: 7,
        dailySpkYield: +(l4Hash / 6000).toFixed(5),
        requirementText: '5,000 Total Team in Level 4',
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: false,
        nextTier: null,
      };
    } else if (l3Count >= 1000 || totalTeamCount >= 1000) {
      return {
        level: 'Level 3',
        levelNumber: 3,
        hashrate: l3Hash,
        unit: 'VH/s',
        targetDays: 10,
        dailySpkYield: +(l3Hash / 6000).toFixed(5),
        requirementText: '1,000 Total Team in Level 3',
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: false,
        nextTier: {
          level: 'Level 4',
          hashrate: l4Hash,
          requirementText: '5,000 Team in Level 4',
          neededInLevel: Math.max(0, 5000 - l4Count),
          neededTeam: Math.max(0, 5000 - totalTeamCount),
        },
      };
    } else if (l2Count >= 100 || totalTeamCount >= 100) {
      return {
        level: 'Level 2',
        levelNumber: 2,
        hashrate: l2Hash,
        unit: 'VH/s',
        targetDays: 15,
        dailySpkYield: +(l2Hash / 6000).toFixed(5),
        requirementText: '100 Total Team in Level 2',
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: false,
        nextTier: {
          level: 'Level 3',
          hashrate: l3Hash,
          requirementText: '1,000 Team in Level 3',
          neededInLevel: Math.max(0, 1000 - l3Count),
          neededTeam: Math.max(0, 1000 - totalTeamCount),
        },
      };
    } else if (l1Count >= 10) {
      return {
        level: 'Level 1',
        levelNumber: 1,
        hashrate: l1Hash,
        unit: 'VH/s',
        targetDays: 30,
        dailySpkYield: +(l1Hash / 6000).toFixed(5),
        requirementText: '10 Direct Referrals in Level 1',
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: false,
        nextTier: {
          level: 'Level 2',
          hashrate: l2Hash,
          requirementText: '100 Team in Level 2',
          neededInLevel: Math.max(0, 100 - l2Count),
          neededTeam: Math.max(0, 100 - totalTeamCount),
        },
      };
    } else {
      return {
        level: 'Fresh user',
        levelNumber: 0,
        hashrate: 100,
        unit: 'VH/s',
        targetDays: 60,
        dailySpkYield: +(100 / 6000).toFixed(5),
        requirementText: '0 Referrals (Base Tier)',
        directCount: l1Count,
        totalTeamCount,
        levelCounts,
        isCustomOverride: false,
        nextTier: {
          level: 'Level 1',
          hashrate: l1Hash,
          requirementText: '10 Direct Referrals in Level 1',
          neededDirects: Math.max(0, 10 - l1Count),
          neededInLevel: Math.max(0, 10 - l1Count),
          neededTeam: 0,
        },
      };
    }
  }

  public setUserCustomHashrate(
    address: string,
    hashrate: number | null,
    reason?: string,
    admin = 'Admin Portal'
  ): { success: boolean; user: DbUser; hashrateInfo: any } {
    const norm = (address || '').toLowerCase();
    let user = this.getUser(norm);
    if (!user) {
      user = this.upsertUser({ address: norm });
    }

    if (hashrate === null || isNaN(Number(hashrate)) || Number(hashrate) <= 0) {
      delete user.customHashrate;
      delete user.customHashrateReason;
    } else {
      user.customHashrate = Number(hashrate);
      user.customHashrateReason = reason || 'Admin Override';
    }
    user.lastActive = new Date().toISOString();

    const info = this.calculateUserHashrate(norm);

    // Update active nodes for this user to reflect new hashrate
    this.data.nodes.forEach((n) => {
      if (n.userAddress.toLowerCase() === norm) {
        n.hashrate = info.hashrate;
      }
    });

    this.logAudit(
      admin,
      'SET_HASHRATE',
      norm,
      hashrate === null ? 'Reset to Referral Auto Tier' : `Set custom hashrate to ${info.hashrate} VH/s (${info.level})`
    );
    this.save();
    return { success: true, user, hashrateInfo: info };
  }

  // ---- Users ----
  public getUsers(): (DbUser & { directPartners: number; totalPartners: number; hashrateInfo: any })[] {
    return this.data.users.map((u) => {
      const stats = this.getUserTeamStats(u.address);
      const hashrateInfo = this.calculateUserHashrate(u.address);
      return {
        ...u,
        directPartners: stats.directCount,
        totalPartners: stats.totalTeamCount,
        hashrateInfo,
      };
    });
  }

  public getUser(address: string): DbUser | undefined {
    const norm = address.toLowerCase();
    return this.data.users.find((u) => u.address.toLowerCase() === norm);
  }

  public upsertUser(user: Partial<DbUser> & { address: string }): DbUser {
    const norm = user.address.toLowerCase();
    const idx = this.data.users.findIndex((u) => u.address.toLowerCase() === norm);
    if (idx >= 0) {
      const existing = this.data.users[idx];
      this.data.users[idx] = {
        ...existing,
        ...user,
        // Permanent Referral Bond: once referredBy is set, it can NEVER be washed out, wiped, or set to null
        referredBy: existing.referredBy || user.referredBy || null,
        lastActive: new Date().toISOString(),
      };
      this.save();
      return this.data.users[idx];
    } else {
      const newUser: DbUser = {
        address: user.address,
        balanceUsdt: typeof user.balanceUsdt === 'number' ? user.balanceUsdt : 10.0,
        balanceBnb: typeof user.balanceBnb === 'number' ? user.balanceBnb : 0.005,
        totalMined: user.totalMined ?? 0.0,
        referralCode: user.referralCode || `SPK-${user.address.slice(2, 8).toUpperCase()}`,
        referredBy: user.referredBy || null,
        role: user.role || 'user',
        status: user.status || 'active',
        createdAt: new Date().toISOString(),
        lastActive: new Date().toISOString(),
        notes: user.notes || '',
      };
      this.data.users.push(newUser);
      this.logAudit('SYSTEM', 'USER_REGISTER', newUser.address, 'New user wallet connected to database');
      this.save();
      return newUser;
    }
  }

  public adjustUserBalance(
    address: string,
    usdtDelta: number,
    bnbDelta: number,
    reason: string,
    admin = 'admin'
  ): DbUser | null {
    const user = this.getUser(address);
    if (!user) return null;

    user.balanceUsdt = Math.max(0, +(user.balanceUsdt + usdtDelta).toFixed(2));
    if (bnbDelta !== 0) {
      user.balanceBnb = Math.max(0, +(user.balanceBnb + bnbDelta).toFixed(4));
    }
    user.lastActive = new Date().toISOString();

    // Record adjustment in transactions
    this.createTransaction({
      userAddress: user.address,
      txHash: `0x${Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      type: 'admin_adjustment',
      amount: usdtDelta,
      currency: 'USDT',
      status: 'Confirmed',
      details: `Admin adjustment: ${reason}`,
      blockNumber: 42900000 + Math.floor(Math.random() * 50000),
    });

    this.logAudit(admin, 'ADJUST_BALANCE', user.address, `USDT delta: ${usdtDelta}, Reason: ${reason}`);
    this.save();
    return user;
  }

  public setUserStatus(address: string, status: 'active' | 'frozen' | 'banned', admin = 'admin'): DbUser | null {
    const user = this.getUser(address);
    if (!user) return null;
    user.status = status;
    this.logAudit(admin, 'USER_STATUS_CHANGE', user.address, `Status set to ${status}`);
    this.save();
    return user;
  }

  public isMasterUser(address: string): boolean {
    if (!address) return false;
    const norm = address.toLowerCase();
    const list = (this.data.settings?.masterWalletAddresses || [
      '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
      '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
    ]).map((a) => a.toLowerCase());
    return list.includes(norm);
  }

  public updateUserRole(address: string, role: DbUser['role'], admin = 'admin'): DbUser | null {
    const user = this.getUser(address);
    if (!user) return null;
    user.role = role;
    this.logAudit(admin, 'USER_ROLE_CHANGE', user.address, `Role set to ${role}`);
    this.save();
    return user;
  }

  public syncUserBalance(
    address: string,
    balanceUsdt?: number,
    balanceBnb?: number,
    balanceSpk?: number,
    miningCycleStartTime?: number
  ): DbUser {
    const norm = address.toLowerCase();
    const user = this.upsertUser({ address: norm });
    if (typeof balanceUsdt === 'number' && !isNaN(balanceUsdt)) {
      user.balanceUsdt = Number(balanceUsdt.toFixed(2));
    }
    if (typeof balanceBnb === 'number' && !isNaN(balanceBnb)) {
      user.balanceBnb = Number(balanceBnb.toFixed(4));
    }
    if (typeof balanceSpk === 'number' && !isNaN(balanceSpk)) {
      user.balanceSpk = Number(balanceSpk.toFixed(4));
    }
    if (typeof miningCycleStartTime === 'number' && !isNaN(miningCycleStartTime) && miningCycleStartTime > 0) {
      user.miningCycleStartTime = miningCycleStartTime;
      user.hasActivatedMining = true;
    }
    user.lastActive = new Date().toISOString();
    this.save();
    return user;
  }

  // ---- Mining Nodes ----
  public getNodes(userAddress?: string): DbMiningNode[] {
    if (userAddress) {
      const norm = userAddress.toLowerCase();
      const hashrateInfo = this.calculateUserHashrate(norm);
      const userNodes = this.data.nodes.filter((n) => n.userAddress.toLowerCase() === norm);

      if (userNodes.length > 0) {
        userNodes.forEach((n) => {
          if (n.status === 'mining') {
            n.hashrate = hashrateInfo.hashrate;
          }
        });
        return userNodes;
      }

      // Ensure that if user has deposited into treasury, activated mining, or has active session, active node is never lost
      const user = this.getUser(norm);
      if (user && (user.hasActivatedMining || user.hasDepositedTreasury || user.role === 'admin')) {
        const autoNode: DbMiningNode = {
          id: `spk-node-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userAddress: norm,
          name: 'SPIKE ASIC Rig #1',
          region: 'US-East (Stratum Cluster)',
          status: 'mining',
          hashrate: hashrateInfo.hashrate,
          temperature: 64,
          shareAcceptance: 99.98,
          fanSpeed: 75,
          powerUsage: 1400,
          uptimeDays: 1,
          algorithm: 'SHA-256 (Stratum)',
          logs: [
            `24-Hour Mining Cycle Active [Level: ${hashrateInfo.level} · ${hashrateInfo.hashrate} VH/s]`,
            'Stratum+SSL target diff accepted: 1048576 (hash: 00000000...a4f2)',
          ],
          costUsdt: 5.0,
          deployedAt: new Date().toISOString(),
        };
        this.data.nodes.unshift(autoNode);
        this.save();
        return [autoNode];
      }
      return userNodes;
    }
    return this.data.nodes;
  }

  public getNode(id: string): DbMiningNode | undefined {
    return this.data.nodes.find((n) => n.id === id);
  }

  public createNode(nodeData: Omit<DbMiningNode, 'id' | 'deployedAt'>): DbMiningNode {
    const newNode: DbMiningNode = {
      ...nodeData,
      id: `spk-node-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      deployedAt: new Date().toISOString(),
    };
    this.data.nodes.unshift(newNode);
    this.logAudit(
      newNode.userAddress,
      'NODE_DEPLOYED',
      newNode.id,
      `Deployed ${newNode.name} (${newNode.hashrate} TH/s)`
    );
    this.save();
    return newNode;
  }

  public updateNodeStatus(id: string, status: DbMiningNode['status'], admin = 'user'): DbMiningNode | null {
    let node = this.getNode(id);
    if (!node) {
      // Check if node matches by name or user
      const normAdmin = admin.toLowerCase();
      node = this.data.nodes.find((n) => n.name === id || (n.userAddress.toLowerCase() === normAdmin && n.id.includes(id)));
    }
    if (!node) return null;
    node.status = status;
    if (status === 'mining') {
      node.temperature = 63;
      node.logs.unshift(`[${new Date().toLocaleTimeString()}] Resumed hashing on BSC sublayer pool.`);
    } else if (status === 'idle') {
      node.temperature = 45;
      node.logs.unshift(`[${new Date().toLocaleTimeString()}] Switched to idle power-save mode.`);
    } else if (status === 'stopped') {
      node.temperature = 38;
      node.logs.unshift(`[${new Date().toLocaleTimeString()}] Hashing stopped by controller.`);
    }
    node.logs = node.logs.slice(0, 10);
    this.logAudit(admin, 'NODE_STATUS_CHANGE', node.id, `Status set to ${status}`);
    this.save();
    return node;
  }

  public syncUserNodes(userAddress: string, clientNodes: any[]): DbMiningNode[] {
    const norm = (userAddress || '').toLowerCase();
    if (!norm) return [];
    if (!Array.isArray(clientNodes) || clientNodes.length === 0) {
      return this.getNodes(norm);
    }

    clientNodes.forEach((cn) => {
      const existing = this.data.nodes.find(
        (n) => n.id === cn.id || (n.userAddress.toLowerCase() === norm && n.name === cn.name)
      );
      if (existing) {
        existing.status = cn.status || existing.status;
        existing.hashrate = Number(cn.hashrate) || existing.hashrate;
        existing.temperature = Number(cn.temperature) || existing.temperature;
        existing.userAddress = norm;
      } else {
        this.data.nodes.unshift({
          id: cn.id || `spk-node-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userAddress: norm,
          name: cn.name || `Falcon Titan Apex Rig #${this.getNodes(norm).length + 1}`,
          region: cn.region || 'Frankfurt (EU-Central BSC Pool)',
          status: cn.status || 'mining',
          hashrate: Number(cn.hashrate) || 100,
          temperature: cn.temperature || 63,
          shareAcceptance: Number(cn.shareAcceptance) || 99.9,
          fanSpeed: Number(cn.fanSpeed) || 70,
          powerUsage: Number(cn.powerUsage) || 2200,
          uptimeDays: Number(cn.uptimeDays) || 0.1,
          algorithm: cn.algorithm || 'SHA-256 (BSC Sublayer)',
          logs: cn.logs || [`[${new Date().toLocaleTimeString()}] Active mining on BSC validator network.`],
          costUsdt: Number(cn.costUsdt) || 15,
          deployedAt: cn.deployedAt || new Date().toISOString(),
        });
      }
    });

    this.save();
    return this.getNodes(norm);
  }

  public deleteNode(id: string, admin = 'admin'): boolean {
    const initialLen = this.data.nodes.length;
    this.data.nodes = this.data.nodes.filter((n) => n.id !== id);
    const removed = this.data.nodes.length < initialLen;
    if (removed) {
      this.logAudit(admin, 'NODE_DELETED', id, `Rig removed from database fleet`);
      this.save();
    }
    return removed;
  }

  // ---- Transactions ----
  public getTransactions(userAddress?: string, limit = 50): DbTransaction[] {
    let list = this.data.transactions;
    if (userAddress) {
      const norm = userAddress.toLowerCase();
      list = list.filter((t) => t.userAddress.toLowerCase() === norm);
    }
    return list.slice(0, limit);
  }

  public createTransaction(tx: Omit<DbTransaction, 'id' | 'timestamp'>): DbTransaction {
    const newTx: DbTransaction = {
      ...tx,
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
    };
    this.data.transactions.unshift(newTx);
    this.save();
    return newTx;
  }

  public updateTransactionStatus(id: string, status: DbTransaction['status'], admin = 'admin'): DbTransaction | null {
    const tx = this.data.transactions.find((t) => t.id === id);
    if (!tx) return null;
    tx.status = status;
    this.logAudit(admin, 'TRANSACTION_STATUS_UPDATE', tx.id, `Status updated to ${status}`);
    this.save();
    return tx;
  }

  public verifyAndProcessDeposit(
    userAddress: string,
    txHash: string,
    amount = 15,
    officialWallet = '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7',
    customBlockNumber?: number
  ): { success: boolean; user?: DbUser; transaction?: DbTransaction; error?: string } {
    if (!userAddress || !txHash) {
      return { success: false, error: 'User address and transaction hash are required' };
    }

    const norm = userAddress.toLowerCase();
    const cleanHash = txHash.trim();

    // Verify hash uniqueness (prevent double crediting of same tx)
    const existing = this.data.transactions.find(
      (t) => t.txHash && t.txHash.toLowerCase() === cleanHash.toLowerCase()
    );
    if (existing) {
      return { success: false, error: 'This transaction hash has already been credited to a wallet.' };
    }

    const user = this.upsertUser({ address: norm });
    user.balanceUsdt = +(user.balanceUsdt + amount).toFixed(2);
    user.lastActive = new Date().toISOString();

    const currentTreasury = typeof this.data.settings.treasuryBalanceUsdt === 'number' ? this.data.settings.treasuryBalanceUsdt : 0.0;
    this.data.settings.treasuryBalanceUsdt = +(currentTreasury + amount).toFixed(2);

    const newTx = this.createTransaction({
      userAddress: norm,
      txHash: cleanHash,
      type: 'deposit',
      amount,
      currency: 'USDT',
      status: 'Confirmed',
      details: `BEP-20 USDT deposit to official wallet ${officialWallet}. Credited $${amount} to Mining Balance.`,
      blockNumber: customBlockNumber || 42950000 + Math.floor(Math.random() * 25000),
    });

    this.logAudit(
      'SYSTEM_VERIFIER',
      'DEPOSIT_VERIFIED',
      norm,
      `Hash: ${cleanHash.slice(0, 16)}... | Amount: +${amount} USDT | Official: ${officialWallet}`
    );

    this.save();
    return { success: true, user, transaction: newTx };
  }

  // ---- Referrals ----
  public getReferrals(userAddress?: string): DbReferral[] {
    if (userAddress) {
      const norm = userAddress.toLowerCase();
      return this.data.referrals.filter(
        (r) => r.referrerAddress.toLowerCase() === norm || r.refereeAddress.toLowerCase() === norm
      );
    }
    return this.data.referrals;
  }

  public getReferralStats(userAddressOrCode: string) {
    if (!userAddressOrCode) {
      return {
        address: '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
        directPartners: 0,
        downlinePartners: 0,
        totalPartners: 0,
        totalCommissions: 0,
        referrals: [],
        referredBy: null,
        referralCode: 'SPK-71C8A9',
      };
    }

    const resolvedUser = this.findUserByReferralCodeOrAddress(userAddressOrCode);
    const targetAddress = resolvedUser ? resolvedUser.address : (userAddressOrCode.startsWith('0x') ? userAddressOrCode : '0x71C8a914B97e889F12A0987cB32456Fa12349A2');
    const norm = targetAddress.toLowerCase();

    const slice6 = norm.startsWith('0x') ? norm.slice(2, 8) : norm.replace(/^(spike-|spk-)/i, '');
    const userCode = `spk-${slice6}`.toLowerCase();

    const directs = this.data.referrals.filter((r) => {
      const ref = (r.referrerAddress || '').toLowerCase();
      return (
        ref === norm ||
        ref === userCode ||
        ref === `spike-${slice6}` ||
        ref === slice6 ||
        ref.includes(slice6)
      );
    });

    const directsMap = new Map<string, DbReferral>();
    directs.forEach((d) => {
      if (d.refereeAddress) {
        directsMap.set(d.refereeAddress.toLowerCase(), d);
      }
    });

    // Also include any registered users who have this sponsor as referredBy
    this.data.users.forEach((u) => {
      if (u.referredBy) {
        const rb = u.referredBy.toLowerCase().trim();
        if (
          rb === norm ||
          rb === userCode ||
          rb === `spike-${slice6}` ||
          rb === slice6 ||
          rb.includes(slice6)
        ) {
          const uNorm = u.address.toLowerCase();
          if (uNorm !== norm && !directsMap.has(uNorm)) {
            directsMap.set(uNorm, {
              id: `ref-user-${uNorm.slice(2, 8)}`,
              referrerAddress: targetAddress,
              refereeAddress: u.address,
              tier: 1,
              commissionUsdt: 0,
              volumeUsdt: 150.0,
              createdAt: u.createdAt || new Date().toISOString(),
            });
          }
        }
      }
    });

    const allDirects = Array.from(directsMap.values());
    const totalCommissions = allDirects.reduce((acc, r) => acc + (r.commissionUsdt || 0), 0);
    const hashrateInfo = this.calculateUserHashrate(norm);
    const teamStats = this.getUserTeamStats(norm);
    // Calculate milestone rewards recorded in transactions for this user (strictly earned rewards, excluding payouts/withdrawals)
    const milestoneRewards = this.data.transactions
      .filter((t) => {
        if (!t.userAddress || t.userAddress.toLowerCase() !== norm) return false;
        if (t.type === 'payout' || t.type === 'activation' || (t.amount || 0) <= 0) return false;
        return t.type === 'milestone_reward' || (t.type === 'claim' && t.details && t.details.includes('Milestone'));
      })
      .reduce((sum, t) => sum + (t.amount || 0), 0);

    const withdrawals = this.getWithdrawalRequests(norm);
    const pendingWithdrawalsAmount = withdrawals
      .filter((w) => w.status === 'pending')
      .reduce((sum, w) => sum + w.amount, 0);
    const approvedWithdrawalsAmount = withdrawals
      .filter((w) => w.status === 'approved')
      .reduce((sum, w) => sum + w.amount, 0);

    const effectiveEarned = +(totalCommissions + milestoneRewards).toFixed(2);
    const availableWithdrawableBalance = Math.max(0, +(effectiveEarned - pendingWithdrawalsAmount - approvedWithdrawalsAmount).toFixed(2));
    const code = resolvedUser?.referralCode || `SPK-${norm.slice(2, 8).toUpperCase()}`;

    return {
      address: targetAddress,
      directPartners: Math.max(teamStats.directCount, allDirects.length),
      downlinePartners: teamStats.downlineCount,
      totalPartners: Math.max(teamStats.totalTeamCount, allDirects.length + teamStats.downlineCount),
      levelCounts: teamStats.levelCounts,
      totalCommissions: effectiveEarned,
      milestoneRewardsClaimed: +milestoneRewards.toFixed(2),
      withdrawals,
      pendingWithdrawalsAmount: +pendingWithdrawalsAmount.toFixed(2),
      approvedWithdrawalsAmount: +approvedWithdrawalsAmount.toFixed(2),
      totalWithdrawn: +approvedWithdrawalsAmount.toFixed(2),
      availableWithdrawableBalance,
      referrals: allDirects,
      referredBy: resolvedUser?.referredBy || null,
      referralCode: code,
      hashrateInfo,
    };
  }

  /**
   * Robust parser that extracts address and/or referral code from:
   * - Full URLs (e.g. https://spikenodes.com/ref/SPK-BC5D44?sponsor=0xbc5d... or http://localhost:3000/?ref=0x...)
   * - Short links (/ref/SPK-123456 or /r/SPK-123456)
   * - Query strings (?ref=... or ?referrer=... or ?sponsor=...)
   * - Direct 0x addresses (0x...)
   * - Short codes (SPK-XXXXXX, SPIKE-XXXXXX, or XXXXXX)
   */
  public extractReferralInput(input: string): { address?: string; code?: string; raw: string } {
    if (!input || typeof input !== 'string') return { raw: '' };
    const raw = input.trim();

    let extractedAddress: string | undefined = undefined;
    let extractedCode: string | undefined = undefined;

    // 1. Check if input contains a valid 40-hex (42 char with 0x) BSC/EVM address anywhere
    const addrMatch = raw.match(/0x[a-fA-F0-9]{40}/);
    if (addrMatch) {
      extractedAddress = addrMatch[0];
    }

    // 2. Check if input is a URL or path with /ref/... or /r/...
    const refPathMatch = raw.match(/\/(?:ref|r)\/([a-zA-Z0-9_\-]+)/i);
    if (refPathMatch && refPathMatch[1]) {
      const segment = refPathMatch[1].trim();
      if (/^0x[a-fA-F0-9]{40}$/i.test(segment)) {
        if (!extractedAddress) extractedAddress = segment;
      } else {
        extractedCode = segment;
      }
    }

    // 3. Check query parameters (?ref=..., ?referrer=..., ?sponsor=..., ?code=...)
    const queryParamMatch = raw.match(/[?&](?:ref|referrer|r|sponsor|code)=([^&#\s]+)/i);
    if (queryParamMatch && queryParamMatch[1]) {
      const paramVal = decodeURIComponent(queryParamMatch[1]).trim();
      if (/^0x[a-fA-F0-9]{40}$/i.test(paramVal)) {
        if (!extractedAddress) extractedAddress = paramVal;
      } else if (!extractedCode) {
        extractedCode = paramVal;
      }
    }

    // 4. Secondary sponsor param check (e.g. ?sponsor=0x... when ref is code)
    const sponsorParamMatch = raw.match(/[?&]sponsor=([^&#\s]+)/i);
    if (sponsorParamMatch && sponsorParamMatch[1]) {
      const sponsorVal = decodeURIComponent(sponsorParamMatch[1]).trim();
      if (/^0x[a-fA-F0-9]{40}$/i.test(sponsorVal)) {
        extractedAddress = sponsorVal;
      }
    }

    // 5. If neither address nor code found yet, clean and test
    if (!extractedAddress && !extractedCode) {
      const clean = raw.replace(/^https?:\/\/[^\/]+/i, '').replace(/^[/?#]+/, '').trim();
      if (/^0x[a-fA-F0-9]{40}$/i.test(clean)) {
        extractedAddress = clean;
      } else {
        extractedCode = clean;
      }
    }

    return { address: extractedAddress, code: extractedCode, raw };
  }

  public findUserByReferralCodeOrAddress(codeOrAddr: string): DbUser | undefined {
    if (!codeOrAddr) return undefined;
    const { address: parsedAddr, code: parsedCode } = this.extractReferralInput(codeOrAddr);

    // 1. If an exact 0x BSC wallet address was extracted or passed:
    if (parsedAddr && /^0x[a-fA-F0-9]{40}$/i.test(parsedAddr)) {
      const normAddr = parsedAddr.toLowerCase();
      let user = this.data.users.find((u) => u.address.toLowerCase() === normAddr);
      if (!user) {
        // Automatically upsert and register this sponsor wallet in the system
        user = this.upsertUser({
          address: parsedAddr,
          referralCode: `SPK-${parsedAddr.slice(2, 8).toUpperCase()}`,
        });
      }
      return user;
    }

    // 2. If a referral code was extracted or passed (e.g. SPK-BC5D44, BC5D44):
    const targetCode = (parsedCode || codeOrAddr).trim().toLowerCase();
    const rawCode = targetCode.replace(/^(spike-|spk-)/i, '').trim();

    if (rawCode) {
      // Find in existing users by referralCode, address slice, or address prefix
      let user = this.data.users.find((u) => {
        const uCode = (u.referralCode || '').toLowerCase();
        const uRawCode = uCode.replace(/^(spike-|spk-)/i, '');
        const uSlice = u.address.slice(2, 8).toLowerCase();
        return (
          uCode === targetCode ||
          uCode === `spk-${rawCode}` ||
          uRawCode === rawCode ||
          uSlice === rawCode ||
          u.address.toLowerCase().startsWith(`0x${rawCode}`)
        );
      });

      if (user) return user;

      // 3. Fallback for known protocol sponsors
      if (rawCode === '71c8a9' || targetCode === 'spk-71c8a9' || targetCode === 'spike-71c8a9') {
        return this.upsertUser({
          address: '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
          referralCode: 'SPK-71C8A9',
        });
      }

      if (rawCode === 'bc5d44' || targetCode === 'spk-bc5d44' || targetCode === 'spike-bc5d44') {
        return this.upsertUser({
          address: '0xbc5d4447cd615daac2338ce7b9c70eab18d78e21',
          referralCode: 'SPK-BC5D44',
        });
      }

      if (rawCode === '380696' || targetCode === 'spk-380696' || targetCode === 'spike-380696') {
        return this.upsertUser({
          address: '0x38069663d6408dff184bafc65e247e37ae84a1c2',
          referralCode: 'SPK-380696',
        });
      }

      if (rawCode === '38f2b7' || targetCode === 'spk-38f2b7') {
        return this.upsertUser({
          address: '0x38F2B78d9b8A6c0d87AeE9e6Fa2c5D551a89E239',
          referralCode: 'SPK-38F2B7',
        });
      }

      if (rawCode === '992b10' || targetCode === 'spk-992b10') {
        return this.upsertUser({
          address: '0x992B1048b6cF8F7d402E8eE755497B1A0a42Ce08',
          referralCode: 'SPK-992B10',
        });
      }

      // 4. Deterministic link for any 6-character hex code
      if (/^[a-f0-9]{6}$/i.test(rawCode)) {
        const hex = rawCode.toLowerCase();
        // Check if there is already a real user with this hex prefix or referral code
        const realUser = this.data.users.find(
          (u) =>
            u.address.toLowerCase().startsWith(`0x${hex}`) ||
            u.address.toLowerCase().includes(hex) ||
            (u.referralCode || '').toLowerCase().includes(hex)
        );
        if (realUser) return realUser;

        // Generate a clean deterministic valid 42-char checksummed BSC wallet address
        const suffix = '0000000000000000000000000000000000';
        const generatedAddr = `0x${hex}${suffix}`;
        return this.upsertUser({
          address: generatedAddr,
          referralCode: `SPK-${rawCode.toUpperCase()}`,
        });
      }
    }

    return undefined;
  }

  public registerReferral(
    referrerCodeOrAddr: string,
    refereeAddress: string
  ): { success: boolean; referrer?: DbUser; referee?: DbUser; referral?: DbReferral; message?: string } {
    if (!referrerCodeOrAddr || !refereeAddress) {
      return { success: false, message: 'Both referrer code/address and referee address are required' };
    }

    // Clean referee address
    const { address: cleanRefAddr } = this.extractReferralInput(refereeAddress);
    const finalRefereeAddr = cleanRefAddr || refereeAddress.trim();
    const normReferee = finalRefereeAddr.toLowerCase();

    let referee = this.getUser(normReferee);
    if (!referee) {
      referee = this.upsertUser({ address: finalRefereeAddr });
    }

    // Find referrer (supports URLs, 0x wallet address, AND SPK-XXXXXX referral code)
    let referrer = this.findUserByReferralCodeOrAddress(referrerCodeOrAddr);

    if (!referrer) {
      const { address: fallbackAddr } = this.extractReferralInput(referrerCodeOrAddr);
      if (fallbackAddr && /^0x[a-fA-F0-9]{40}$/i.test(fallbackAddr)) {
        referrer = this.upsertUser({ address: fallbackAddr });
      }
    }

    if (!referrer) {
      // Default fallback to protocol team sponsor
      referrer = this.upsertUser({
        address: '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
        referralCode: 'SPK-71C8A9',
      });
    }

    // Check if referrer code is the same wallet (cannot self-refer)
    if (referrer.address.toLowerCase() === referee.address.toLowerCase()) {
      return { success: false, message: 'Cannot refer your own wallet address' };
    }

    // Check if referral link already established
    const existing = this.data.referrals.find(
      (r) =>
        r.referrerAddress.toLowerCase() === referrer!.address.toLowerCase() &&
        r.refereeAddress.toLowerCase() === normReferee &&
        r.tier === 1
    );

    if (existing) {
      if (!referee.referredBy) {
        referee.referredBy = referrer.address;
        this.save();
      }
      return {
        success: true,
        referrer,
        referee,
        referral: existing,
        message: 'Referral connection already verified and active',
      };
    }

    // Bind sponsor
    referee.referredBy = referrer.address;
    this.save();

    // Create Team Partner record (counted towards Team Milestone Rewards)
    const newRef = this.createReferral({
      referrerAddress: referrer.address,
      refereeAddress: referee.address,
      tier: 1,
      commissionUsdt: 0,
      volumeUsdt: 150.0,
    });

    this.logAudit(
      'SYSTEM',
      'REFERRAL_REGISTER',
      `${referrer.address}->${referee.address}`,
      `Linked partner ${referee.address} to sponsor ${referrer.address} (Code: ${referrer.referralCode})`
    );

    return {
      success: true,
      referrer,
      referee,
      referral: newRef,
      message: 'Partner successfully linked to your team and counted toward milestones!',
    };
  }

  public createReferral(ref: Omit<DbReferral, 'id' | 'createdAt'>): DbReferral {
    const newRef: DbReferral = {
      ...ref,
      id: `ref-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
    };
    this.data.referrals.unshift(newRef);
    this.save();
    return newRef;
  }

  public simulateReferral(referrerAddress: string): { referral: DbReferral; commissionAdded: number } {
    let cleanRef = (referrerAddress || '').trim();
    const user = this.findUserByReferralCodeOrAddress(cleanRef);
    const finalReferrerAddr = user ? user.address : (cleanRef.startsWith('0x') ? cleanRef : '0x71C8a914B97e889F12A0987cB32456Fa12349A2');

    const chars = '0123456789abcdef';
    let randAddr = '0x';
    for (let i = 0; i < 40; i++) randAddr += chars[Math.floor(Math.random() * chars.length)];

    this.upsertUser({
      address: randAddr,
      referralCode: `SPK-${randAddr.slice(2, 8).toUpperCase()}`,
      referredBy: finalReferrerAddr,
    });

    const newRef = this.createReferral({
      referrerAddress: finalReferrerAddr,
      refereeAddress: randAddr,
      tier: 1,
      commissionUsdt: 0,
      volumeUsdt: 150.0,
    });

    this.save();
    return { referral: newRef, commissionAdded: 0 };
  }

  // ---- Withdrawal Requests (Milestone & Mining Rewards) ----
  public getWithdrawalRequests(userAddress?: string): DbWithdrawalRequest[] {
    if (!this.data.withdrawalRequests) {
      this.data.withdrawalRequests = [];
    }
    if (userAddress) {
      const norm = userAddress.toLowerCase();
      return this.data.withdrawalRequests.filter(
        (r) => r.userAddress.toLowerCase() === norm || r.destinationAddress.toLowerCase() === norm
      );
    }
    return this.data.withdrawalRequests;
  }

  public createWithdrawalRequest(req: {
    userAddress: string;
    destinationAddress: string;
    amount: number;
    source?: string;
    milestoneLabel?: string;
  }): { success: boolean; request?: DbWithdrawalRequest; error?: string } {
    if (!this.data.withdrawalRequests) {
      this.data.withdrawalRequests = [];
    }
    const cleanUser = req.userAddress.trim();
    const cleanDest = (req.destinationAddress || req.userAddress).trim();
    const amount = Number(req.amount);

    if (isNaN(amount) || amount <= 0) {
      return { success: false, error: 'Invalid withdrawal amount' };
    }

    const newReq: DbWithdrawalRequest = {
      id: `wdr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userAddress: cleanUser,
      destinationAddress: cleanDest,
      amount: +amount.toFixed(2),
      source: req.source || 'milestone_reward',
      milestoneLabel: req.milestoneLabel || 'Team Milestone Reward',
      status: 'pending',
      requestedAt: new Date().toISOString(),
    };

    this.data.withdrawalRequests.unshift(newReq);
    this.logAudit(
      'USER',
      'WITHDRAWAL_REQUEST',
      cleanUser,
      `Requested withdrawal of ${amount} USDT to ${cleanDest} (${newReq.milestoneLabel})`
    );
    this.save();
    return { success: true, request: newReq };
  }

  public approveWithdrawalRequest(
    id: string,
    txHash?: string,
    admin = 'Admin'
  ): { success: boolean; request?: DbWithdrawalRequest; remainingBalance?: number; user?: DbUser; error?: string } {
    if (!this.data.withdrawalRequests) {
      this.data.withdrawalRequests = [];
    }
    const req = this.data.withdrawalRequests.find((r) => r.id === id);
    if (!req) {
      return { success: false, error: 'Withdrawal request not found' };
    }
    if (req.status === 'approved') {
      return { success: false, error: 'Request is already approved' };
    }

    const finalTxHash = txHash || `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    req.status = 'approved';
    req.txHash = finalTxHash;
    req.reviewedAt = new Date().toISOString();
    req.reviewedBy = admin;

    // Deduct withdrawn amount from user balance in database
    const userNorm = req.userAddress.toLowerCase();
    const user = this.data.users.find((u) => u.address.toLowerCase() === userNorm);
    let remainingUserUsdt = 0;
    if (user) {
      user.balanceUsdt = Math.max(0, +(Number(user.balanceUsdt || 0) - req.amount).toFixed(2));
      user.lastActive = new Date().toISOString();
      remainingUserUsdt = user.balanceUsdt;
    }

    if (this.data.testnetWallets) {
      const tw = this.data.testnetWallets.find((w) => w.address.toLowerCase() === userNorm);
      if (tw) {
        tw.testnetUsdt = Math.max(0, +(Number(tw.testnetUsdt || 0) - req.amount).toFixed(2));
      }
    }

    // Record verified payout transaction in ledger
    this.createTransaction({
      userAddress: req.userAddress.toLowerCase(),
      txHash: finalTxHash,
      type: 'payout',
      amount: req.amount,
      currency: 'USDT',
      status: 'Confirmed',
      details: `Withdrawal Payout: Cleared & paid out $${req.amount.toFixed(2)} USDT to ${req.destinationAddress} (${req.milestoneLabel || 'Milestone Reward'}). User remaining balance: $${remainingUserUsdt.toFixed(2)} USDT.`,
      blockNumber: 42960000 + Math.floor(Math.random() * 15000),
    });

    this.logAudit(
      admin,
      'WITHDRAWAL_APPROVE',
      req.userAddress,
      `Approved withdrawal #${id} for ${req.amount} USDT. Payout Tx: ${finalTxHash}. Remaining balance: ${remainingUserUsdt} USDT`
    );
    this.save();
    return { success: true, request: req, remainingBalance: remainingUserUsdt, user };
  }

  public rejectWithdrawalRequest(
    id: string,
    reason?: string,
    admin = 'Admin'
  ): { success: boolean; request?: DbWithdrawalRequest; error?: string } {
    if (!this.data.withdrawalRequests) {
      this.data.withdrawalRequests = [];
    }
    const req = this.data.withdrawalRequests.find((r) => r.id === id);
    if (!req) {
      return { success: false, error: 'Withdrawal request not found' };
    }
    req.status = 'rejected';
    req.adminNote = reason || 'Admin review declined';
    req.reviewedAt = new Date().toISOString();
    req.reviewedBy = admin;

    this.logAudit(
      admin,
      'WITHDRAWAL_REJECT',
      req.userAddress,
      `Rejected withdrawal #${id}. Reason: ${req.adminNote}`
    );
    this.save();
    return { success: true, request: req };
  }

  // ---- Announcements ----
  public getAnnouncements(): DbAnnouncement[] {
    return this.data.announcements;
  }

  public createAnnouncement(ann: Omit<DbAnnouncement, 'id' | 'createdAt'>, admin = 'admin'): DbAnnouncement {
    const newAnn: DbAnnouncement = {
      ...ann,
      id: `ann-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.data.announcements.unshift(newAnn);
    this.logAudit(admin, 'ANNOUNCEMENT_CREATE', newAnn.id, `Created broadcast "${newAnn.title}"`);
    this.save();
    return newAnn;
  }

  public deleteAnnouncement(id: string, admin = 'admin'): boolean {
    const initialLen = this.data.announcements.length;
    this.data.announcements = this.data.announcements.filter((a) => a.id !== id);
    const removed = this.data.announcements.length < initialLen;
    if (removed) {
      this.logAudit(admin, 'ANNOUNCEMENT_DELETE', id, `Removed broadcast announcement`);
      this.save();
    }
    return removed;
  }

  // ---- Settings ----
  public getSettings(): DbSettings {
    return this.data.settings;
  }

  public updateSettings(partial: Partial<DbSettings>, admin = 'admin'): DbSettings {
    this.data.settings = {
      ...this.data.settings,
      ...partial,
      updatedAt: new Date().toISOString(),
    };
    this.logAudit(admin, 'SETTINGS_UPDATE', 'system_config', JSON.stringify(partial));
    this.save();
    return this.data.settings;
  }

  // ---- Audit Logs ----
  public getAuditLogs(limit = 100): DbAuditLog[] {
    return this.data.auditLogs.slice(0, limit);
  }

  public logAudit(adminUser: string, action: string, target: string, details: string) {
    const log: DbAuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      adminUser,
      action,
      target,
      details,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(log);
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 500);
    }
    this.save();
  }

  // ---- DB Maintenance & Export ----
  public resetToDefault(admin = 'admin') {
    return this.resetMainnetBaseline(admin);
  }

  public resetMainnetBaseline(admin = 'Master User') {
    this.data = {
      version: 1,
      lastSaved: new Date().toISOString(),
      users: [
        {
          address: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
          balanceUsdt: 0.0,
          balanceBnb: 0.0,
          totalMined: 0.0,
          balanceSpk: 0.0,
          referralCode: 'SPK-3471E0',
          referredBy: null,
          role: 'master',
          status: 'active',
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
          notes: 'Master Creator & Protocol Root Authority',
        },
      ],
      nodes: [],
      transactions: [],
      referrals: [],
      announcements: [],
      withdrawalRequests: [],
      settings: {
        turboMultiplier: 10,
        dailyYieldPercent: 3.88,
        baseHashrateTh: 1.25,
        miningCycleHours: 24,
        dailyRewardSpk: 35.0,
        minDepositUsdt: 5.0,
        pancakeRouterAddress: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
        pancakePairAddress: '0xdB75fAB72e56492CFE870344D115C57047992F3c',
        testnetFastCycleEnabled: false,
        maintenanceMode: false,
        stratumPoolUrl: 'stratum+tcp://pool.spikenodes.com:443',
        bscContractAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
        treasuryWalletAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
        treasuryBalanceUsdt: 0.0,
        minWithdrawalUsdt: 5.0,
        autoPayoutEnabled: true,
        updatedAt: new Date().toISOString(),
        primaryDomain: 'spikenodes.com',
        protocolUrl: 'https://spikenodes.com',
        apiBaseUrl: 'https://spikenodes.com/api',
        docsUrl: 'https://docs.spikenodes.com',
        rpcUrl: 'https://bsc-dataseed.binance.org/',
        telegramUrl: 'https://t.me/spikenodes',
        twitterUrl: 'https://x.com/spikenodes',
        supportEmail: 'contact@spikenodes.com',
        masterWalletAddresses: [
          '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
        ],
        maintenanceMessage: 'Spike Stratum Protocol is currently undergoing scheduled network maintenance.',
        nodeCostUsdt: 15.0,
        tier1CommissionPercent: 15,
        tier2CommissionPercent: 5,
        level1DirectsRequired: 10,
        level2DirectsRequired: 25,
        level3DirectsRequired: 50,
        level1HashrateBoost: 200,
        level2HashrateBoost: 400,
        level3HashrateBoost: 600,
      },
      auditLogs: [
        {
          id: `audit-${Date.now()}`,
          adminUser: admin,
          action: 'MAINNET_FRESH_RESET',
          target: 'spike_database',
          details: 'Database completely reset to clean mainnet baseline: 0.0 Treasury USDT, 0 SPIKE balance, clean nodes and transactions.',
          timestamp: new Date().toISOString(),
        },
      ],
      testnetWallets: [],
      testnetTransactions: [],
      testnetSpikeToken: {
        name: 'Spike Mining Protocol',
        symbol: 'SPK',
        totalSupply: 50000000,
        circulatingSupply: 0,
        decimals: 18,
        contractAddress: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
        pair: 'SPK/USDT',
        poolSpkReserve: 10000000,
        poolUsdtReserve: 345000,
        currentPrice: 1.12,
        volume24h: 0,
        high24h: 1.20,
        low24h: 1.00,
        change24h: 0,
        buyPressure: 50,
      },
    };
    this.saveDirect(this.data);
    return {
      success: true,
      message: 'Database completely reset to clean Mainnet baseline (Treasury: $0.00 USDT, User Balances: 0 SPK / 0 USDT, Fleet: 0 rigs)',
      database: this.data,
    };
  }

  public exportData(): DatabaseSchema {
    return this.data;
  }

  public purgeNonMasterData(customMasters?: string[]): {
    success: boolean;
    remainingUsers: number;
    removedUsers: number;
    removedNodes: number;
    removedReferrals: number;
    removedTransactions: number;
  } {
    const masters = (customMasters && customMasters.length > 0)
      ? customMasters
      : [
          '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
          '0x71C8a914B97e889F12A0987cB32456Fa12349A2',
        ];
    const masterLower = masters.map((m) => m.toLowerCase().trim());

    const initialUserCount = this.data.users.length;
    const initialNodeCount = this.data.nodes.length;
    const initialRefCount = this.data.referrals.length;
    const initialTxCount = this.data.transactions.length;

    // Filter users: keep only master addresses
    this.data.users = this.data.users.filter((u) => masterLower.includes(u.address.toLowerCase().trim()));

    // If master doesn't exist, create default master
    if (this.data.users.length === 0) {
      this.data.users.push({
        address: '0x3471e07c4d2f7e11c155760a7b386e616b5c3715',
        balanceUsdt: 0.0,
        balanceBnb: 0.0,
        totalMined: 0.0,
        balanceSpk: 0.0,
        referralCode: 'SPK-3471E0',
        referredBy: null,
        role: 'master',
        status: 'active',
        createdAt: new Date().toISOString(),
        lastActive: new Date().toISOString(),
        notes: 'Master Creator & Protocol Root Authority',
      });
    }

    // Filter nodes: keep only master nodes
    this.data.nodes = this.data.nodes.filter((n) => masterLower.includes(n.userAddress.toLowerCase().trim()));

    // Filter referrals: keep only referrals where both referrer and referee are valid remaining users
    const validUserAddrs = new Set(this.data.users.map((u) => u.address.toLowerCase().trim()));
    this.data.referrals = this.data.referrals.filter(
      (r) => validUserAddrs.has(r.referrerAddress.toLowerCase().trim()) && validUserAddrs.has(r.refereeAddress.toLowerCase().trim())
    );

    // Filter transactions: keep only master transactions
    this.data.transactions = this.data.transactions.filter((t) => t.userAddress && masterLower.includes(t.userAddress.toLowerCase().trim()));

    // Filter testnet wallets and txs
    this.data.testnetWallets = (this.data.testnetWallets || []).filter((w) => masterLower.includes(w.address.toLowerCase().trim()));
    this.data.testnetTransactions = (this.data.testnetTransactions || []).filter((t) => masterLower.includes(t.userAddress.toLowerCase().trim()));
    this.data.withdrawalRequests = (this.data.withdrawalRequests || []).filter((w) => masterLower.includes(w.userAddress.toLowerCase().trim()));

    this.logAudit(
      'System Admin',
      'PURGE_NON_MASTER_DATA',
      'All Non-Master Addresses',
      `Purged ${initialUserCount - this.data.users.length} users, ${initialNodeCount - this.data.nodes.length} nodes, ${initialRefCount - this.data.referrals.length} referrals.`
    );

    this.save();
    return {
      success: true,
      remainingUsers: this.data.users.length,
      removedUsers: initialUserCount - this.data.users.length,
      removedNodes: initialNodeCount - this.data.nodes.length,
      removedReferrals: initialRefCount - this.data.referrals.length,
      removedTransactions: initialTxCount - this.data.transactions.length,
    };
  }

  // ---- Testnet SPIKE Token & Auto-Buy Engine ----
  public getTestnetSpikeToken(): DbTestnetSpikeToken {
    if (!this.data.testnetSpikeToken) {
      this.data.testnetSpikeToken = { ...INITIAL_DATA.testnetSpikeToken };
      this.save();
    }
    return this.data.testnetSpikeToken;
  }

  public getTestnetWallet(address: string): DbTestnetWallet {
    if (!this.data.testnetWallets) {
      this.data.testnetWallets = [];
    }
    const norm = (address || '').toLowerCase();
    let wallet = this.data.testnetWallets.find((w) => w.address.toLowerCase() === norm);
    if (!wallet) {
      wallet = {
        address: address || '0xDemoWallet...User',
        testnetUsdt: 1000.0,
        testnetSpk: 0.0,
        autoBuyEnabled: true,
        slippageTolerance: 0.5,
        totalHarvestAutoBoughtSpk: 0.0,
        totalUsdtSpentOnAutoBuy: 0.0,
      };
      this.data.testnetWallets.push(wallet);
      this.save();
    }
    return wallet;
  }

  public updateTestnetWalletSettings(
    address: string,
    autoBuyEnabled: boolean,
    slippageTolerance: number
  ): DbTestnetWallet {
    const wallet = this.getTestnetWallet(address);
    wallet.autoBuyEnabled = autoBuyEnabled;
    wallet.slippageTolerance = Number(slippageTolerance) || 0.5;
    this.save();
    return wallet;
  }

  public topupTestnetWallet(
    address: string,
    usdtAmount = 500,
    spkAmount = 100
  ): { wallet: DbTestnetWallet; tx: DbTestnetTx } {
    const wallet = this.getTestnetWallet(address);
    wallet.testnetUsdt += Number(usdtAmount);
    wallet.testnetSpk += Number(spkAmount);

    const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    const token = this.getTestnetSpikeToken();
    const newTx: DbTestnetTx = {
      id: `test-tx-${Date.now()}`,
      userAddress: wallet.address,
      txHash,
      type: 'faucet',
      spkAmount: Number(spkAmount),
      usdtAmount: Number(usdtAmount),
      priceUsdt: token.currentPrice,
      status: 'Confirmed',
      blockNumber: 42918400 + Math.floor(Math.random() * 5000),
      gasFeeBnb: 0.0,
      details: `Testnet Faucet Top-up: +${usdtAmount} tUSDT & +${spkAmount} SPK`,
      timestamp: new Date().toISOString(),
    };

    if (!this.data.testnetTransactions) {
      this.data.testnetTransactions = [];
    }
    this.data.testnetTransactions.unshift(newTx);
    this.save();
    return { wallet, tx: newTx };
  }

  public executeTestnetHarvestAutoBuy(
    address: string,
    minedSpkAmount: number,
    hashrate: number,
    slippageTolerance = 0.2,
    customTxHash?: string
  ): {
    success: boolean;
    wallet: DbTestnetWallet;
    token: DbTestnetSpikeToken;
    tx: DbTestnetTx;
    route?: string[];
    routerAddress?: string;
    pairAddress?: string;
    slippageUsed?: number;
    error?: string;
  } {
    const wallet = this.getTestnetWallet(address);
    const token = this.getTestnetSpikeToken();
    const exactMinedSpk = Number(minedSpkAmount) > 0 ? Number(minedSpkAmount) : (this.data.settings.dailyRewardSpk || 25.0);

    // Dynamic AMM calculation on PancakeSwap v3 / v2 pool
    const poolSpk = token.poolSpkReserve;
    const poolUsdt = token.poolUsdtReserve;
    const numerator = poolUsdt * exactMinedSpk;
    const denominator = Math.max(1, (poolSpk - exactMinedSpk) * 0.9975);
    const baseRequiredUsdt = Number((numerator / denominator).toFixed(5));

    // Best slippage buffer (0.2% optimal slippage for ultra-fast confirmation)
    const effectiveSlippage = Number(slippageTolerance) > 0 ? Number(slippageTolerance) : 0.2;
    const maxUsdtWithSlippage = Number((baseRequiredUsdt * (1 + effectiveSlippage / 100)).toFixed(5));
    const requiredUsdt = baseRequiredUsdt;

    // If user's testnet USDT is insufficient, top up automatically so testing is effortless
    if (wallet.testnetUsdt < requiredUsdt) {
      wallet.testnetUsdt += 1000.0;
    }

    // Execute PancakeSwap Router swap: Deduct USDT, Credit exact mined SPK
    wallet.testnetUsdt = Math.max(0, Number((wallet.testnetUsdt - requiredUsdt).toFixed(4)));
    wallet.testnetSpk = Number((wallet.testnetSpk + exactMinedSpk).toFixed(5));
    wallet.totalHarvestAutoBoughtSpk = Number((wallet.totalHarvestAutoBoughtSpk + exactMinedSpk).toFixed(5));
    wallet.totalUsdtSpentOnAutoBuy = Number((wallet.totalUsdtSpentOnAutoBuy + requiredUsdt).toFixed(4));
    wallet.lastAutoBuyAt = new Date().toISOString();

    // Also update persistent user record if exists
    if (address) {
      const norm = address.toLowerCase();
      const existingUser = this.data.users.find((u) => u.address.toLowerCase() === norm);
      if (existingUser) {
        existingUser.totalMined = Number((existingUser.totalMined + exactMinedSpk).toFixed(5));
        existingUser.balanceSpk = Number(((existingUser.balanceSpk || 0) + exactMinedSpk).toFixed(5));
        existingUser.miningCycleStartTime = Date.now();
        existingUser.lastActive = new Date().toISOString();
      }
    }

    // Update AMM liquidity pool reserves & live price
    token.poolSpkReserve = Math.max(100000, token.poolSpkReserve - exactMinedSpk);
    token.poolUsdtReserve = token.poolUsdtReserve + requiredUsdt;
    const newPrice = Number((token.poolUsdtReserve / token.poolSpkReserve).toFixed(6));
    token.currentPrice = newPrice;
    token.volume24h = Number((token.volume24h + exactMinedSpk).toFixed(2));
    token.high24h = Math.max(token.high24h || 0.0368, newPrice);
    token.change24h = Number((token.change24h + 0.18).toFixed(2));
    token.buyPressure = Math.min(96, Number((token.buyPressure + 0.25).toFixed(1)));

    const txHash = customTxHash || `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    const blockNumber = 42918500 + (this.data.testnetTransactions?.length || 0);

    const tx: DbTestnetTx = {
      id: `test-tx-${Date.now()}`,
      userAddress: wallet.address,
      txHash,
      type: 'harvest_autobuy',
      spkAmount: exactMinedSpk,
      usdtAmount: requiredUsdt,
      priceUsdt: newPrice,
      status: 'Confirmed',
      blockNumber,
      gasFeeBnb: 0.00015,
      details: `PancakeRouter.exactInputSingle(amountOut=${exactMinedSpk.toFixed(5)} SPK, usdtIn=${requiredUsdt.toFixed(5)} USDT, pool=0xdB75fAB72e56492CFE870344D115C57047992F3c, router=${this.data.settings.pancakeRouterAddress || '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4'}) [Rate: $${newPrice} USDT/SPK | Hashrate: ${hashrate.toFixed(2)} TH/s]`,
      timestamp: new Date().toISOString(),
    };

    if (!this.data.testnetTransactions) {
      this.data.testnetTransactions = [];
    }
    this.data.testnetTransactions.unshift(tx);
    this.save();

    return {
      success: true,
      wallet,
      token,
      tx,
      route: ['USDT', 'SPK'],
      routerAddress: this.data.settings.pancakeRouterAddress || '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4',
      pairAddress: this.data.settings.pancakePairAddress || '0xdB75fAB72e56492CFE870344D115C57047992F3c',
    };
  }

  public executeTestnetSwap(
    address: string,
    fromToken: 'USDT' | 'SPK',
    toToken: 'USDT' | 'SPK',
    amountIn: number
  ): { success: boolean; wallet: DbTestnetWallet; token: DbTestnetSpikeToken; tx: DbTestnetTx; error?: string } {
    const wallet = this.getTestnetWallet(address);
    const token = this.getTestnetSpikeToken();
    const numIn = Number(amountIn) || 0;

    if (numIn <= 0) {
      return { success: false, wallet, token, tx: null as any, error: 'Amount must be greater than 0' };
    }

    if (fromToken === 'USDT') {
      if (wallet.testnetUsdt < numIn) {
        return { success: false, wallet, token, tx: null as any, error: 'Insufficient testnet USDT balance' };
      }
      const amountInWithFee = numIn * 0.9975;
      const amountOut = Number(((token.poolSpkReserve * amountInWithFee) / (token.poolUsdtReserve + amountInWithFee)).toFixed(4));
      
      wallet.testnetUsdt -= numIn;
      wallet.testnetSpk += amountOut;

      token.poolUsdtReserve += numIn;
      token.poolSpkReserve -= amountOut;
      token.currentPrice = Number((token.poolUsdtReserve / token.poolSpkReserve).toFixed(6));
      token.volume24h += amountOut;
      token.buyPressure = Math.min(95, token.buyPressure + 0.1);

      if (address) {
        const norm = address.toLowerCase();
        const existingUser = this.data.users.find((u) => u.address.toLowerCase() === norm);
        if (existingUser) {
          existingUser.balanceUsdt = Math.max(0, Number(((existingUser.balanceUsdt || 0) - numIn).toFixed(2)));
          existingUser.balanceSpk = Number(((existingUser.balanceSpk || 0) + amountOut).toFixed(4));
          existingUser.lastActive = new Date().toISOString();
        }
      }

      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const tx: DbTestnetTx = {
        id: `test-tx-${Date.now()}`,
        userAddress: wallet.address,
        txHash,
        type: 'swap_buy',
        spkAmount: amountOut,
        usdtAmount: numIn,
        priceUsdt: token.currentPrice,
        status: 'Confirmed',
        blockNumber: 42918500 + (this.data.testnetTransactions?.length || 0),
        gasFeeBnb: 0.00015,
        details: `Swap ${numIn} USDT -> ${amountOut} SPK on PancakeSwap Pool (0xdB75fAB72e56492CFE870344D115C57047992F3c) via Router (${this.data.settings.pancakeRouterAddress || '0x10ED43C718714eb63d5aA57B78B54704E256024E'})`,
        timestamp: new Date().toISOString(),
      };

      if (!this.data.testnetTransactions) this.data.testnetTransactions = [];
      this.data.testnetTransactions.unshift(tx);
      this.save();
      return { success: true, wallet, token, tx };
    } else {
      // Selling SPK for USDT: ENFORCE 10% MAX SELL LIMIT WITH FLOAT TOLERANCE
      const norm = (address || '').toLowerCase();
      const existingUser = this.data.users.find((u) => u.address.toLowerCase() === norm);
      
      // Auto-sync wallet balance with user record if present
      if (existingUser && typeof existingUser.balanceSpk === 'number' && existingUser.balanceSpk > wallet.testnetSpk) {
        wallet.testnetSpk = existingUser.balanceSpk;
      }
      
      const effectiveSpkBal = Math.max(wallet.testnetSpk, existingUser?.balanceSpk || 0, existingUser?.totalMined || 0);
      const maxAllowedSell = +(effectiveSpkBal * 0.10).toFixed(4);
      
      // Allow a small decimal tolerance (0.001) or minimum 0.1 SPK for small test balances
      if (effectiveSpkBal > 0 && numIn > maxAllowedSell + 0.005 && numIn > 0.10) {
        return {
          success: false,
          wallet,
          token,
          tx: null as any,
          error: `10% Max Daily Sell Limit: You can only sell up to ${maxAllowedSell} SPK (10% of your ${effectiveSpkBal.toFixed(2)} SPK balance) at this time.`,
        };
      }

      // If wallet is lower than user profile balance, sync it
      if (wallet.testnetSpk < numIn && effectiveSpkBal >= numIn) {
        wallet.testnetSpk = effectiveSpkBal;
      }

      if (wallet.testnetSpk < numIn && effectiveSpkBal < numIn) {
        // Auto-provision balance for seamless testing if zero
        wallet.testnetSpk = Math.max(numIn, 10.0);
      }

      const amountInWithFee = numIn * 0.9975;
      // Fixed guaranteed rate of 1.12 USDT per SPIKE or pool formula
      const guaranteedRate = 1.12;
      const amountOut = Number((numIn * guaranteedRate).toFixed(4));

      wallet.testnetSpk = Math.max(0, Number((wallet.testnetSpk - numIn).toFixed(4)));
      wallet.testnetUsdt = Number((wallet.testnetUsdt + amountOut).toFixed(2));

      token.poolSpkReserve += numIn;
      token.poolUsdtReserve = Math.max(100, token.poolUsdtReserve - amountOut);
      token.currentPrice = guaranteedRate;
      token.volume24h += numIn;
      token.buyPressure = Math.max(70, token.buyPressure - 0.2);

      if (existingUser) {
        existingUser.balanceSpk = Math.max(0, Number(((existingUser.balanceSpk || 0) - numIn).toFixed(4)));
        existingUser.balanceUsdt = Number(((existingUser.balanceUsdt || 0) + amountOut).toFixed(2));
        existingUser.lastActive = new Date().toISOString();
      }

      const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      const tx: DbTestnetTx = {
        id: `test-tx-${Date.now()}`,
        userAddress: wallet.address,
        txHash,
        type: 'swap_sell',
        spkAmount: numIn,
        usdtAmount: amountOut,
        priceUsdt: guaranteedRate,
        status: 'Confirmed',
        blockNumber: 42918500 + (this.data.testnetTransactions?.length || 0),
        gasFeeBnb: 0.00015,
        details: `Swap ${numIn} SPK -> ${amountOut} USDT on PancakeSwap Pool (0xdB75fAB72e56492CFE870344D115C57047992F3c) via Smart Router (${this.data.settings.pancakeRouterAddress || '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4'})`,
        timestamp: new Date().toISOString(),
      };

      if (!this.data.testnetTransactions) this.data.testnetTransactions = [];
      this.data.testnetTransactions.unshift(tx);
      this.save();
      return { success: true, wallet, token, tx };
    }
  }

  public getTestnetTransactions(address?: string, limit = 50): DbTestnetTx[] {
    const all = this.data.testnetTransactions || [];
    if (!address) return all.slice(0, limit);
    const norm = address.toLowerCase();
    return all.filter((t) => t.userAddress.toLowerCase() === norm).slice(0, limit);
  }

  public getTreasuryInfo() {
    return {
      treasuryWalletAddress: this.data.settings.treasuryWalletAddress || '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7',
      treasuryBalanceUsdt: typeof this.data.settings.treasuryBalanceUsdt === 'number' ? this.data.settings.treasuryBalanceUsdt : 0.0,
      depositRequiredUsdt: 5.0,
      miningCostUsdt: 10.0,
      totalProjectCostUsdt: 15.0,
      network: 'BNB Smart Chain (BEP-20)',
      contractAddress: this.data.settings.bscContractAddress,
      lastUpdated: new Date().toISOString(),
    };
  }

  public updateTreasuryBalance(newBalance: number): number {
    this.data.settings.treasuryBalanceUsdt = +Number(newBalance).toFixed(2);
    this.data.settings.updatedAt = new Date().toISOString();
    this.save();
    return this.data.settings.treasuryBalanceUsdt;
  }

  public updateTreasuryAddress(newAddress: string, adminUser = 'admin'): { success: boolean; treasuryWalletAddress: string; error?: string } {
    if (!newAddress || typeof newAddress !== 'string') {
      return { success: false, treasuryWalletAddress: this.data.settings.treasuryWalletAddress, error: 'Address string is required' };
    }
    const clean = newAddress.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(clean)) {
      return { success: false, treasuryWalletAddress: this.data.settings.treasuryWalletAddress, error: 'Invalid EVM/BEP-20 address format. Must be 42 characters starting with 0x.' };
    }
    const oldAddress = this.data.settings.treasuryWalletAddress;
    this.data.settings.treasuryWalletAddress = clean;
    this.data.settings.updatedAt = new Date().toISOString();
    this.logAudit(adminUser, 'TREASURY_ADDRESS_UPDATED', clean, `Official Treasury address changed from ${oldAddress} to ${clean}`);
    this.save();
    return { success: true, treasuryWalletAddress: clean };
  }

  public processTreasuryDeposit(
    userAddress: string,
    amount = 5.0,
    txHash?: string
  ): {
    success: boolean;
    treasuryBalanceUsdt: number;
    remainingUserUsdt: number;
    txHash: string;
    user?: DbUser;
    node?: DbMiningNode;
    error?: string;
  } {
    if (!userAddress) {
      return { success: false, treasuryBalanceUsdt: 0, remainingUserUsdt: 0, txHash: '', error: 'User address is required' };
    }
    const norm = userAddress.toLowerCase();
    const user = this.upsertUser({ address: norm });
    const officialWallet = this.data.settings.treasuryWalletAddress || '0x3471e07c4d2f7e11c155760a7b386e616b5c3715';
    
    // Accumulate in Global Treasury
    const currentTreasury = typeof this.data.settings.treasuryBalanceUsdt === 'number' ? this.data.settings.treasuryBalanceUsdt : 0.0;
    this.data.settings.treasuryBalanceUsdt = +( currentTreasury + amount ).toFixed(2);
    
    // Deduct $5 from user's starting budget ($15 -> $10 remaining)
    if (user.balanceUsdt >= amount) {
      user.balanceUsdt = +(user.balanceUsdt - amount).toFixed(2);
    } else {
      user.balanceUsdt = 10.0; // default remainder for 15$ project flow
    }
    user.hasDepositedTreasury = true;
    user.hasActivatedMining = true;
    if (!user.miningCycleStartTime) {
      user.miningCycleStartTime = Date.now();
    }
    user.lastActive = new Date().toISOString();

    // Automatically provision and activate Mining Node upon $5 deposit
    const userNodes = this.data.nodes.filter((n) => n.userAddress.toLowerCase() === norm);
    let activeNode = userNodes.find((n) => n.status === 'mining');
    if (!activeNode) {
      activeNode = {
        id: `node-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        userAddress: norm,
        name: `SPIKE ASIC Rig #${userNodes.length + 1}`,
        region: 'US-East (Stratum Cluster)',
        status: 'mining',
        hashrate: this.data.settings.baseHashrateTh || 1.25,
        temperature: 64,
        shareAcceptance: 99.98,
        fanSpeed: 75,
        powerUsage: 1400,
        uptimeDays: 1,
        algorithm: 'SHA-256 (Stratum)',
        logs: [
          `Deposit of $${amount.toFixed(2)} USDT verified in Protocol Treasury`,
          `Connected to BSC stratum pool: ${this.data.settings.stratumPoolUrl}`,
          `24-Hour Mining Cycle Active · Automated PancakeSwap Buyback Enabled`,
        ],
        costUsdt: amount,
        deployedAt: new Date().toISOString(),
      };
      this.data.nodes.unshift(activeNode);
    }

    const cleanHash = txHash || `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    this.createTransaction({
      userAddress: norm,
      txHash: cleanHash,
      type: 'deposit',
      amount,
      currency: 'USDT',
      status: 'Confirmed',
      details: `Protocol Entry Fee ($${amount.toFixed(2)} USDT) deposited into Official Protocol Treasury (${officialWallet}). Remaining: $${user.balanceUsdt.toFixed(2)} USDT.`,
      blockNumber: 42950000 + Math.floor(Math.random() * 25000),
    });

    this.logAudit(norm, 'TREASURY_DEPOSIT', officialWallet, `Deposited $${amount} USDT to Treasury. Remaining balance: $${user.balanceUsdt}`);
    this.save();

    return {
      success: true,
      treasuryBalanceUsdt: this.data.settings.treasuryBalanceUsdt,
      remainingUserUsdt: user.balanceUsdt,
      txHash: cleanHash,
      user,
      node: activeNode,
    };
  }

  public executeMiningActivation(
    userAddress: string,
    nodeName?: string,
    costUsdt = 10.0
  ): {
    success: boolean;
    node?: DbMiningNode;
    boughtSpk?: number;
    spkPrice?: number;
    remainingUsdt?: number;
    swapTxHash?: string;
    contractTxHash?: string;
    treasuryBalanceUsdt?: number;
    treasuryWalletAddress?: string;
    error?: string;
  } {
    if (!userAddress) {
      return { success: false, error: 'User address is required' };
    }
    const norm = userAddress.toLowerCase();
    const user = this.upsertUser({ address: norm });
    const wallet = this.getTestnetWallet(norm);
    const token = this.getTestnetSpikeToken();

    // Check user has the $10 USDT
    if (user.balanceUsdt < costUsdt && wallet.testnetUsdt < costUsdt) {
      return { success: false, error: `Insufficient balance: $${costUsdt} USDT required for Smart Contract Mining Activation.` };
    }

    // Deduct 10 USDT from user
    user.balanceUsdt = Math.max(0, +(user.balanceUsdt - costUsdt).toFixed(2));
    user.hasActivatedMining = true;
    if (!user.miningCycleStartTime) {
      user.miningCycleStartTime = Date.now();
    }
    user.lastActive = new Date().toISOString();

    // CREDIT TREASURY WALLET WITH 10 USDT (Treasury address: 0x3471e07c4d2f7e11c155760a7b386e616b5c3715)
    const currentTreasury = typeof this.data.settings.treasuryBalanceUsdt === 'number' ? this.data.settings.treasuryBalanceUsdt : 0.0;
    this.data.settings.treasuryBalanceUsdt = +(currentTreasury + costUsdt).toFixed(2);

    // BACKEND SMART WORK: Execute PancakeSwap buy route with the $10 USDT
    const amountInWithFee = costUsdt * 0.9975;
    const amountOutSpk = Number(((token.poolSpkReserve * amountInWithFee) / (token.poolUsdtReserve + amountInWithFee)).toFixed(4));

    // Update pool reserves and token price
    token.poolUsdtReserve += costUsdt;
    token.poolSpkReserve -= amountOutSpk;
    token.currentPrice = Number((token.poolUsdtReserve / token.poolSpkReserve).toFixed(6));
    token.volume24h += amountOutSpk;
    token.buyPressure = Math.min(98, token.buyPressure + 0.3);

    // Credit purchased SPIKE tokens to user testnet/SPIKE balance
    wallet.testnetSpk = +(wallet.testnetSpk + amountOutSpk).toFixed(4);
    wallet.totalHarvestAutoBoughtSpk = +(wallet.totalHarvestAutoBoughtSpk + amountOutSpk).toFixed(4);
    wallet.totalUsdtSpentOnAutoBuy = +(wallet.totalUsdtSpentOnAutoBuy + costUsdt).toFixed(2);
    wallet.lastAutoBuyAt = new Date().toISOString();

    // Create PancakeSwap Buy Transaction Receipt
    const swapTxHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    const swapTx: DbTestnetTx = {
      id: `test-tx-${Date.now()}`,
      userAddress: norm,
      txHash: swapTxHash,
      type: 'swap_buy',
      spkAmount: amountOutSpk,
      usdtAmount: costUsdt,
      priceUsdt: token.currentPrice,
      status: 'Confirmed',
      blockNumber: 42918600 + (this.data.testnetTransactions?.length || 0),
      gasFeeBnb: 0.00015,
      details: `PancakeRouter.swapExactTokensForTokens(${costUsdt} USDT -> ${amountOutSpk} SPK) [Mining Backend Auto-Buy Execution]`,
      timestamp: new Date().toISOString(),
    };
    if (!this.data.testnetTransactions) this.data.testnetTransactions = [];
    this.data.testnetTransactions.unshift(swapTx);

    // Create Mining Node (Frontend views as active mining rig!)
    const rigName = nodeName || `Falcon Titan Apex Rig #${(this.getNodes(norm).length + 1).toString().padStart(2, '0')}`;
    const newNode = this.createNode({
      userAddress: norm,
      name: rigName,
      region: 'Frankfurt (EU-Central BSC Pool)',
      status: 'mining',
      hashrate: 100,
      temperature: 63,
      shareAcceptance: 99.95,
      fanSpeed: 74,
      powerUsage: 3180,
      uptimeDays: 0.1,
      algorithm: 'SHA-256 (BSC Validator Sublayer)',
      logs: [
        `[${new Date().toLocaleTimeString()}] Smart Contract Call executed: Mining node provisioned for 10 USDT.`,
        `[${new Date().toLocaleTimeString()}] Backend executed PancakeSwap V2 Buy Route: +${amountOutSpk.toFixed(2)} SPK purchased & credited!`,
        `[${new Date().toLocaleTimeString()}] Stratum target diff accepted: 100 VH/s active engine (1 SPK / 60 Days)`,
      ],
      costUsdt,
    });

    // Record on-chain mining contract transaction
    const contractTxHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    this.createTransaction({
      userAddress: norm,
      txHash: contractTxHash,
      type: 'activation',
      amount: costUsdt,
      currency: 'USDT',
      status: 'Confirmed',
      details: `Smart Contract Call: Mining Node Activation (${rigName}). Backend executed PancakeSwap Buy Route for +${amountOutSpk.toFixed(2)} SPK.`,
      blockNumber: 42918600 + Math.floor(Math.random() * 1000),
    });

    this.logAudit(norm, 'MINING_ACTIVATED', newNode.id, `Smart Contract Call: Mining started with $10 USDT. Backend bought ${amountOutSpk.toFixed(2)} SPK.`);
    this.save();

    return {
      success: true,
      node: newNode,
      boughtSpk: amountOutSpk,
      spkPrice: token.currentPrice,
      remainingUsdt: user.balanceUsdt,
      treasuryBalanceUsdt: this.data.settings.treasuryBalanceUsdt,
      treasuryWalletAddress: this.data.settings.treasuryWalletAddress || '0xDE7BfCaDE6F9BcC411aC67D970A4618054B8a4c7',
      swapTxHash,
      contractTxHash,
    };
  }
}

export const db = new PersistentDatabase();
