import { doc, setDoc, getDocs, collection, query, where } from 'firebase/firestore';
import { db } from '../firebase';

export interface FirestoreReferralRecord {
  id: string;
  referrerAddress: string;
  refereeAddress: string;
  tier: number;
  referralCode?: string;
  timestamp?: string;
}

export const MASTER_WALLET = '0x3471e07c4d2f7e11c155760a7b386e616b5c3715'.toLowerCase();

export const BASELINE_MASTER_DIRECTS = [
  { refereeAddress: '0xaaaa111122223333444455556666777788889999', timestamp: '2026-10-17T07:35:13.134Z' },
  { refereeAddress: '0xbbbb222233334444555566667777888899990000', timestamp: '2026-10-17T07:43:22.822Z' },
  { refereeAddress: '0x2222222222222222222222222222222222222222', timestamp: '2026-10-22T05:45:21.314Z' },
  { refereeAddress: '0x5555555555555555555555555555555555555555', timestamp: '2026-10-22T07:09:31.752Z' },
  { refereeAddress: '0x16ee54796d74c3bd8fbe93954b339c629c1acf0c', timestamp: '2026-10-22T15:31:43.566Z' },
  { refereeAddress: '0x03dF2Ff70a21E058d67c2F4bfaB0AD4a22750F37', timestamp: '2026-10-23T08:36:35.182Z' },
  { refereeAddress: '0x1111111111111111111111111111111111111111', timestamp: '2026-10-24T17:40:45.885Z' },
  { refereeAddress: '0x3333333333333333333333333333333333333333', timestamp: '2026-10-24T17:41:13.157Z' },
  { refereeAddress: '0x8888888888888888888888888888888888888888', timestamp: '2026-10-24T17:43:28.329Z' },
  { refereeAddress: '0xaF88C8E3c4ae2B58Ade49C00ac8F1bc8968A48C4', timestamp: '2026-10-29T08:28:45.097Z' },
  { refereeAddress: '0x5512d577b94b8abf9308de15d43507075c43b167', timestamp: '2026-10-14T09:27:16.813Z' },
  { refereeAddress: '0xa0dcb94347e7b4ed957cbf51306bc1f6e8334147', timestamp: '2026-10-14T09:37:01.167Z' },
  { refereeAddress: '0x5dfea4b8aaeff82770710afa22332be6e0817b42', timestamp: '2026-10-14T09:37:06.785Z' },
  { refereeAddress: '0xb955549766b1127bf5b8b834610d1427f47171a4', timestamp: '2026-10-15T18:03:20.955Z' },
  { refereeAddress: '0x2c69b9fe8f052309dd9094e62d97d16127f51f52', timestamp: '2026-10-16T08:55:33.040Z' },
  { refereeAddress: '0x38069663d6408dff184bafc65e247e37ae84a1c2', timestamp: '2026-10-16T10:15:05.139Z' },
  { refereeAddress: '0xc8ae035c7bd0d6a043d7389f5defd3daee0e9006', timestamp: '2026-10-16T10:17:18.496Z' },
  { refereeAddress: '0x6884C3A256e5826e841595a846626B89f717e834', timestamp: '2026-10-17T08:07:11.421Z' },
  { refereeAddress: '0x84c06fe76adf7c7ab16b1f4af84655b1f50147b9', timestamp: '2026-10-18T16:15:09.052Z' },
  { refereeAddress: '0x3856175386ce7cc62ba595310392bd1e42a019f9', timestamp: '2026-10-17T07:43:17.268Z' },
];

/**
 * Register a referral directly in Cloud Firestore.
 * This runs client-side, so even on static hosting (like Hostinger public_html)
 * without a Node.js server, the referral is permanently saved in the cloud!
 */
export async function registerReferralInFirestore(
  referrerCodeOrAddr: string,
  refereeAddress: string
): Promise<{ success: boolean; error?: string }> {
  try {
    if (!refereeAddress || !referrerCodeOrAddr) {
      return { success: false, error: 'Missing address or sponsor' };
    }

    const normReferee = refereeAddress.toLowerCase();
    let normReferrer = referrerCodeOrAddr.toLowerCase().trim();

    // Check if referrer is a known sponsor code
    if (referrerCodeOrAddr.toUpperCase() === 'SPK-3471E0' || referrerCodeOrAddr.toLowerCase().includes('3471e0')) {
      normReferrer = MASTER_WALLET;
    }

    if (normReferrer === normReferee) {
      return { success: false, error: 'Self-referral is not allowed' };
    }

    // Create a deterministic document ID for this referral
    const cleanId = `ref_${normReferee.replace(/[^a-zA-Z0-9]/g, '')}`;
    const docRef = doc(db, 'referrals', cleanId);

    const data: FirestoreReferralRecord = {
      id: cleanId,
      referrerAddress: normReferrer,
      refereeAddress: normReferee,
      tier: 1,
      referralCode: referrerCodeOrAddr.toUpperCase().startsWith('SPK-') ? referrerCodeOrAddr.toUpperCase() : undefined,
      timestamp: new Date().toISOString(),
    };

    await setDoc(docRef, data, { merge: true });

    // Cache locally
    localStorage.setItem(`spike_referred_by_${normReferee}`, normReferrer);

    // Also update sponsor's local cached count if active on this device
    try {
      const sponsorKey = `spike_referral_stats_${normReferrer}`;
      const existing = localStorage.getItem(sponsorKey);
      if (existing) {
        const parsed = JSON.parse(existing);
        parsed.directPartners = (parsed.directPartners || 0) + 1;
        parsed.totalPartners = (parsed.totalPartners || 0) + 1;
        if (Array.isArray(parsed.referrals)) {
          parsed.referrals.unshift({
            id: cleanId,
            address: normReferee,
            tier: 1,
            joinedAt: new Date().toISOString(),
            activeMiners: 1,
            totalCommission: 0,
          });
        }
        localStorage.setItem(sponsorKey, JSON.stringify(parsed));
      }
    } catch {}

    return { success: true };
  } catch (err: any) {
    console.warn('[Firestore Referral Register Handled]:', err?.message || err);
    return { success: false, error: err?.message || 'Firestore write failed' };
  }
}

/**
 * Fetch all direct referrals for a sponsor wallet directly from Cloud Firestore + Baseline.
 */
export async function getReferralsFromFirestore(walletAddress: string): Promise<{
  directPartners: number;
  referrals: Array<{ refereeAddress: string; timestamp: string }>;
}> {
  try {
    if (!walletAddress) return { directPartners: 0, referrals: [] };
    const norm = walletAddress.toLowerCase().trim();

    const referralsMap = new Map<string, { refereeAddress: string; timestamp: string }>();

    // 1. If this is the master sponsor, seed with baseline verified direct partners
    if (norm === MASTER_WALLET || norm.includes('3471e0')) {
      BASELINE_MASTER_DIRECTS.forEach((r) => {
        referralsMap.set(r.refereeAddress.toLowerCase(), r);
      });
    }

    // 2. Query Cloud Firestore for any real-time registered referrals
    try {
      const q = query(collection(db, 'referrals'), where('referrerAddress', '==', norm));
      const snapshot = await getDocs(q);

      snapshot.forEach((d) => {
        const data = d.data() as FirestoreReferralRecord;
        if (data && data.refereeAddress) {
          referralsMap.set(data.refereeAddress.toLowerCase(), {
            refereeAddress: data.refereeAddress,
            timestamp: data.timestamp || new Date().toISOString(),
          });
        }
      });
    } catch (fsErr) {
      console.warn('[Firestore Query Handled]:', fsErr);
    }

    const referrals = Array.from(referralsMap.values());

    return {
      directPartners: referrals.length,
      referrals,
    };
  } catch (err: any) {
    console.warn('[Firestore Referral Stats Handled]:', err?.message || err);
    return { directPartners: 0, referrals: [] };
  }
}
